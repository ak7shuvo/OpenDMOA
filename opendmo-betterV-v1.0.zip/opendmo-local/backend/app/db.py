"""Database layer.

Preferred production/dev target: local PostgreSQL + PostGIS (see database/schema.sql).
For zero-setup local development a SQLite file is used automatically when
DATABASE_URL points to sqlite. Geometry columns are stored as WKT/GeoJSON
text in portable mode and as native geometry under PostGIS.
"""
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, declarative_base
from .config import get_settings

settings = get_settings()

connect_args = {'check_same_thread': False} if settings.database_url.startswith('sqlite') else {}
engine = create_engine(settings.database_url, connect_args=connect_args, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def is_postgis() -> bool:
    return settings.database_url.startswith('postgresql')
