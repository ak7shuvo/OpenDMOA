from datetime import datetime, timezone
import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..db import get_db
from ..db_models import CalculationRun, Calculation, Destination
from ..schemas import CalculationOut, CalculationRunIn
from ..calculations import REGISTRY
from ..services.provenance import run_provenance

router = APIRouter(tags=['calculations'])


@router.get('/calculations', response_model=list[CalculationOut])
def list_calculations():
    return [CalculationOut(id=c.id, name=c.name, version=c.version, category=c.category,
                           inputs=list(c.inputs), formula=c.formula, method=c.method,
                           reference=c.reference, weights=c.weights)
            for c in REGISTRY.values()]


def _ensure_calc_rows(db: Session):
    """Mirror the in-code registry into the calculations table (idempotently)."""
    for c in REGISTRY.values():
        row = (db.query(Calculation)
               .filter(Calculation.id == c.id, Calculation.version == c.version)
               .first())
        if row is None:
            db.add(Calculation(id=c.id, version=c.version, name=c.name, category=c.category,
                               inputs=list(c.inputs), formula=c.formula, method=c.method,
                               reference=c.reference, weights=c.weights))
    db.commit()


@router.post('/calculations/run', status_code=201)
def run_calculation(body: CalculationRunIn, db: Session = Depends(get_db)):
    _ensure_calc_rows(db)
    calc = REGISTRY.get(body.calculation_id)
    if not calc:
        raise HTTPException(404, f'unknown calculation: {body.calculation_id}')
    missing = [k for k in calc.inputs if k not in body.inputs]
    if missing:
        raise HTTPException(422, f'missing inputs: {missing}')
    run = CalculationRun(
        id=f'CALC-{datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")}-{uuid.uuid4().hex[:6]}',
        calculation_id=calc.id, calculation_version=calc.version,
        destination_id=body.destination_id, inputs=body.inputs,
        dataset_id=body.dataset_id, data_quality={})
    run.outputs = calc.compute({k: float(v) for k, v in body.inputs.items()})
    db.add(run)
    db.commit()
    return {'run_id': run.id, 'calculation_id': calc.id, 'version': calc.version,
            'formula': calc.formula, 'outputs': run.outputs,
            'provenance': run_provenance(db, run)}


@router.get('/calculations/runs')
def list_calc_runs(destination_id: str | None = None, limit: int = 50,
                   db: Session = Depends(get_db)):
    q = db.query(CalculationRun).order_by(CalculationRun.created_at.desc()).limit(limit)
    if destination_id:
        q = db.query(CalculationRun).filter(CalculationRun.destination_id == destination_id)                 .order_by(CalculationRun.created_at.desc()).limit(limit)
    return [run_provenance(db, r) for r in q]
