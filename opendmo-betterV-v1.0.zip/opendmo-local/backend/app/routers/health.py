from fastapi import APIRouter
from ..db import engine, is_postgis

router = APIRouter(tags=['system'])


@router.get('/health')
def health():
    try:
        with engine.connect() as conn:
            conn.execute(__import__('sqlalchemy').text('SELECT 1'))
        db = 'postgresql+postgis' if is_postgis() else 'sqlite'
        return {'status': 'ok', 'database': db, 'local_first': True}
    except Exception as exc:
        return {'status': 'degraded', 'detail': str(exc)}
