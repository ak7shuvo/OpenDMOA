import json
import re

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session

from ..db import get_db
from ..db_models import Dataset, Observation, Destination
from ..schemas import (DatasetCreate, DatasetOut, ObservationBatch,
                       ImportPayload, QualityOut)
from ..services import dataset_service as svc

router = APIRouter(prefix='/datasets', tags=['datasets'])

_slug = re.compile(r'[^A-Z0-9]+')


def _dataset_id(dest: str, name: str, version: int) -> str:
    base = _slug.sub('-', f'{dest[:3].upper()}-{name.upper()}').strip('-')
    return f'{base}-{version:02d}'


@router.get('', response_model=list[DatasetOut])
def list_datasets(destination_id: str | None = None, db: Session = Depends(get_db)):
    q = db.query(Dataset)
    if destination_id:
        q = q.filter(Dataset.destination_id == destination_id)
    return q.order_by(Dataset.destination_id, Dataset.name, Dataset.version.desc()).all()


@router.post('', response_model=DatasetOut, status_code=201)
def create_dataset(body: DatasetCreate, db: Session = Depends(get_db)):
    if not db.get(Destination, body.destination_id):
        raise HTTPException(404, 'destination not found')
    version = body.version or svc.next_version(db, body.destination_id, body.name)
    ds = Dataset(
        id=_dataset_id(body.destination_id, body.name, version),
        destination_id=body.destination_id, name=body.name, version=version,
        variable_defs=[v.model_dump() for v in body.variable_defs],
        provenance=body.provenance | {'created_via': 'api'},
    )
    db.add(ds)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(409, 'dataset id conflict — bump the version')
    return ds


@router.get('/{ds_id}', response_model=DatasetOut)
def get_dataset(ds_id: str, db: Session = Depends(get_db)):
    ds = db.get(Dataset, ds_id)
    if not ds:
        raise HTTPException(404, 'dataset not found')
    return ds


@router.get('/{ds_id}/observations')
def get_observations(ds_id: str, period: str | None = None, db: Session = Depends(get_db)):
    q = db.query(Observation).filter(Observation.dataset_id == ds_id)
    if period:
        q = q.filter(Observation.period == period)
    rows = q.order_by(Observation.period, Observation.variable).all()
    return [{'period': r.period, 'variable': r.variable, 'value': r.value,
             'unit': r.unit, 'quality_flag': r.quality_flag} for r in rows]


@router.post('/{ds_id}/observations', status_code=201)
def add_observations(ds_id: str, body: ObservationBatch, db: Session = Depends(get_db)):
    ds = db.get(Dataset, ds_id)
    if not ds:
        raise HTTPException(404, 'dataset not found')
    if ds.status == 'archived':
        raise HTTPException(409, 'dataset is archived — create a new version')
    defined = {v['name'] for v in (ds.variable_defs or [])}
    if defined:
        unknown = sorted({o.variable for o in body.observations} - defined)
        if unknown:
            raise HTTPException(422, f'variables not in dataset definition: {unknown}')
    rows = [o.model_dump() for o in body.observations]
    if body.mode == 'replace':
        for r in rows:
            (db.query(Observation)
               .filter(Observation.dataset_id == ds_id, Observation.period == r['period'],
                       Observation.variable == r['variable'])
               .delete())
        db.commit()
    n = svc.insert_observations(db, ds, rows)
    return {'inserted': n}


@router.post('/{ds_id}/import', status_code=201)
def import_payload(ds_id: str, body: ImportPayload, db: Session = Depends(get_db)):
    ds = db.get(Dataset, ds_id)
    if not ds:
        raise HTTPException(404, 'dataset not found')
    try:
        rows = svc.parse_csv(body.content) if body.format == 'csv' else svc.parse_json(body.content)
    except svc.DatasetError as exc:
        raise HTTPException(422, str(exc))
    n = svc.insert_observations(db, ds, rows)
    ds.provenance = (ds.provenance or {}) | {'last_import': body.format}
    db.commit()
    return {'inserted': n, 'format': body.format}


@router.post('/{ds_id}/upload')
async def upload_file(ds_id: str, file: UploadFile = File(...), db: Session = Depends(get_db)):
    ds = db.get(Dataset, ds_id)
    if not ds:
        raise HTTPException(404, 'dataset not found')
    content = (await file.read()).decode('utf-8', errors='replace')
    fmt = 'json' if file.filename and file.filename.endswith('.json') else 'csv'
    try:
        rows = svc.parse_json(content) if fmt == 'json' else svc.parse_csv(content)
    except svc.DatasetError as exc:
        raise HTTPException(422, str(exc))
    return {'inserted': svc.insert_observations(db, ds, rows), 'format': fmt}


@router.post('/{ds_id}/validate', response_model=QualityOut)
def validate(ds_id: str, db: Session = Depends(get_db)):
    ds = db.get(Dataset, ds_id)
    if not ds:
        raise HTTPException(404, 'dataset not found')
    quality = svc.validate_dataset(db, ds)
    ds.status = 'validated'
    db.commit()
    return quality


@router.get('/{ds_id}/quality', response_model=QualityOut)
def quality(ds_id: str, db: Session = Depends(get_db)):
    ds = db.get(Dataset, ds_id)
    if not ds:
        raise HTTPException(404, 'dataset not found')
    return svc.validate_dataset(db, ds)


@router.post('/{ds_id}/archive')
def archive(ds_id: str, db: Session = Depends(get_db)):
    ds = db.get(Dataset, ds_id)
    if not ds:
        raise HTTPException(404, 'dataset not found')
    ds.status = 'archived'
    db.commit()
    return {'id': ds.id, 'status': ds.status}
