from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..db import get_db
from ..db_models import Destination
from ..schemas import DestinationOut

router = APIRouter(prefix='/destinations', tags=['destinations'])


@router.get('', response_model=list[DestinationOut])
def list_destinations(db: Session = Depends(get_db)):
    return db.query(Destination).order_by(Destination.id).all()


@router.get('/{dest_id}', response_model=DestinationOut)
def get_destination(dest_id: str, db: Session = Depends(get_db)):
    d = db.get(Destination, dest_id)
    if not d:
        raise HTTPException(404, 'destination not found')
    return d
