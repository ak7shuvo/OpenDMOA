from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..db import get_db
from ..db_models import ModelPackage, ModelRun, Destination, Dataset
from ..schemas import ModelInstallIn, ModelRunIn
from ..services.model_manager import download_from_github, register_local_package
from ..services.provenance import run_provenance
from ..runtime.runner import run_model
from ..runtime.package_contract import PackageError

router = APIRouter(tags=['models'])


def _pkg_dict(p: ModelPackage) -> dict:
    return {'id': p.id, 'version': p.version, 'name': p.name, 'task': p.task,
            'description': p.description, 'framework': p.framework,
            'source_repo': p.source_repo, 'source_ref': p.source_ref, 'license': p.license,
            'training_data': p.training_data, 'expected_units': p.expected_units,
            'input_variables': p.input_variables, 'output_variables': p.output_variables,
            'status': p.status, 'installed_at': p.installed_at.isoformat() if p.installed_at else None}


@router.get('/models')
def list_models(db: Session = Depends(get_db)):
    return [_pkg_dict(p) for p in db.query(ModelPackage).order_by(ModelPackage.id, ModelPackage.version).all()]


@router.get('/models/available')
def available_models():
    """Approved model repositories a researcher may install from."""
    return [{'repo': 'opendmo-models/demo-tourism-demand', 'ref': 'v1.0.0',
             'name': 'Tourism Demand Forecast (DEMO)', 'task': 'regression',
             'note': 'Bundled local demo model — clearly labelled synthetic, no real training data.'}]


@router.get('/models/{model_id}')
def get_model(model_id: str, version: str | None = None, db: Session = Depends(get_db)):
    q = db.query(ModelPackage).filter(ModelPackage.id == model_id)
    if version:
        q = q.filter(ModelPackage.version == version)
    p = q.order_by(ModelPackage.version.desc()).first()
    if not p:
        raise HTTPException(404, 'model not found')
    return _pkg_dict(p)


@router.post('/models/install', status_code=201)
def install(body: ModelInstallIn, db: Session = Depends(get_db)):
    try:
        pkg = download_from_github(db, body.repo, body.ref)
    except PackageError as exc:
        raise HTTPException(422, str(exc))
    return _pkg_dict(pkg)


@router.post('/models/register-local', status_code=201)
def register_local(path: str, db: Session = Depends(get_db)):
    """Register a package already on local disk (bundled demo model)."""
    try:
        pkg = register_local_package(db, path)
    except PackageError as exc:
        raise HTTPException(422, str(exc))
    return _pkg_dict(pkg)


@router.post('/models/{model_id}/status')
def set_status(model_id: str, body: dict, db: Session = Depends(get_db)):
    p = db.get(ModelPackage, (model_id, body.get('version', '')))
    if not p:
        # version may be omitted in path; find latest
        p = (db.query(ModelPackage).filter(ModelPackage.id == model_id)
             .order_by(ModelPackage.version.desc()).first())
    if not p:
        raise HTTPException(404, 'model not found')
    if body.get('status') not in ('enabled', 'disabled'):
        raise HTTPException(422, 'status must be enabled | disabled')
    p.status = body['status']
    db.commit()
    return _pkg_dict(p)


@router.post('/models/run', status_code=201)
def run(body: ModelRunIn, db: Session = Depends(get_db)):
    q = (db.query(ModelPackage)
         .filter(ModelPackage.id == body.model_id, ModelPackage.status == 'enabled'))
    if body.model_version:
        q = q.filter(ModelPackage.version == body.model_version)
    pkg = q.order_by(ModelPackage.version.desc()).first()
    if not pkg:
        raise HTTPException(404, 'model not found or not enabled')
    dest = db.get(Destination, body.destination_id)
    if not dest:
        raise HTTPException(404, 'destination not found')
    ds = db.get(Dataset, body.dataset_id) if body.dataset_id else None
    run = run_model(db, pkg, dest, body.inputs,
                    dataset_id=body.dataset_id,
                    dataset_version=ds.version if ds else None)
    return run_provenance(db, run) | {'status': run.status, 'error': run.error}


@router.get('/models/runs')
def list_runs(destination_id: str | None = None, model_id: str | None = None,
              limit: int = 50, db: Session = Depends(get_db)):
    q = db.query(ModelRun)
    if destination_id:
        q = q.filter(ModelRun.destination_id == destination_id)
    if model_id:
        q = q.filter(ModelRun.model_id == model_id)
    q = q.order_by(ModelRun.created_at.desc()).limit(limit)
    return [run_provenance(db, r) | {'status': r.status, 'error': r.error} for r in q]
