"""Persistent entities — database/schema.sql is the reference DDL.

Kept deliberately small (no over-engineering): destinations, datasets,
observations, models, model_versions, model_runs, calculations,
calculation_versions, calculation_runs, gis_layers.
"""
from sqlalchemy import (Column, Integer, String, Float, Boolean, DateTime,
                        ForeignKey, Text, UniqueConstraint, JSON)
from sqlalchemy.sql import func
from .db import Base


class Destination(Base):
    __tablename__ = 'destinations'
    id          = Column(String(32), primary_key=True)          # e.g. 'jaflong'
    name        = Column(String(128), nullable=False)
    region      = Column(String(128))
    latitude    = Column(Float)
    longitude   = Column(Float)
    capacity_k  = Column(Float)                                  # modelled annual capacity, '000 visitors
    attributes  = Column(JSON, default=dict)                     # narrative fields from LocationDef
    created_at  = Column(DateTime(timezone=True), server_default=func.now())


class Dataset(Base):
    """A versioned collection of observations for one destination."""
    __tablename__ = 'datasets'
    id            = Column(String(64), primary_key=True)         # e.g. 'JAF-2026-09'
    destination_id = Column(String(32), ForeignKey('destinations.id'), nullable=False, index=True)
    name          = Column(String(192), nullable=False)
    version       = Column(Integer, nullable=False, default=1)
    status        = Column(String(24), nullable=False, default='draft')  # draft | validated | archived
    quality_score = Column(Float)                                # 0–100 data-quality indicator
    quality_notes = Column(Text)
    variable_defs = Column(JSON, nullable=False, default=list)   # DatasetVariableDef[]
    provenance    = Column(JSON, default=dict)                   # source, importer, timestamps
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (UniqueConstraint('destination_id', 'name', 'version'),)


class Observation(Base):
    """One value of one variable at one (destination, period)."""
    __tablename__ = 'observations'
    id           = Column(Integer, primary_key=True)
    dataset_id   = Column(String(64), ForeignKey('datasets.id'), nullable=False, index=True)
    destination_id = Column(String(32), ForeignKey('destinations.id'), nullable=False, index=True)
    period       = Column(String(16), nullable=False)            # '2026-09' or '2026'
    variable     = Column(String(64), nullable=False, index=True)
    value        = Column(Float, nullable=False)
    unit         = Column(String(32))
    quality_flag = Column(String(16), default='ok')              # ok | estimated | missing | outlier
    created_at   = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (UniqueConstraint('dataset_id', 'period', 'variable'),)


class ModelPackage(Base):
    """Registered model (one row per installed package version)."""
    __tablename__ = 'models'
    id              = Column(String(64), primary_key=True)       # 'demo-tourism-demand'
    version         = Column(String(32), primary_key=True)       # semver or commit tag
    name            = Column(String(192), nullable=False)
    task            = Column(String(64), nullable=False)         # regression | classification | index
    description     = Column(Text)
    framework       = Column(String(64), nullable=False)         # 'json-linear' | 'sklearn-joblib' ...
    source_repo     = Column(String(512))
    source_ref      = Column(String(128))                        # commit / tag / version
    license         = Column(String(64))
    training_data   = Column(Text)
    expected_units  = Column(JSON, default=dict)
    input_variables = Column(JSON, nullable=False, default=list) # VariableSpec[]
    output_variables = Column(JSON, nullable=False, default=list)
    status          = Column(String(24), nullable=False, default='disabled')  # enabled | disabled | error
    package_path    = Column(String(512), nullable=False)
    installed_at    = Column(DateTime(timezone=True), server_default=func.now())
    metadata_json   = Column(JSON, default=dict)                 # full metadata.json copy


class ModelRun(Base):
    __tablename__ = 'model_runs'
    id               = Column(String(48), primary_key=True)      # 'RUN-<ts>-<rand>'
    model_id         = Column(String(64), nullable=False, index=True)
    model_version    = Column(String(32), nullable=False)
    destination_id   = Column(String(32), ForeignKey('destinations.id'), nullable=False)
    inputs           = Column(JSON, nullable=False)              # {var: value}
    derived_variables = Column(JSON, default=dict)
    dataset_id       = Column(String(64))                        # provenance: which dataset fed X
    dataset_version  = Column(Integer)
    outputs          = Column(JSON, nullable=False)              # {var: value}
    status           = Column(String(24), nullable=False)        # success | failed
    runtime          = Column(String(64), default='local')
    eval_metrics     = Column(JSON, default=dict)
    data_quality     = Column(JSON, default=dict)
    error            = Column(Text)
    created_at       = Column(DateTime(timezone=True), server_default=func.now())


class Calculation(Base):
    __tablename__ = 'calculations'
    id          = Column(String(64), primary_key=True)           # 'pressure.index'
    version     = Column(String(32), primary_key=True)
    name        = Column(String(192), nullable=False)
    category    = Column(String(64))                             # growth | ratios | pressure | capacity | sustainability
    inputs      = Column(JSON, nullable=False, default=list)     # ['visitors','capacity',...]
    formula     = Column(Text, nullable=False)                   # human-readable formula
    method      = Column(Text)                                   # methodology notes
    reference   = Column(String(512))                            # source / citation
    weights     = Column(JSON, default=dict)
    status      = Column(String(24), default='active')
    created_at  = Column(DateTime(timezone=True), server_default=func.now())


class CalculationRun(Base):
    __tablename__ = 'calculation_runs'
    id              = Column(String(48), primary_key=True)
    calculation_id  = Column(String(64), nullable=False, index=True)
    calculation_version = Column(String(32), nullable=False)
    destination_id  = Column(String(32), ForeignKey('destinations.id'), nullable=False)
    inputs          = Column(JSON, nullable=False)
    outputs         = Column(JSON, nullable=False)
    dataset_id      = Column(String(64))
    data_quality    = Column(JSON, default=dict)
    created_at      = Column(DateTime(timezone=True), server_default=func.now())


class GisLayer(Base):
    __tablename__ = 'gis_layers'
    id          = Column(String(64), primary_key=True)
    name        = Column(String(128), nullable=False)
    category    = Column(String(64))
    description = Column(Text)
    destination_id = Column(String(32), ForeignKey('destinations.id'))
    geometry    = Column(Text)                                   # WKT or GeoJSON (PostGIS: geometry)
    attributes  = Column(JSON, default=dict)
    source      = Column(String(512))
    demo        = Column(Boolean, default=False)                 # clearly-labelled schematic/demo layers
    created_at  = Column(DateTime(timezone=True), server_default=func.now())
