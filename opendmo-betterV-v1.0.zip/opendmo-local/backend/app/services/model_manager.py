"""Model Manager — download, validate, register and store model packages.

Download workflow (GitHub):
    repo URL -> download zip archive of the package subtree -> validate
    against the contract -> read metadata -> register -> store locally.

Only archives whose metadata passes contract validation are registered.
No package code is ever executed at install time.
"""
import io
import shutil
import tempfile
import zipfile
from pathlib import Path

import httpx

from ..config import get_settings
from ..db_models import ModelPackage
from ..runtime.package_contract import validate_package, PackageError


def _github_zip_url(repo: str, ref: str) -> str:
    repo = repo.strip().removesuffix('.git')
    repo = repo.removeprefix('https://github.com/').removeprefix('github.com/')
    if repo.count('/') != 1:
        raise PackageError(f'expected GitHub repo "owner/name", got: {repo!r}')
    return f'https://api.github.com/repos/{repo}/zipball/{ref}'


def download_from_github(db, repo: str, ref: str = 'main') -> ModelPackage:
    """Download a compatible model package from an approved GitHub repository."""
    settings = get_settings()
    url = _github_zip_url(repo, ref)
    headers = {'Accept': 'application/vnd.github+json'}
    if settings.github_token:
        headers['Authorization'] = f'Bearer {settings.github_token}'

    with httpx.Client(timeout=60, follow_redirects=True) as client:
        resp = client.get(url, headers=headers)
    if resp.status_code != 200:
        raise PackageError(f'GitHub download failed: HTTP {resp.status_code}')

    store = Path(settings.model_store)
    store.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
            zf.extractall(tmp)
        roots = [p for p in Path(tmp).iterdir() if p.is_dir()]
        if not roots:
            raise PackageError('archive is empty')
        meta = validate_package(roots[0])          # raises on contract violation

        dest = store / meta['id'] / meta['version']
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(roots[0], dest)

    # read schema.json for the variable contract
    schema = __import__('json').loads((dest / 'schema.json').read_text(encoding='utf-8'))
    meta['schema'] = schema

    pkg = (db.query(ModelPackage)
           .filter(ModelPackage.id == meta['id'], ModelPackage.version == meta['version'])
           .first())
    if pkg is None:
        pkg = ModelPackage(id=meta['id'], version=meta['version'])
        db.add(pkg)
    pkg.name = meta['name']
    pkg.task = meta['task']
    pkg.description = meta['description']
    pkg.framework = meta['framework']
    pkg.source_repo = repo
    pkg.source_ref = meta.get('source_ref', ref)
    pkg.license = meta['license']
    pkg.training_data = meta.get('training_data', '')
    pkg.expected_units = meta.get('expected_units', {})
    pkg.input_variables = schema['inputs']
    pkg.output_variables = schema['outputs']
    pkg.package_path = str(dest)
    pkg.metadata_json = meta
    pkg.status = 'enabled'
    db.commit()
    return pkg


def register_local_package(db, pkg_dir: str) -> ModelPackage:
    """Register a package already on local disk (e.g. the bundled demo model)."""
    meta = validate_package(pkg_dir)
    dest = Path(get_settings().model_store) / meta['id'] / meta['version']
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        shutil.copytree(pkg_dir, dest)
    import json
    schema = json.loads((dest / 'schema.json').read_text(encoding='utf-8'))
    meta['schema'] = schema
    pkg = ModelPackage(
        id=meta['id'], version=meta['version'], name=meta['name'], task=meta['task'],
        description=meta['description'], framework=meta['framework'],
        source_repo=meta['source_repo'], source_ref=meta.get('source_ref', 'local'),
        license=meta['license'], training_data=meta.get('training_data', ''),
        expected_units=meta.get('expected_units', {}),
        input_variables=schema['inputs'], output_variables=schema['outputs'],
        package_path=str(dest), metadata_json=meta, status='enabled',
    )
    db.merge(pkg)
    db.commit()
    return pkg
