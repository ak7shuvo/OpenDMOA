"""Provenance assembly — every result answers: what data, what variables,
what formula/model, what version, when, and what data quality."""
from ..db_models import CalculationRun, ModelRun, Dataset


def run_provenance(db, run) -> dict:
    """Build the inspectable provenance block for a model or calculation run."""
    ds = None
    if getattr(run, 'dataset_id', None):
        ds = db.get(Dataset, run.dataset_id)
    base = {
        'run_id': run.id,
        'destination': run.destination_id,
        'timestamp': run.created_at.isoformat() if run.created_at else None,
        'inputs': run.inputs,
        'outputs': run.outputs,
        'data_quality': getattr(run, 'data_quality', None) or (
            {'dataset_score': ds.quality_score, 'dataset_level': None} if ds else None),
    }
    if isinstance(run, CalculationRun):
        base['method'] = {'type': 'calculation', 'id': run.calculation_id, 'version': run.calculation_version}
    else:
        base['method'] = {'type': 'model', 'id': run.model_id, 'version': run.model_version,
                          'source_repo': getattr(run, 'source_repo', None)}
    if ds:
        base['source'] = {'dataset_id': ds.id, 'dataset_version': ds.version,
                          'dataset_name': ds.name, 'quality_score': ds.quality_score}
    return base
