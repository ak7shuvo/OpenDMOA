"""Dataset operations: validation, versioning, quality indicators, import parsing."""
import csv
import io
import json
from datetime import datetime, timezone

from sqlalchemy import func
from ..db_models import Dataset, Observation, Destination


class DatasetError(ValueError):
    pass


def validate_dataset(db, ds: Dataset) -> dict:
    """Run data-quality checks over a dataset's observations."""
    obs = db.query(Observation).filter(Observation.dataset_id == ds.id).all()
    total = len(obs)
    flags = {}
    for o in obs:
        flags[o.quality_flag] = flags.get(o.quality_flag, 0) + 1
    defined = {v['name'] for v in (ds.variable_defs or [])}
    observed = {o.variable for o in obs}
    missing_vars = sorted(defined - observed)
    # completeness: expected cells = variables x periods
    periods = {o.period for o in obs}
    expected = max(len(defined) * len(periods), 1)
    completeness = round(min(total / expected, 1.0) * 100, 1)
    score = round(completeness - 10 * flags.get('outlier', 0) - 5 * flags.get('estimated', 0), 1)
    quality = {
        'observations': total,
        'periods': sorted(periods),
        'variables_observed': sorted(observed),
        'variables_defined': sorted(defined),
        'variables_missing': missing_vars,
        'flags': flags,
        'completeness_pct': completeness,
        'quality_score': max(score, 0.0),
        'checked_at': datetime.now(timezone.utc).isoformat(),
        'level': 'high' if score >= 90 else 'moderate' if score >= 60 else 'low',
    }
    ds.quality_score = quality['quality_score']
    ds.quality_notes = json.dumps(quality['flags'])
    db.commit()
    return quality


def next_version(db, destination_id: str, name: str) -> int:
    last = (db.query(func.max(Dataset.version))
            .filter(Dataset.destination_id == destination_id, Dataset.name == name)
            .scalar())
    return (last or 0) + 1


def _coerce_float(raw: str) -> float | None:
    try:
        return float(str(raw).strip())
    except (TypeError, ValueError):
        return None


def parse_csv(text: str) -> list[dict]:
    """Parse CSV of shape: period,variable,value[,unit]."""
    rows = []
    reader = csv.DictReader(io.StringIO(text))
    need = {'period', 'variable', 'value'}
    if not reader.fieldnames or not need.issubset(set(reader.fieldnames)):
        raise DatasetError('CSV must have header: period,variable,value[,unit]')
    for i, row in enumerate(reader, start=2):
        val = _coerce_float(row['value'])
        if val is None:
            raise DatasetError(f'row {i}: value is not numeric: {row["value"]!r}')
        rows.append({'period': row['period'].strip(), 'variable': row['variable'].strip(),
                     'value': val, 'unit': (row.get('unit') or '').strip() or None})
    return rows


def parse_json(text: str) -> list[dict]:
    """Parse JSON of shape: {"observations": [{"period","variable","value","unit"?}]}."""
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise DatasetError(f'invalid JSON: {exc}') from exc
    rows = payload.get('observations') if isinstance(payload, dict) else payload
    if not isinstance(rows, list):
        raise DatasetError('JSON must be a list or {"observations": [...]}')
    out = []
    for i, row in enumerate(rows):
        for field in ['period', 'variable', 'value']:
            if field not in row:
                raise DatasetError(f'row {i}: missing {field}')
        val = _coerce_float(row['value'])
        if val is None:
            raise DatasetError(f'row {i}: value is not numeric')
        out.append({'period': str(row['period']), 'variable': str(row['variable']),
                    'value': val, 'unit': row.get('unit')})
    return out


def insert_observations(db, ds: Dataset, rows: list[dict]) -> int:
    count = 0
    for row in rows:
        exists = (db.query(Observation)
                  .filter(Observation.dataset_id == ds.id, Observation.period == row['period'],
                          Observation.variable == row['variable'])
                  .first())
        if exists:
            continue
        db.add(Observation(dataset_id=ds.id, destination_id=ds.destination_id,
                           period=row['period'], variable=row['variable'],
                           value=row['value'], unit=row.get('unit'),
                           quality_flag=row.get('quality_flag', 'ok')))
        count += 1
    db.commit()
    return count
