"""OpenDMO backend — local-first API.

Run:  uvicorn app.main:app --reload --port 8000
"""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import get_settings
from .db import Base, engine
from . import db_models  # noqa: F401  (register entities)
from .routers import health, destinations, datasets, calculations, models

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    _seed()
    yield


def _seed():
    """Idempotent seed: pilot destinations + bundled demo model registration."""
    from .db import SessionLocal
    from .scripts_seed import seed_destinations, seed_demo_model
    db = SessionLocal()
    try:
        seed_destinations(db)
        seed_demo_model(db)
    finally:
        db.close()


app = FastAPI(
    title='OpenDMO Local Runtime',
    version='0.6.0-alpha',
    description='Local-first research data, calculation and model runtime for OpenDMO. '
                'All data stays on this machine unless the researcher explicitly exports it.',
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(',')],
    allow_methods=['*'],
    allow_headers=['*'],
)

app.include_router(health.router, prefix='/api')
app.include_router(destinations.router, prefix='/api')
app.include_router(datasets.router, prefix='/api')
app.include_router(calculations.router, prefix='/api')
app.include_router(models.router, prefix='/api')


@app.get('/api/meta')
def meta():
    return {
        'product': 'OpenDMO',
        'mode': 'local-first',
        'network': 'offline-capable; internet used only for model downloads and optional ingestion',
        'location_policy': 'browser/network location is optional, approximate, never transmitted by default',
        'demo_data': 'synthetic demo data bundled with the frontend; research data lives in the local DB',
    }
