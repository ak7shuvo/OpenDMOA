"""Idempotent seed data — pilot destinations + bundled demo model."""
from pathlib import Path

from .db_models import Destination, ModelPackage
from .services.model_manager import register_local_package

PILOTS = [
    {'id': 'jaflong', 'name': 'Jaflong', 'region': 'Sylhet Division',
     'latitude': 25.17, 'longitude': 92.02, 'capacity_k': 730,
     'attributes': {'gauge': 'Piyain', 'envChange': 'Stone-extraction pressure on streambed, monitored since 2021',
                    'tourismPressure': 'High weekend density, moderate weekday flow'}},
    {'id': 'ratargul', 'name': 'Ratargul Swamp Forest', 'region': 'Sylhet Division',
     'latitude': 25.08, 'longitude': 91.99, 'capacity_k': 400,
     'attributes': {'gauge': 'Goyain', 'envChange': 'Canopy cover stable, minor siltation near boat channel',
                    'tourismPressure': 'Boat-access controlled, capacity within limits'}},
    {'id': 'sajek', 'name': 'Sajek Valley', 'region': 'Chittagong Hill Tracts',
     'latitude': 23.38, 'longitude': 92.29, 'capacity_k': 480,
     'attributes': {'gauge': 'Kassalong (nearest)', 'envChange': 'Slope destabilisation near km 18 access road, tracked since 2023',
                    'tourismPressure': 'Rapid resort development, peak-season overload'}},
    {'id': 'bandarban', 'name': 'Bandarban Hill District', 'region': 'Chittagong Hill Tracts',
     'latitude': 22.19, 'longitude': 92.22, 'capacity_k': 1200,
     'attributes': {'gauge': 'Sangu', 'envChange': 'Mixed land-use change along corridor settlements',
                    'tourismPressure': 'Distributed across multiple sites; corridor congestion in season'}},
]


def seed_destinations(db) -> None:
    for row in PILOTS:
        if db.get(Destination, row['id']) is None:
            db.add(Destination(**row))
    db.commit()


def seed_demo_model(db) -> None:
    pkg_dir = Path(__file__).resolve().parent.parent / 'model_packages' / 'demo-tourism-demand-v1'
    if not pkg_dir.is_dir():
        return
    existing = db.query(ModelPackage).filter_by(id='demo-tourism-demand').first()
    if existing is None:
        register_local_package(db, str(pkg_dir))
