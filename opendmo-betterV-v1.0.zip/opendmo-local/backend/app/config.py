"""Central configuration — local-first, no cloud dependencies."""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    database_url: str = 'sqlite:///./opendmo.db'
    model_store: str = './model_store'
    dataset_store: str = './dataset_store'
    github_token: str | None = None
    cors_origins: str = 'http://localhost:3000'
    allow_pickle_models: bool = False


@lru_cache
def get_settings() -> Settings:
    return Settings()
