"""Sustainability screening composite — OpenDMO custom index (explicit weights)."""
from .base import CalculationDef


def _sustainability(v: dict) -> dict:
    waste = v.get('waste_per_visitor_kg')
    rev = v.get('revenue_per_visitor')
    # normalisation references are methodology constants of THIS index version,
    # recorded in the calculation registry and every run's provenance.
    waste_score = 100 if waste is None else max(0.0, 100 - waste / 0.5 * 100)   # 0.5 kg ref level
    rev_score = 100 if rev is None else min(rev / 5000 * 100, 100)              # 5000 BDT ref level
    idx = round(0.5 * waste_score + 0.5 * rev_score, 2)
    return {'sustainability_screen': idx,
            'waste_score': round(waste_score, 2),
            'revenue_score': round(rev_score, 2)}


sustainability_screen = CalculationDef(
    id='sustainability.screen',
    name='Sustainability Screening Score',
    version='1.0.0',
    category='sustainability',
    inputs=('waste_per_visitor_kg', 'revenue_per_visitor'),
    formula='0.5 * max(0, 100 - waste/0.5*100) + 0.5 * min(revenue/5000*100, 100)',
    method='Equal-weighted (0.5/0.5) screen of waste intensity and local revenue '
           'capture. Reference levels (0.5 kg waste, 5000 BDT revenue per visitor) '
           'are OpenDMO methodology constants for v1.0 — screening only, not a '
           'certification.',
    reference='OpenDMO custom index — methodology documented in docs/CALCULATIONS.md',
    weights={'waste_score': 0.5, 'revenue_score': 0.5},
    compute=_sustainability,
)
