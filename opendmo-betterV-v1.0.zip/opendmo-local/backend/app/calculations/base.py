"""Calculation registry base.

Every calculation exposes: id, name, version, inputs, formula, method,
reference, weights, and a pure `compute(inputs: dict) -> dict` function.
Calculations are data-in/data-out — never touch the DB; the API layer
persists CalculationRun rows for provenance.
"""
from dataclasses import dataclass, field
from typing import Callable


@dataclass(frozen=True)
class CalculationDef:
    id: str
    name: str
    version: str
    category: str
    inputs: tuple[str, ...]
    formula: str
    method: str
    reference: str
    weights: dict = field(default_factory=dict)
    compute: Callable[[dict[str, float]], dict[str, float]] = lambda _: {}
