"""Calculation registry — the single source of truth for available calculations."""
from .base import CalculationDef
from . import growth, ratios, pressure, capacity, sustainability

REGISTRY: dict[str, CalculationDef] = {
    c.id: c
    for c in [
        growth.growth_rate, growth.cagr,
        ratios.occupancy_rate, ratios.waste_per_visitor,
        ratios.revenue_per_visitor, ratios.visitor_density,
        pressure.pressure_index,
        capacity.capacity_utilisation,
        sustainability.sustainability_screen,
    ]
}


def get(calc_id: str) -> CalculationDef | None:
    return REGISTRY.get(calc_id)


def all_calculations() -> list[CalculationDef]:
    return list(REGISTRY.values())
