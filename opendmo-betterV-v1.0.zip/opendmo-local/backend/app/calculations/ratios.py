"""Ratio calculations — intensity / efficiency ratios between variables."""
from .base import CalculationDef

occupancy_rate = CalculationDef(
    id='ratio.occupancy_rate',
    name='Hotel Occupancy Rate',
    version='1.0.0',
    category='ratios',
    inputs=('rooms_sold', 'rooms_available'),
    formula='rooms_sold / rooms_available * 100',
    method='Standard lodging occupancy measure.',
    reference='UNWTO / STR standard occupancy definition.',
    compute=lambda v: {'occupancy_rate_pct':
        None if not v.get('rooms_available') else
        v.get('rooms_sold', 0) / v['rooms_available'] * 100},
)

waste_per_visitor = CalculationDef(
    id='ratio.waste_per_visitor',
    name='Waste per Visitor',
    version='1.0.0',
    category='ratios',
    inputs=('waste_kg', 'visitors'),
    formula='waste_kg / visitors',
    method='Solid waste generated per visitor visit; unit kg/visitor.',
    reference='Derived indicator; methodology defined by OpenDMO, v1.0.',
    compute=lambda v: {'waste_per_visitor_kg':
        None if not v.get('visitors') else v.get('waste_kg', 0) / v['visitors']},
)

revenue_per_visitor = CalculationDef(
    id='ratio.revenue_per_visitor',
    name='Revenue per Visitor',
    version='1.0.0',
    category='ratios',
    inputs=('revenue', 'visitors'),
    formula='revenue / visitors',
    method='Direct revenue attributed to tourism divided by visitor count.',
    reference='Derived indicator; methodology defined by OpenDMO, v1.0.',
    compute=lambda v: {'revenue_per_visitor':
        None if not v.get('visitors') else v.get('revenue', 0) / v['visitors']},
)

visitor_density = CalculationDef(
    id='ratio.visitor_density',
    name='Visitor Density',
    version='1.0.0',
    category='ratios',
    inputs=('visitors', 'area_km2'),
    formula='visitors / area_km2',
    method='Visitors per square kilometre per period.',
    reference='Derived indicator; methodology defined by OpenDMO, v1.0.',
    compute=lambda v: {'visitor_density_per_km2':
        None if not v.get('area_km2') else v.get('visitors', 0) / v['area_km2']},
)
