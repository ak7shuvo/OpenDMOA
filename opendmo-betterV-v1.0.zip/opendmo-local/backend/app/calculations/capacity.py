"""Capacity utilisation calculations."""
from .base import CalculationDef

capacity_utilisation = CalculationDef(
    id='capacity.utilisation',
    name='Capacity Utilisation',
    version='1.0.0',
    category='capacity',
    inputs=('visitors', 'capacity'),
    formula='visitors / capacity * 100',
    method='Share of modelled annual carrying capacity used in the period.',
    reference='Derived indicator; methodology defined by OpenDMO, v1.0.',
    compute=lambda v: {'capacity_utilisation_pct':
        None if not v.get('capacity') else v.get('visitors', 0) / v['capacity'] * 100},
)
