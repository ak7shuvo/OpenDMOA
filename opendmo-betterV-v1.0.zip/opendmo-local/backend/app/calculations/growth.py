"""Growth calculations — compound and period-over-period change."""
from .base import CalculationDef

# Reference: standard compound growth measure, equivalent in form to CAGR;
# no domain-specific constants are invented.
growth_rate = CalculationDef(
    id='growth.rate',
    name='Growth Rate (period-over-period)',
    version='1.0.0',
    category='growth',
    inputs=('value_current', 'value_previous'),
    formula='(value_current - value_previous) / value_previous * 100',
    method='Simple percentage change between two observation periods. '
           'Returns percent; undefined (None) when the base period is zero.',
    reference='Standard percentage-change formula (algebraic identity).',
    compute=lambda v: {'growth_rate_pct':
        None if not v.get('value_previous') else
        (v['value_current'] - v['value_previous']) / v['value_previous'] * 100},
)

cagr = CalculationDef(
    id='growth.cagr',
    name='Compound Annual Growth Rate',
    version='1.0.0',
    category='growth',
    inputs=('value_begin', 'value_end', 'years'),
    formula='((value_end / value_begin) ** (1 / years) - 1) * 100',
    method='Compound annual growth over n years.',
    reference='Standard CAGR definition.',
    compute=lambda v: {'cagr_pct':
        None if (not v.get('value_begin') or not v.get('years')) else
        ((v['value_end'] / v['value_begin']) ** (1 / v['years']) - 1) * 100},
)
