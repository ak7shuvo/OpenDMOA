"""Tourism pressure index — OpenDMO custom composite.

Custom index: methodology, formula, variables, weights, reference and
version are declared here and recorded with every calculation run.
"""
from .base import CalculationDef


def _pressure(v: dict) -> dict:
    cap = v.get('capacity')
    if not cap:
        return {'pressure_index': None}
    vcr = v.get('visitors', 0) / cap                      # visitor / capacity ratio (weight 0.6)
    occ = min(v.get('occupancy_rate', 0) / 100, 1.0)      # occupancy share      (weight 0.4)
    idx = (0.6 * vcr + 0.4 * occ) * 100
    return {'pressure_index': round(idx, 2),
            'visitor_capacity_ratio': round(vcr, 4),
            'pressure_band': 'high' if idx >= 75 else 'moderate' if idx >= 45 else 'low'}


pressure_index = CalculationDef(
    id='pressure.tourism_index',
    name='Tourism Pressure Index',
    version='1.1.0',
    category='pressure',
    inputs=('visitors', 'capacity', 'occupancy_rate'),
    formula='(0.6 * visitors/capacity + 0.4 * min(occupancy_rate/100, 1)) * 100',
    method='Weighted composite of the visitor/capacity ratio and hotel occupancy. '
           'Weights 0.6/0.4 set by OpenDMO methodology v1.1; bands: low <45, '
           'moderate 45–75, high >=75. Index is a screening indicator, not a '
           'carrying-capacity determination.',
    reference='OpenDMO custom index — methodology documented in docs/CALCULATIONS.md',
    weights={'visitor_capacity_ratio': 0.6, 'occupancy_rate': 0.4},
    compute=_pressure,
)
