"""API schemas — the frontend only ever talks to these shapes."""
from pydantic import BaseModel, Field


class DestinationOut(BaseModel):
    id: str
    name: str
    region: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    capacity_k: float | None = None
    attributes: dict = {}


class VariableDef(BaseModel):
    """Metadata-driven variable definition used to generate entry forms."""
    name: str
    label: str
    unit: str = ''
    type: str = 'float'                     # float | int | bool | category
    description: str = ''
    required: bool = True
    min: float | None = None
    max: float | None = None
    source: str = 'researcher-entry'        # provenance of the variable definition


class DatasetCreate(BaseModel):
    destination_id: str
    name: str
    version: int | None = None              # auto-bump when omitted
    variable_defs: list[VariableDef] = []
    provenance: dict = {}


class DatasetOut(BaseModel):
    id: str
    destination_id: str
    name: str
    version: int
    status: str
    quality_score: float | None = None
    variable_defs: list = []
    provenance: dict = {}


class ObservationIn(BaseModel):
    period: str = Field(..., examples=['2026-09'])
    variable: str
    value: float
    unit: str | None = None


class ObservationBatch(BaseModel):
    observations: list[ObservationIn]
    mode: str = 'insert'                    # insert | replace


class ImportPayload(BaseModel):
    format: str                             # 'csv' | 'json'
    content: str


class CalculationOut(BaseModel):
    id: str
    name: str
    version: str
    category: str
    inputs: list[str]
    formula: str
    method: str
    reference: str
    weights: dict = {}


class CalculationRunIn(BaseModel):
    calculation_id: str
    destination_id: str
    inputs: dict[str, float]
    dataset_id: str | None = None


class ModelRunIn(BaseModel):
    model_id: str
    model_version: str | None = None        # latest enabled when omitted
    destination_id: str
    inputs: dict[str, float]
    dataset_id: str | None = None


class ModelInstallIn(BaseModel):
    repo: str = Field(..., examples=['opendmo-models/demo-tourism-demand'])
    ref: str = 'main'


class QualityOut(BaseModel):
    observations: int
    periods: list[str]
    variables_observed: list[str]
    variables_defined: list[str]
    variables_missing: list[str]
    flags: dict
    completeness_pct: float
    quality_score: float
    level: str
