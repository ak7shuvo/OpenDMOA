"""Model execution — validates inputs against schema, runs locally, records provenance."""
from datetime import datetime, timezone
import uuid

from ..db_models import ModelPackage, ModelRun, Destination
from ..config import get_settings
from .loader import load_model


def _validate_inputs(schema_inputs: list[dict], inputs: dict) -> list[str]:
    errors = []
    for spec in schema_inputs:
        name = spec['name']
        if name not in inputs:
            if spec.get('required', True):
                errors.append(f'missing required input: {name}')
            continue
        try:
            val = float(inputs[name])
        except (TypeError, ValueError):
            errors.append(f'input {name} is not numeric: {inputs[name]!r}')
            continue
        if 'min' in spec and val < spec['min']:
            errors.append(f'input {name} below min {spec["min"]}')
        if 'max' in spec and val > spec['max']:
            errors.append(f'input {name} above max {spec["max"]}')
    return errors


def run_model(db, pkg: ModelPackage, destination: Destination, inputs: dict,
              dataset_id: str | None = None, dataset_version: int | None = None) -> ModelRun:
    run_id = f'RUN-{datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")}-{uuid.uuid4().hex[:6]}'
    run = ModelRun(
        id=run_id, model_id=pkg.id, model_version=pkg.version,
        destination_id=destination.id, inputs=inputs,
        dataset_id=dataset_id, dataset_version=dataset_version,
        derived_variables={}, status='failed', runtime='local',
    )
    try:
        schema = pkg.metadata_json.get('schema', {})
        errors = _validate_inputs(schema.get('inputs', []), inputs)
        if errors:
            raise ValueError('; '.join(errors))
        model = load_model(pkg.package_path, pkg.framework, pkg.metadata_json.get('_artifact') or '',
                           allow_pickle=get_settings().allow_pickle_models)
        raw = model.predict({k: float(v) for k, v in inputs.items()})
        outputs = {}
        out_specs = {o['name']: o for o in schema.get('outputs', [])}
        for k, v in raw.items():
            spec = out_specs.get(k, {})
            outputs[k] = {'value': v, 'unit': spec.get('unit', '')}
        run.outputs = outputs
        run.status = 'success'
        run.eval_metrics = pkg.metadata_json.get('evaluation', {})
    except Exception as exc:  # recorded, never silently swallowed
        run.error = str(exc)
    db.add(run)
    db.commit()
    return run
