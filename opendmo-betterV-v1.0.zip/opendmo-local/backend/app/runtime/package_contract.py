"""Model package contract — validation ONLY, no code execution.

A model package is a directory (or zip) with:

    model-package/
    ├── model/            artifact file(s)
    │   └── model.<ext>
    ├── metadata.json     identity, provenance, licensing
    ├── schema.json       input/output variable contract
    ├── requirements.txt  declared deps (informational; never auto-installed)
    └── README.md

Security rule: the runtime NEVER imports or execs package code. Only
whitelisted artifact FORMATS are loadable. Today: 'json-linear' (pure JSON
weights). 'sklearn-joblib' is recognised but refused unless the operator
explicitly sets ALLOW_PICKLE_MODELS=true for a fully-trusted source —
pickle is code execution and is off by default.
"""
import json
from pathlib import Path

REQUIRED_FILES = ['metadata.json', 'schema.json', 'requirements.txt', 'README.md']
ALLOWED_FRAMEWORKS = {'json-linear', 'sklearn-joblib'}


class PackageError(ValueError):
    pass


def _load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        raise PackageError(f'invalid JSON in {path.name}: {exc}') from exc


def validate_package(pkg_dir: str | Path) -> dict:
    """Validate a package directory against the contract. Returns metadata dict."""
    root = Path(pkg_dir)
    if not root.is_dir():
        raise PackageError(f'not a directory: {root}')

    for name in REQUIRED_FILES:
        if not (root / name).is_file():
            raise PackageError(f'missing required file: {name}')

    meta = _load_json(root / 'metadata.json')
    schema = _load_json(root / 'schema.json')

    for field in ['id', 'name', 'version', 'task', 'framework', 'description']:
        if not meta.get(field):
            raise PackageError(f'metadata.json missing field: {field}')

    fw = meta['framework']
    if fw not in ALLOWED_FRAMEWORKS:
        raise PackageError(
            f"framework '{fw}' not in allowed list {sorted(ALLOWED_FRAMEWORKS)}")

    if not meta.get('source_repo'):
        raise PackageError('metadata.json missing provenance: source_repo')
    if not meta.get('license'):
        raise PackageError('metadata.json missing field: license')

    if not schema.get('inputs') or not schema.get('outputs'):
        raise PackageError('schema.json must define inputs[] and outputs[]')
    for var in schema['inputs']:
        for field in ['name', 'type']:
            if field not in var:
                raise PackageError(f'schema input missing {field}: {var}')

    model_files = list((root / 'model').glob('*')) if (root / 'model').is_dir() else []
    if not model_files:
        raise PackageError('model/ directory has no artifact')
    meta['_artifact'] = model_files[0].name
    return meta
