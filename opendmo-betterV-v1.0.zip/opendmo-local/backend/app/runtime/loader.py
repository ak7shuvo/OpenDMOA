"""Artifact loaders — whitelisted formats only."""
import json
from pathlib import Path
from .package_contract import PackageError


class LinearModel:
    """y = bias + sum(coef_i * x_i) with optional per-input transforms.

    Pure-math loader for 'json-linear' packages. Deterministic and safe:
    the artifact is data, never code.
    """

    def __init__(self, artifact: dict):
        self.bias = float(artifact.get('bias', 0.0))
        self.coefficients = {k: float(v) for k, v in artifact.get('coefficients', {}).items()}
        self.clip_negative = bool(artifact.get('clip_negative', True))

    def predict(self, inputs: dict[str, float]) -> dict[str, float]:
        y = self.bias + sum(self.coefficients.get(k, 0.0) * float(inputs.get(k, 0.0))
                            for k in self.coefficients)
        if self.clip_negative:
            y = max(y, 0.0)
        return {'prediction': round(y, 2)}


def load_model(pkg_dir: str | Path, framework: str, artifact_name: str, allow_pickle: bool = False):
    path = Path(pkg_dir) / 'model' / artifact_name
    if framework == 'json-linear':
        return LinearModel(json.loads(path.read_text(encoding='utf-8')))
    if framework == 'sklearn-joblib':
        if not allow_pickle:
            raise PackageError(
                'sklearn-joblib artifacts are disabled by default (pickle = code '
                'execution). Set ALLOW_PICKLE_MODELS=true only for fully trusted sources.')
        import joblib  # optional dependency, imported lazily
        return joblib.load(path)
    raise PackageError(f'no loader for framework: {framework}')
