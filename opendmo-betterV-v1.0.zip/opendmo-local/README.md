# OpenDMO — Local-First DMO Research, Analytics & Model Runtime

OpenDMO is a **local-first** research workstation for destination researchers and DMOs.
A researcher chooses a destination, enters/imports data, picks a calculation or ML model,
runs it locally, and inspects the full provenance of every result. Core research data
never leaves the machine by default.

## Layout
- `frontend/` — Next.js 15 + TypeScript + Tailwind Mission Control (four analytical cores,
  GIS panel, monitoring strip, intel panel) plus Operations (Destination, Data Operations,
  Model Lab, GIS) and Research/System (Model Registry, Dataset Registry, Methodology Registry).
- `backend/` — FastAPI: validation, persistence, calculation engine, model registry,
  model runtime, provenance. No business logic in React.
- `database/schema.sql` — PostgreSQL + PostGIS reference DDL (SQLite works for zero-setup dev).
- `model_packages/` (inside `backend/`) — bundled, clearly-labelled DEMO model package.

## Run locally
Terminal 1: `cd backend && pip install -r requirements.txt && cp .env.example .env && uvicorn app.main:app --port 8000`
Terminal 2: `cd frontend && npm install && npm run dev` → http://localhost:3000

The frontend runs fully with the backend offline — it switches to clearly-labelled DEMO
fixtures. Set `NEXT_PUBLIC_OPENDMO_API` to point at a different backend host.

## Quality gates
- `cd frontend && npm run typecheck && npm run lint && npm run build`
- `cd backend && python -m compileall app`

## Documentation
See `docs/`: LOCAL-FIRST, DATABASE, DATA-OPERATIONS, CALCULATIONS, MODELS (package
contract + GitHub install + provenance), API, PRIVACY. Design contract: `frontend/CONTRACT.md`.
Every dataset, model and result remains traceable: docs/PROVENANCE.md.
