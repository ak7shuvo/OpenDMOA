# Model Runtime — package contract, GitHub install, provenance

## Model package contract
```
model-package/
├── model/              artifact file(s), e.g. model.json
├── metadata.json       id, name, version, task, framework, description,
│                       source_repo, source_ref, license, training_data,
│                       expected_units, evaluation
├── schema.json         inputs[] / outputs[]: name, type, unit, min, max, required
├── requirements.txt    declared deps (informational — NEVER auto-installed)
└── README.md
```

## Security rules
- The runtime **never imports or executes package code** — install-time or run-time.
- Only whitelisted artifact formats load. Today: `json-linear` (pure JSON weights).
  `sklearn-joblib` (pickle) is **refused by default** because pickle is code execution;
  it requires the operator to set `ALLOW_PICKLE_MODELS=true` for a fully trusted source.
- `requirements.txt` is never auto-installed.

## GitHub installation (Model Lab → INSTALL / UPDATE)
GitHub repo → download zipball → validate against contract → read metadata → register →
store locally under `MODEL_STORE` → load → RUN. Any contract violation rejects the
package before registration.

## Provenance (docs/PROVENANCE.md)
Every `model_runs` record stores: model id + version, destination, exact inputs, linked
dataset + version, derived variables, outputs, execution timestamp, runtime status,
source repository, methodology version, data quality, optional evaluation metrics. Every
result answers: what data, what variables, what formula/model, what version, when, what
data quality.

The bundled `demo-tourism-demand` v1.0.0 model is clearly labelled: synthetic
coefficients, no real training data, for exercising the workflow only.
