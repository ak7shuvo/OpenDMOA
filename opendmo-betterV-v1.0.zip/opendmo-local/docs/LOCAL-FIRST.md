# Local-First Architecture

```
Frontend (Next.js — interface only, no business logic)
        ↓  lib/api/client.ts  (only transport; demo fallback when offline)
Local API (FastAPI — validation, persistence, calculations, model registry, provenance)
        ↓
Data / Calculation / Model services
        ↓
Local PostgreSQL + PostGIS   (SQLite file for zero-setup development)
        ↓
Local ML model runtime       (whitelisted artifact formats only)
```

Principles:
1. Core research data stays local by default. No cloud database, no telemetry.
2. Internet access is used only for: downloading/updating model packages from approved
   GitHub repositories; optional external data ingestion; future opt-in remote sync.
3. The analytical workflow (destination → data → variables → model/calculation → output
   → interpretation) works fully offline.

## Network / location behaviour (see also docs/PRIVACY.md)
- Browser/network location is **optional**, permission-gated, approximate-only, and is
  **never transmitted externally by default**.
- The researcher-selected destination is the authoritative analytical context for every
  core, panel, data-entry form and model run.
- Demo/synthetic data is always labelled; schematic GIS is labelled as not-live.
