# Calculation Engine

Registry: `backend/app/calculations/` — pure, data-in/data-out functions registered in
`__init__.py`, callable only via the API. No equation exists in any React component.

| id | version | inputs |
|---|---|---|
| growth.rate | 1.0.0 | value_current, value_previous |
| growth.cagr | 1.0.0 | value_begin, value_end, years |
| ratio.occupancy_rate | 1.0.0 | rooms_sold, rooms_available |
| ratio.waste_per_visitor | 1.0.0 | waste_kg, visitors |
| ratio.revenue_per_visitor | 1.0.0 | revenue, visitors |
| ratio.visitor_density | 1.0.0 | visitors, area_km2 |
| pressure.tourism_index | 1.1.0 | visitors, capacity, occupancy_rate |
| capacity.utilisation | 1.0.0 | visitors, capacity |
| sustainability.screen | 1.0.0 | waste_per_visitor_kg, revenue_per_visitor |

Every calculation declares: id, name, version, category, inputs, formula, method,
reference, weights. Established mathematical/domain formulas are used where justified
(percentage change, CAGR, standard occupancy). Custom OpenDMO indices document their
methodology, formula, variables, weights, reference and version, and are **screening
indicators, not certifications or carrying-capacity determinations**.

Every execution writes a `calculation_runs` row (inputs, outputs, dataset link, data
quality, timestamp) — see docs/PROVENANCE.md.
