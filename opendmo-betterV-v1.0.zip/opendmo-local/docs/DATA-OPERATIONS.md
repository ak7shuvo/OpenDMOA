# Data Operations

Workflow: **create dataset → enter observations → import → validate → quality → versioned registry.**

- Datasets are defined by metadata-driven `variable_defs`
  (name / label / unit / type / min / max / required / source). The manual entry form is
  generated from these definitions, so datasets define their own variables — nothing is
  hard-coded.
- Import formats: CSV (`period,variable,value[,unit]`) or JSON
  (`{"observations":[{"period","variable","value","unit"?}]}`). Originals stay local.
- Validation computes data-quality indicators: observation count, completeness %,
  quality flags (ok / estimated / missing / outlier), missing defined variables, and a
  0–100 quality score (high ≥ 90, moderate ≥ 60, low below).
- Destination-specific: every dataset belongs to one of the four pilot destinations and
  follows the global destination selector.

## Dataset contract
A dataset = `{ id, destination_id, name, version, status (draft|validated|archived),
variable_defs[], provenance{} }` plus observations `{ period, variable, value, unit,
quality_flag }` unique on (dataset, period, variable).

## Demo vs research data
The frontend bundles **synthetic demo fixtures** (always badged `DEMO MODE`) used only
when the local API is unreachable, so Mission Control stays functional. Research data
enters only through Data Operations into the local database. The same analytical
interfaces consume demo data, local research data, or imported datasets.
