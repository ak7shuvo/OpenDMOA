# Data Privacy & Network / Location Behaviour

- Research data is stored only in the local database (PostgreSQL/SQLite) and local file
  stores (`MODEL_STORE`, `DATASET_STORE`). Nothing is transmitted externally by default.
- The only outbound network call the backend makes is downloading model packages from a
  repository URL the researcher explicitly provides, plus optional external ingestion if
  added later. Remote sync is a future, explicitly enabled feature.
- `GITHUB_TOKEN` (optional) is used solely to raise GitHub rate limits for model downloads.
- Browser/network geolocation: optional, requested only with permission, approximate,
  used only as local context, never silently tracked, never transmitted externally by
  default. The researcher-selected destination remains the authoritative context.
- Demo/synthetic data bundled with the frontend contains no personal data.
