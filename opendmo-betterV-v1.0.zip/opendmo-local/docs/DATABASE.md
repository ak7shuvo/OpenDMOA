# Local Database

`database/schema.sql` is the canonical PostgreSQL + PostGIS DDL for:
`destinations`, `datasets`, `observations`, `models`, `model_versions` (composite key
id+version), `model_runs`, `calculations`, `calculation_versions` (composite key),
`calculation_runs`, `gis_layers`.

- `gis_layers.geometry` is native `geometry(Geometry, 4326)` with a GIST index; the
  portable fallback stores WKT/GeoJSON text.
- The SQLAlchemy models in `backend/app/db_models.py` auto-create an equivalent schema
  on startup (`Base.metadata.create_all`).
- Zero-setup default: `DATABASE_URL=sqlite:///./opendmo.db`. For the full target
  architecture run a local PostgreSQL with the PostGIS extension and point
  `DATABASE_URL` at it (see `backend/.env.example`).
- Datasets are versioned (unique destination × name × version); archived datasets are
  immutable. Model and calculation runs are append-only provenance records.
