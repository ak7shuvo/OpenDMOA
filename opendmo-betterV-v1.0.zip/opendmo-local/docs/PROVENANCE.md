# Provenance / Traceability

Every important result (model run, calculation run) exposes:

```
RESULT      <outputs>
INPUTS      <exact X values>
METHOD      calculation id+version  OR  model id+version + source repo
DATASET     dataset id + version (or "manual inputs")
CALCULATED  UTC timestamp
QUALITY     dataset quality score / level
```

Implementation: `backend/app/services/provenance.py` assembles this from `model_runs` /
`calculation_runs` (+ linked `datasets` row). The frontend renders it unchanged in the
`ProvenanceBlock` component. Both run tables are append-only; nothing is overwritten.
