# API

Base URL: `http://localhost:8000` (configure via `NEXT_PUBLIC_OPENDMO_API`).

| Method | Path | Purpose |
|---|---|---|
| GET | /api/health | backend + database status |
| GET | /api/meta | local-first / network / location policy statement |
| GET | /api/destinations, /api/destinations/{id} | pilot destinations |
| GET/POST | /api/datasets | list / create (auto version bump) |
| GET | /api/datasets/{id} | dataset detail |
| GET/POST | /api/datasets/{id}/observations | list / insert batch |
| POST | /api/datasets/{id}/import | CSV/JSON paste import |
| POST | /api/datasets/{id}/upload | file import (multipart) |
| POST | /api/datasets/{id}/validate | run quality checks → status validated |
| GET | /api/datasets/{id}/quality | quality indicators |
| POST | /api/datasets/{id}/archive | immutable archive |
| GET | /api/calculations | calculation registry |
| POST | /api/calculations/run | execute + provenance |
| GET | /api/calculations/runs | run history |
| GET | /api/models | installed models |
| GET | /api/models/available | approved GitHub repos |
| GET | /api/models/{id} | model metadata |
| POST | /api/models/install | download + validate + register from GitHub |
| POST | /api/models/register-local | register a local package dir |
| POST | /api/models/{id}/status | enable / disable |
| POST | /api/models/run | execute locally + provenance |
| GET | /api/models/runs | run history |
