/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // For an offline / air-gapped static build, uncomment the next line and
  // run `npm run build` — the site is emitted to ./out (see README).
  // output: 'export',
};
export default nextConfig;
