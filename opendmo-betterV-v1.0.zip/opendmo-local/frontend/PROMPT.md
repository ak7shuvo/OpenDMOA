# OpenDMO — Build Prompt for Opus 5.5

Paste everything below into Opus 5.5 (or Claude Code) along with the three
attached files: `index.html` (current prototype), `CONTRACT.md` (product/
design rules), and `ARCHITECTURE.md` (technical plan). All three are part of
this same zip.

---

```
You are completing OpenDMO — Destination Management, Observatory &
Analytical Platform — an open-source landscape mission-control / research
command center for tourism, climate, and policy researchers working on
Sylhet and the Chittagong Hill Tracts (Bangladesh). A working visual
prototype (single-file index.html, vanilla JS, no framework) already
exists and is attached. Two governing documents are also attached:

- CONTRACT.md — the fixed product scope, information architecture, the
  four core modules, pilot locations, and the visual design system. Treat
  this as non-negotiable unless I explicitly tell you to change it.
- ARCHITECTURE.md — the current prototype structure, the recommended
  Next.js + TypeScript + Tailwind migration plan, proposed folder
  structure, shared state shape, and typed data-model shape.

Read both attached documents fully before planning. Think deeply and plan
the full architecture before writing any code — use extended thinking to
reason through data modeling, state management, and module scope before
implementation.

============================================================
1. WHAT ALREADY EXISTS (do not redesign — extend)
============================================================
index.html (attached) implements:
- Collapsible left sidebar with the 4 core modules and their submodules
- Top monitoring zone: location selector, observation year, data
  freshness, live clock, 6 KPI signal cells with sparklines, scrolling
  alert ticker
- Bottom-left: GIS panel — simulated map canvas, 4 location markers,
  base-layer switch, 6 layer toggles, time slider (2015–2030), legend,
  coordinate readout
- Bottom-right: Intelligence panel — status, risk, tourism/economic data,
  alerts, analytical summary, recent events, forecast, fully keyed per
  location
- Visual system exactly as specified in CONTRACT.md §5 — preserve these
  tokens precisely, do not soften them toward a generic dashboard look

============================================================
2. WHAT "COMPLETE" MEANS
============================================================
Build out all four cores for real, per CONTRACT.md §3 and §7. Right now
only Observatory-style KPI cards exist; switching core must not just
relabel the same 6 cards — each of the following needs its own dedicated,
functional view:

01 Destination Observatory — Visitor Flow, Site Condition, Community
   Sentiment, Asset Registry
02 Climate & Risk — Weather Observations, Flood & Landslide Risk,
   Ecosystem Stress, Early Warning
03 Future & Economy — Revenue Signals, Scenario Modelling, Infrastructure
   Pipeline, Growth Forecast
04 Research & Policy Lab — Dataset Explorer, Policy Briefs, VR/AR Field
   Visualisation (clearly labeled future capability, mockup only, not
   functional), Publication Queue

GIS stays the shared spatial layer underneath all four, per CONTRACT.md
§1–2 — clicking a location updates whichever core is active, correctly.

============================================================
3. TECHNICAL ARCHITECTURE
============================================================
Follow ARCHITECTURE.md §2's recommendation: migrate to Next.js + 
TypeScript + Tailwind, using the folder structure, shared state shape, and
typed data-model shape it proposes, unless you have a specific reason to
deviate — if so, state that reason in one line before proceeding.

Data layer: build a typed mock data layer matching ARCHITECTURE.md's
Signal shape (value + history + status + source + confidence +
lastUpdated) so every field maps cleanly to a future real API/database.
Never claim live API connectivity; keep DEMO/SIMULATED labeling and
timestamps/source/confidence indicators throughout, per CONTRACT.md §6.

State management: a single shared context per ARCHITECTURE.md §2 (active
core, location, year, layers, base layer) drives both the GIS panel and
whichever core panel is active.

============================================================
4. NON-NEGOTIABLE CONSTRAINTS
============================================================
All of CONTRACT.md applies. In particular:
- No marketing site / landing page / SaaS dashboard tropes
- No neon/cyberpunk, no giant typography, no gradient decoration, no fake 3D
- Dense information hierarchy over whitespace-heavy layouts
- IA stays: LOCATION → TIME → OBSERVATION → CHANGE → RISK → FORECAST →
  SCENARIO → DECISION
- GIS is shared across all four cores, not a fifth core
- VR/AR lives inside Research & Policy Lab only, never a standalone core,
  never presented as functional today
- All data is clearly DEMO/SIMULATED — never implies live connectivity
- Four pilot locations only (Jaflong, Ratargul, Sajek, Bandarban) unless I
  say otherwise

============================================================
5. DELIVERABLES
============================================================
1. A brief architecture plan (your reasoning, confirming or deviating from
   ARCHITECTURE.md §2) before any code
2. The complete, working implementation
3. A README.md covering: how to run it, what's mock vs. real-ready per
   ARCHITECTURE.md §3 checklist item 7, and what a real deployment would
   still need (actual data sources, auth, hosting, a real GIS tile
   provider) — be explicit this is a research prototype, not a production
   system, unless told otherwise
4. Preserve the exact visual identity from CONTRACT.md §5 throughout —
   port colors, type scale, spacing, and the GIS/monitoring/intel
   three-zone layout precisely, don't reinterpret it

Work through the architecture decision and full data model in your
reasoning before writing implementation code. If any requirement above is
ambiguous, state your assumption in one line and proceed — don't stop to
ask.
```


---

## v0.6.0 handoff note

OpenDMO is now a local-first DMO research, analytics & model runtime. The four-core Mission Control, GIS, monitoring and visual identity are preserved unchanged. Added: Operations (Destination, Data Operations, Model Lab, GIS) and Research/System (Model Registry, Dataset Registry, Methodology/Calculation Registry) sections; a FastAPI backend with a calculation engine, a safe model runtime (whitelisted artifact formats, no arbitrary code execution), GitHub model installation, dataset versioning/validation, and full run provenance. Bundled demo model is clearly labelled synthetic. Docs live in `../docs` relative to this file (`docs/` at repo root).
