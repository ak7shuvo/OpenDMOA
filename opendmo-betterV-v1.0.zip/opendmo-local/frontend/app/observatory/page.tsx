import { ObservatoryCore } from '@/components/cores/observatory/ObservatoryCore';
export default function Page() {
  return <ObservatoryCore />;
}
