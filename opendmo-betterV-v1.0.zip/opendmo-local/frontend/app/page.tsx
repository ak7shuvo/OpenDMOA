import { ObservatoryCore } from '@/components/cores/observatory/ObservatoryCore';

/** Default route → Destination Observatory (ARCHITECTURE.md §2). */
export default function Home() {
  return <ObservatoryCore />;
}
