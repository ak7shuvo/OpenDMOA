import { ClimateCore } from '@/components/cores/climate/ClimateCore';
export default function Page() {
  return <ClimateCore />;
}
