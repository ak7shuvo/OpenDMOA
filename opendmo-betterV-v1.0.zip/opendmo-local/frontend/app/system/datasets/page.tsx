import { DatasetRegistry } from '@/components/system/DatasetRegistry';

export default function Page() {
  return <DatasetRegistry />;
}
