import { MethodologyRegistry } from '@/components/system/MethodologyRegistry';

export default function Page() {
  return <MethodologyRegistry />;
}
