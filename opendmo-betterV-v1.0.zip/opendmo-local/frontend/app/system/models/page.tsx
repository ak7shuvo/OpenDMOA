import { ModelRegistry } from '@/components/system/ModelRegistry';

export default function Page() {
  return <ModelRegistry />;
}
