import { DestinationOps } from '@/components/operations/DestinationOps';

export default function Page() {
  return <DestinationOps />;
}
