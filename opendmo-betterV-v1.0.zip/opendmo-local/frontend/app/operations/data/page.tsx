import { DataOps } from '@/components/operations/DataOps';

export default function Page() {
  return <DataOps />;
}
