import { ModelLab } from '@/components/operations/ModelLab';

export default function Page() {
  return <ModelLab />;
}
