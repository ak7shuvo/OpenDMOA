import { GisOps } from '@/components/operations/GisOps';

export default function Page() {
  return <GisOps />;
}
