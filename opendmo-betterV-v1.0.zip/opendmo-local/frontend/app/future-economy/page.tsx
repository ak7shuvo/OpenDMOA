import { EconomyCore } from '@/components/cores/economy/EconomyCore';
export default function Page() {
  return <EconomyCore />;
}
