import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import './globals.css';
import { AppShell } from '@/components/AppShell';

export const metadata: Metadata = {
  title: 'OpenDMO — Destination Management, Observatory & Analytical Platform',
  description: 'Research prototype for Sylhet and the Chittagong Hill Tracts. All data is simulated.',
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#090c0a' };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
