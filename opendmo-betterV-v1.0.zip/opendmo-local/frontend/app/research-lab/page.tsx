import { LabCore } from '@/components/cores/lab/LabCore';
export default function Page() {
  return <LabCore />;
}
