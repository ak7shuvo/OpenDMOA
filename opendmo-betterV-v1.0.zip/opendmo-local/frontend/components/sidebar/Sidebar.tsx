'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { CORES } from '@/lib/data/cores';

/** Operations + Research/System sections — supporting infrastructure for the
 *  four analytical cores (local research data & model runtime). */
const OPS_NAV = [
  { href: '/operations/destination', num: 'A1', name: 'Destination' },
  { href: '/operations/data', num: 'A2', name: 'Data Operations' },
  { href: '/operations/models', num: 'A3', name: 'Model Lab' },
  { href: '/operations/gis', num: 'A4', name: 'GIS' },
];
const SYS_NAV = [
  { href: '/system/models', num: 'B1', name: 'Model Registry' },
  { href: '/system/datasets', num: 'B2', name: 'Dataset Registry' },
  { href: '/system/methodology', num: 'B3', name: 'Methodology / Calculation Registry' },
];
const inNav = (pathname: string, href: string) => pathname === href;
import { BUILD } from '@/lib/data/layers';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';

export function Sidebar() {
  const { activeCore, submodule, setSubmodule } = useOpenDMO();
  const pathname = usePathname() ?? '/';
  const router = useRouter();
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    if (window.innerWidth < 640) setCollapsed(true);
  }, []);

  return (
    <aside className={`sidebar${collapsed ? ' collapsed' : ''}`} aria-label="Core modules">
      <div className="sidebar-head">
        <button className="toggle" onClick={() => setCollapsed((c) => !c)} title="Collapse / expand" aria-expanded={!collapsed}>
          ☰
        </button>
        <div className="brand">
          <span className="brand-mark">DMO</span>
          <span className="brand-text">
            OpenDMO
            <br />
            Destination Mgmt &amp; Observatory
          </span>
        </div>
      </div>
      <nav className="cores">
        {CORES.map((core) => {
          const active = core.id === activeCore;
          return (
            <div key={core.id} className={`core-block${active ? ' active' : ''}`}>
              <Link href={core.route} className="core-head" aria-current={active ? 'page' : undefined} title={`${core.num} · ${core.name}`}>
                <span className="core-num">{core.num}</span>
                <span className="core-name">{core.name}</span>
                <span className="core-chevron">›</span>
              </Link>
              <div className="submodules">
                {core.sub.map((s) => (
                  <button
                    key={s.id}
                    className={`submodule${active && submodule[core.id] === s.id ? ' on' : ''}`}
                    onClick={() => {
                      setSubmodule(core.id, s.id);
                      if (!active) router.push(core.route);
                    }}
                  >
                    <span className="dot" />
                    <span className="truncate">{s.name}</span>
                    {s.roadmap && <span className="rm">ROADMAP</span>}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </nav>
      <nav className="ops-nav" aria-label="Operations">
        <div className="nav-group-label">OPERATIONS</div>
        {OPS_NAV.map((n) => (
          <Link key={n.href} href={n.href} className={`nav-link${inNav(pathname, n.href) ? ' active' : ''}`} aria-current={inNav(pathname, n.href) ? 'page' : undefined}>
            <span className="core-num">{n.num}</span>
            <span className="truncate">{n.name}</span>
          </Link>
        ))}
        <div className="nav-group-label">RESEARCH / SYSTEM</div>
        {SYS_NAV.map((n) => (
          <Link key={n.href} href={n.href} className={`nav-link${inNav(pathname, n.href) ? ' active' : ''}`} aria-current={inNav(pathname, n.href) ? 'page' : undefined}>
            <span className="core-num">{n.num}</span>
            <span className="truncate">{n.name}</span>
          </Link>
        ))}
      </nav>
      <div className="sidebar-foot">
        <div className="foot-row">
          <span className="status-dot" />
          <span>DEMO MODE · NO LIVE FEEDS</span>
        </div>
        <div className="foot-row small">
          <span>BUILD {BUILD} · SYNTHETIC DATA</span>
        </div>
      </div>
    </aside>
  );
}
