'use client';

import { useEffect, useMemo, useRef, useState, type MouseEvent } from 'react';
import { CORE_BY_ID } from '@/lib/data/cores';
import { LAYERS, OBSERVATION_YEAR, YEAR_MAX, YEAR_MIN } from '@/lib/data/layers';
import { LOCATIONS, LOCATION_KEYS } from '@/lib/data/locations';
import { PROJECTS, projectStage } from '@/lib/data/registry';
import { compositeStatus, fmtSignal, statusAt, valueAt } from '@/lib/data/series';
import { SPEC_BY_ID } from '@/lib/data/signals';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { rgba, statusColor, statusHex } from '@/lib/theme';
import type { BaseLayer, LayerId, LocationKey } from '@/lib/types';

/* ---------------- schematic geometry (viewBox 0–100, not to scale) ---------------- */

const RIVERS: { id: string; loc: LocationKey; d: string; name: string }[] = [
  { id: 'piyain', loc: 'jaflong', name: 'Piyain', d: 'M17,6 C19,16 21,24 22,30 S27,38 30,42' },
  { id: 'goyain', loc: 'ratargul', name: 'Goyain', d: 'M30,42 C32,44 33,45 34,46 S38,56 33,66' },
  { id: 'kassalong', loc: 'sajek', name: 'Kassalong', d: 'M72,38 C70,48 66,58 64,64 S57,76 50,82' },
  { id: 'sangu', loc: 'bandarban', name: 'Sangu', d: 'M94,62 C88,66 82,70 78,74 S66,86 54,94' },
];
const BORDER = ['M0,12 L18,15 L34,11 L52,13', 'M86,22 L88,44 L95,58 L100,62'];
const ROADS = ['M42,24 L22,30', 'M42,24 L34,46', 'M42,24 L47,48 L64,64', 'M47,48 L50,84 L78,74', 'M64,64 L78,74'];
const HUBS = [
  { name: 'SYLHET', x: 42, y: 24 },
  { name: 'KHAGRACHARI', x: 47, y: 48 },
  { name: 'CHATTOGRAM', x: 50, y: 84 },
];
const FOREST: Record<LocationKey, string> = {
  jaflong: 'M14,22 L20,20 L25,24 L24,28 L17,28 Z',
  ratargul: 'M28,44 L33,40 L40,43 L41,50 L35,53 L29,50 Z',
  sajek: 'M60,56 L68,54 L72,60 L70,67 L62,68 L58,62 Z',
  bandarban: 'M76,64 L86,62 L90,70 L86,80 L78,82 L73,74 Z',
};
const SLOPES: Partial<Record<LocationKey, string>> = {
  jaflong: 'M19,31 L24,31 L25,35 L20,36 Z',
  sajek: 'M57,62 L62,60 L63,66 L58,69 Z',
  bandarban: 'M80,66 L86,68 L84,74 L79,72 Z',
};

const LAYER_KEY: Record<LayerId, string> = {
  tourism: 'halo ∝ visitors',
  environment: 'fill ∝ forest cover',
  climate: 'rings ∝ rain anomaly',
  risk: 'flood · slope hatch',
  infrastructure: '□ planned ◧ building ■ done',
  community: '▵ survey sentiment',
};

const BASE_FILTER: Record<BaseLayer, string> = {
  satellite: 'none',
  terrain: 'sepia(0.18) saturate(1.05)',
  analytical: 'hue-rotate(20deg) saturate(1.3)',
};

export function GisPanel() {
  const { activeCore, location, setLocation, year, setYear, layers, toggleLayer, baseLayer, setBaseLayer } = useOpenDMO();
  const core = CORE_BY_ID[activeCore];
  const [grid, setGrid] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [legendOpen, setLegendOpen] = useState(true);
  useEffect(() => {
    if (window.innerWidth < 1100) setLegendOpen(false);
  }, []);
  const yearRef = useRef(year);
  yearRef.current = year;

  useEffect(() => {
    if (!playing) return;
    if (yearRef.current >= YEAR_MAX) setYear(YEAR_MIN);
    const id = setInterval(() => {
      if (yearRef.current >= YEAR_MAX) {
        setPlaying(false);
        return;
      }
      setYear(yearRef.current + 1);
    }, 700);
    return () => clearInterval(id);
  }, [playing, setYear]);

  const sel = LOCATIONS[location];
  const mapSpec = SPEC_BY_ID[core.mapSignal];

  const derived = useMemo(
    () =>
      LOCATION_KEYS.map((k) => ({
        k,
        loc: LOCATIONS[k],
        status: compositeStatus(k, year),
        visitors: valueAt('annual_visitors', k, year),
        pressure: statusAt('visitor_pressure', k, year),
        rain: valueAt('rainfall_anomaly', k, year),
        rainS: statusAt('rainfall_anomaly', k, year),
        cover: valueAt('forest_cover', k, year),
        coverS: statusAt('forest_cover', k, year),
        river: statusAt('river_stage', k, year),
        slope: valueAt('landslide_susceptibility', k, year),
        slopeS: statusAt('landslide_susceptibility', k, year),
        sent: valueAt('community_sentiment', k, year),
        sentS: statusAt('community_sentiment', k, year),
        mapV: valueAt(core.mapSignal, k, year),
        mapS: statusAt(core.mapSignal, k, year),
      })),
    [year, core.mapSignal],
  );

  const projects = useMemo(
    () => PROJECTS.map((p) => ({ p, stage: projectStage(p, year) })).filter((x) => x.stage !== null),
    [year],
  );

  const onMove = (e: MouseEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const col = Math.min(9, Math.floor(((e.clientX - r.left) / r.width) * 10));
    const row = Math.min(9, Math.floor(((e.clientY - r.top) / r.height) * 10));
    setGrid(`${'ABCDEFGHIJ'[col]}${row + 1}`);
  };

  const proj = year > OBSERVATION_YEAR;

  return (
    <div className="gis-panel" aria-label="GIS — shared spatial layer">
      <div className="gis-toolbar">
        <div className="base-layers" role="group" aria-label="Base layer">
          {(['satellite', 'terrain', 'analytical'] as BaseLayer[]).map((b) => (
            <button key={b} className={baseLayer === b ? 'active' : ''} onClick={() => setBaseLayer(b)} aria-pressed={baseLayer === b}>
              {b.toUpperCase()}
            </button>
          ))}
        </div>
        <div className="coord-readout">
          {sel.lat} · {sel.lon}
          <span className="text-faint"> · GRID {grid ?? '—'}</span>
        </div>
      </div>

      <div className={`map-canvas base-${baseLayer}`} onMouseMove={onMove} onMouseLeave={() => setGrid(null)} style={{ filter: BASE_FILTER[baseLayer] }}>
        <div className="map-grid" />
        <svg className="map-svg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden>
          <defs>
            <pattern id="hatch" width="1.6" height="1.6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
              <line x1="0" y1="0" x2="0" y2="1.6" stroke="#fff" strokeWidth="0.5" />
            </pattern>
          </defs>
          {/* base contours (prototype) */}
          <g opacity={baseLayer === 'terrain' ? 0.8 : 0.45}>
            <path d="M0,70 Q20,55 35,62 T70,50 T100,58" stroke="rgba(111,191,148,0.25)" fill="none" strokeWidth={0.3} />
            <path d="M0,80 Q25,68 40,74 T75,64 T100,70" stroke="rgba(111,191,148,0.15)" fill="none" strokeWidth={0.3} />
            <path d="M0,40 Q30,30 50,36 T100,28" stroke="rgba(111,179,199,0.15)" fill="none" strokeWidth={0.3} />
            {baseLayer === 'terrain' && (
              <>
                <path d="M50,100 Q60,70 70,62 T96,40" stroke="rgba(111,191,148,0.18)" fill="none" strokeWidth={0.3} />
                <path d="M58,100 Q66,76 78,66 T100,48" stroke="rgba(111,191,148,0.14)" fill="none" strokeWidth={0.3} />
              </>
            )}
          </g>
          {BORDER.map((d, i) => (
            <path key={i} d={d} stroke="var(--text-faint)" strokeDasharray="1 1" fill="none" strokeWidth={0.25} opacity={0.7} />
          ))}
          {RIVERS.map((r) => (
            <path key={r.id} d={r.d} stroke="rgba(111,179,199,0.35)" fill="none" strokeWidth={1.2} vectorEffect="non-scaling-stroke" />
          ))}

          {layers.environment &&
            derived.map((d) => (
              <path
                key={`f-${d.k}`}
                d={FOREST[d.k]}
                fill={rgba('#6fbf94', 0.06 + (d.cover / 100) * 0.3)}
                stroke={statusHex(d.coverS)}
                strokeOpacity={0.55}
                strokeWidth={1}
                vectorEffect="non-scaling-stroke"
              />
            ))}

          {layers.risk &&
            RIVERS.map((r) => {
              const s = derived.find((d) => d.k === r.loc)!.river;
              return (
                <path
                  key={`fl-${r.id}`}
                  d={r.d}
                  stroke={rgba(statusHex(s), s === 'risk' ? 0.35 : s === 'watch' ? 0.25 : 0.12)}
                  fill="none"
                  strokeWidth={s === 'risk' ? 14 : s === 'watch' ? 9 : 5}
                  strokeLinecap="round"
                  vectorEffect="non-scaling-stroke"
                />
              );
            })}
          {layers.risk &&
            derived.map((d) =>
              SLOPES[d.k] ? (
                <g key={`sl-${d.k}`}>
                  <path d={SLOPES[d.k]} fill="url(#hatch)" opacity={0.15 + (d.slope / 100) * 0.5} />
                  <path d={SLOPES[d.k]} fill={rgba(statusHex(d.slopeS), 0.12)} stroke={statusHex(d.slopeS)} strokeWidth={1} vectorEffect="non-scaling-stroke" />
                </g>
              ) : null,
            )}

          {layers.climate &&
            derived.map((d) => {
              const rings = Math.max(1, Math.min(4, Math.ceil(Math.abs(d.rain) / 12)));
              return (
                <g key={`c-${d.k}`}>
                  {Array.from({ length: rings }, (_, i) => (
                    <ellipse
                      key={i}
                      cx={d.loc.x}
                      cy={d.loc.y}
                      rx={4 + i * 3}
                      ry={5 + i * 3.6}
                      fill="none"
                      stroke={statusHex(d.rainS)}
                      strokeOpacity={0.45 - i * 0.08}
                      strokeDasharray="3 3"
                      strokeWidth={1}
                      vectorEffect="non-scaling-stroke"
                    />
                  ))}
                </g>
              );
            })}

          {layers.infrastructure &&
            ROADS.map((d, i) => (
              <path key={`r-${i}`} d={d} stroke="rgba(217,228,221,0.28)" fill="none" strokeWidth={1} strokeDasharray="5 2" vectorEffect="non-scaling-stroke" />
            ))}
        </svg>

        {/* hubs — context labels only */}
        {HUBS.map((h) => (
          <span key={h.name} className="map-frame-label" style={{ left: `${h.x}%`, top: `${h.y}%`, transform: 'translate(-50%,-50%)', zIndex: 3 }}>
            ◇ {h.name}
          </span>
        ))}

        {layers.tourism &&
          derived.map((d) => {
            const size = 18 + Math.sqrt(d.visitors) * 2.4;
            const hex = statusHex(d.pressure);
            return (
              <span
                key={`h-${d.k}`}
                className="map-halo"
                style={{ left: `${d.loc.x}%`, top: `${d.loc.y}%`, width: size, height: size, background: rgba(hex, 0.09), border: `1px solid ${rgba(hex, 0.35)}` }}
              />
            );
          })}

        {layers.climate &&
          derived.map((d) => (
            <span key={`cl-${d.k}`} className="map-frame-label" style={{ left: `calc(${d.loc.x}% + 8px)`, top: `calc(${d.loc.y}% - 22px)`, color: statusColor(d.rainS), zIndex: 4 }}>
              {d.rain >= 0 ? '+' : ''}
              {d.rain}% RAIN
            </span>
          ))}

        {layers.community &&
          derived.map((d) =>
            [0, 1, 2].map((i) => {
              const a = [Math.PI, -2.45, 2.45][i];
              return (
                <span
                  key={`cm-${d.k}-${i}`}
                  className="absolute font-mono text-9"
                  style={{ left: `calc(${d.loc.x}% + ${Math.cos(a) * 30}px)`, top: `calc(${d.loc.y}% + ${Math.sin(a) * 24}px)`, transform: 'translate(-50%,-50%)', color: statusColor(d.sentS), zIndex: 4 }}
                  title={`${d.loc.name} survey cluster — sentiment ${d.sent}`}
                >
                  ▵{i === 0 ? d.sent : ''}
                </span>
              );
            }),
          )}

        {layers.infrastructure &&
          projects.map(({ p, stage }) => {
            const l = LOCATIONS[p.location];
            return (
              <span
                key={p.id}
                className="map-proj"
                title={`${p.id} ${p.name} — ${stage} (${p.start}–${p.end})`}
                style={{
                  left: `${l.x + p.dx}%`,
                  top: `${l.y + p.dy}%`,
                  borderColor: 'var(--cyan)',
                  background: stage === 'complete' ? 'var(--cyan)' : stage === 'construction' ? 'linear-gradient(90deg, var(--cyan) 50%, transparent 50%)' : 'transparent',
                }}
              />
            );
          })}

        {derived.map((d) => (
          <button
            key={d.k}
            className={`map-marker ${d.status === 'ok' ? '' : d.status}${location === d.k ? ' selected' : ''}`}
            style={{ left: `${d.loc.x}%`, top: `${d.loc.y}%` }}
            onClick={() => setLocation(d.k)}
            aria-label={`${d.loc.name} — ${d.status}`}
            aria-pressed={location === d.k}
          >
            <span className="ring" />
            <span className="map-marker-label">{d.loc.short === 'Ratargul' ? 'Ratargul' : d.loc.short}</span>
            <span className="map-marker-val" style={{ color: statusColor(d.mapS) }}>
              {fmtSignal(core.mapSignal, d.mapV)} {mapSpec.unit}
            </span>
          </button>
        ))}

        <div className="map-scan" />
        <div className="map-frame-label mf-tl">SECTOR · SYLHET / CHT</div>
        <div className="map-frame-label mf-tr">SCHEMATIC · NOT TO SCALE</div>
        <div className="map-frame-label mf-bl" style={{ left: 'auto', right: 10, bottom: 22 }}>
          {baseLayer.toUpperCase()} · DEMO TILES
        </div>
        <div className="map-frame-label mf-br" style={{ color: proj ? 'var(--amber)' : 'var(--cyan)' }}>
          {year}
          {proj ? ' · PROJECTED' : ''}
        </div>

        <div className="map-legend">
          <button className="lg-toggle" onClick={() => setLegendOpen((o) => !o)} aria-expanded={legendOpen}>
            <span>SIGNAL LEGEND</span>
            <span>{legendOpen ? '▾' : '▸'}</span>
          </button>
          {legendOpen && (
            <>
              <div className="lg-row"><span className="dot" style={{ background: 'var(--green)' }} />Nominal</div>
              <div className="lg-row"><span className="dot" style={{ background: 'var(--amber)' }} />Elevated watch</div>
              <div className="lg-row"><span className="dot" style={{ background: 'var(--red)' }} />Active risk</div>
              <div className="lg-sep" />
              <div className="text-faint">VALUE · {mapSpec.label}</div>
              {LAYERS.filter((l) => layers[l.id]).map((l) => (
                <div key={l.id} className="mt-[2px] truncate text-faint" title={l.describes}>
                  <span className="text-dim">▪ {l.name}</span> {LAYER_KEY[l.id]}
                </div>
              ))}
            </>
          )}
        </div>
      </div>

      <div className="layer-controls" role="group" aria-label="Thematic layers">
        {LAYERS.map((l) => (
          <button key={l.id} className={`layer-btn${layers[l.id] ? ' on' : ''}`} onClick={() => toggleLayer(l.id)} aria-pressed={layers[l.id]} title={l.describes}>
            <span className="sw" />
            {l.name.toUpperCase()}
          </button>
        ))}
      </div>

      <div className="time-slider-wrap">
        <div className="flex items-center gap-2">
          <button className={`ctl${playing ? ' on' : ''}`} onClick={() => setPlaying((p) => !p)} aria-label={playing ? 'Pause timeline' : 'Play timeline'}>
            {playing ? '❚❚' : '▶'}
          </button>
          <input
            type="range"
            className={`time-slider${proj ? ' proj' : ''}`}
            min={YEAR_MIN}
            max={YEAR_MAX}
            step={1}
            value={year}
            onChange={(e) => setYear(parseInt(e.target.value, 10))}
            aria-label="Observation year"
          />
          <button className="ctl" onClick={() => setYear(OBSERVATION_YEAR)} disabled={year === OBSERVATION_YEAR} title="Back to observation year">
            NOW
          </button>
        </div>
        <div className="slider-labels pl-[34px] pr-[44px]">
          <span>2015</span>
          <span>2020</span>
          <span>2026 · NOW</span>
          <span>2030 · PROJECTED</span>
        </div>
      </div>
    </div>
  );
}
