'use client';

import type { ReactNode } from 'react';
import { OpenDMOProvider } from '@/lib/state/OpenDMOContext';
import { Sidebar } from './sidebar/Sidebar';
import { MonitoringStrip } from './monitoring/MonitoringStrip';
import { GisPanel } from './gis/GisPanel';
import { IntelPanel } from './intel/IntelPanel';

/** Persistent three-zone shell: sidebar · monitoring strip · (GIS | core view | intel). */
export function AppShell({ children }: { children: ReactNode }) {
  return (
    <OpenDMOProvider>
      <div className="app">
        <Sidebar />
        <main className="main">
          <MonitoringStrip />
          <section className="workspace">
            <GisPanel />
            {children}
            <IntelPanel />
          </section>
        </main>
      </div>
    </OpenDMOProvider>
  );
}
