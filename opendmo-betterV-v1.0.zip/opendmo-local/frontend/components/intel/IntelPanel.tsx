'use client';

import { useState } from 'react';
import { DATASET_VERSION, OBSERVATION_YEAR } from '@/lib/data/layers';
import { LOCATIONS } from '@/lib/data/locations';
import { compositeStatus, fmtSignal, getSignal, valueAt } from '@/lib/data/series';
import { warningsFor } from '@/lib/data/warnings';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { Badge } from '../shared/ui';

export function IntelPanel() {
  const { location, year } = useOpenDMO();
  const [collapsed, setCollapsed] = useState(false);
  const loc = LOCATIONS[location];

  if (collapsed) {
    return (
      <aside className="intel-panel collapsed" aria-label="Intelligence panel (collapsed)">
        <button className="intel-rail" onClick={() => setCollapsed(false)} title="Expand intelligence panel">
          ◂ INTEL · {loc.short.toUpperCase()}
        </button>
      </aside>
    );
  }

  const status = compositeStatus(location, year);
  const river = getSignal('river_stage', location, year);
  const riverPrev = valueAt('river_stage', location, Math.max(2015, year - 1));
  const visitors = getSignal('annual_visitors', location, year);
  const pressure = getSignal('visitor_pressure', location, year);
  const revenue = getSignal('revenue_index', location, year);
  const employment = getSignal('employment_index', location, year);
  const warnings = warningsFor(location, year);
  const narrativeYear = year !== OBSERVATION_YEAR;
  const v2030 = valueAt('annual_visitors', location, 2030);
  const p2030 = valueAt('visitor_pressure', location, 2030);
  const s2030 = compositeStatus(location, 2030);
  const d = river.value - riverPrev;

  return (
    <aside className="intel-panel" aria-label="Intelligence panel">
      <div className="intel-header">
        <h2>{loc.name}</h2>
        <span className="coord">{loc.region}</span>
        <button className="ctl ml-auto" onClick={() => setCollapsed(true)} title="Collapse intelligence panel" aria-label="Collapse intelligence panel">
          ▸
        </button>
      </div>

      <div className="intel-sub">STATUS · {year}{year > OBSERVATION_YEAR ? ' PROJ.' : ''}</div>
      <div className="intel-row">
        <span className="k">Risk status</span>
        <span className="v"><Badge status={status} /></span>
      </div>
      <div className="intel-row">
        <span className="k">River / hydrology</span>
        <span className="v">
          {fmtSignal('river_stage', river.value)} m
          <span className="text-faint">({d >= 0 ? '+' : ''}{d.toFixed(1)} m / yr)</span>
          <Badge status={river.status}>{river.status.toUpperCase()}</Badge>
        </span>
      </div>
      <div className="intel-row">
        <span className="k">Gauge</span>
        <span className="v prose">{loc.gauge}</span>
      </div>
      <div className="intel-row">
        <span className="k">Environmental change</span>
        <span className="v prose">{loc.envChange}</span>
      </div>

      <div className="intel-sub">TOURISM &amp; ECONOMY</div>
      <div className="intel-row">
        <span className="k">Annual visitors</span>
        <span className="v">{fmtSignal('annual_visitors', visitors.value)}k <Badge status={pressure.status}>PI {fmtSignal('visitor_pressure', pressure.value)}</Badge></span>
      </div>
      <div className="intel-row">
        <span className="k">Tourism pressure</span>
        <span className="v prose">{loc.tourismPressure}</span>
      </div>
      <div className="intel-row">
        <span className="k">Economic signal</span>
        <span className="v">
          REV {fmtSignal('revenue_index', revenue.value)} · EMP {fmtSignal('employment_index', employment.value)}
          <Badge status={revenue.status}>{revenue.status.toUpperCase()}</Badge>
        </span>
      </div>

      <div className="intel-sub">ALERTS &amp; DATA STREAMS</div>
      {warnings.length === 0 ? (
        <div className="intel-alert ok">
          <span className="ai">✓</span>
          <span>No rule-derived alerts for this sector in {year}.</span>
        </div>
      ) : (
        warnings.slice(0, 4).map((w) => (
          <div key={w.id} className={`intel-alert${w.level === 'risk' ? ' risk' : ''}`}>
            <span className="ai">{w.level === 'risk' ? '⚠' : '△'}</span>
            <span>
              {w.title}
              <span className="block font-mono text-9 text-faint">{w.detail}</span>
            </span>
          </div>
        ))
      )}
      {warnings.length > 4 && <div className="font-mono text-9 text-faint">+{warnings.length - 4} more in Climate &amp; Risk / Early Warning</div>}

      <div className="intel-sub">ANALYTICAL SUMMARY</div>
      {narrativeYear && <div className="mb-1 font-mono text-9 text-amber">NARRATIVE AS OF {OBSERVATION_YEAR} OBSERVATION · FIGURES ABOVE RE-DERIVED FOR {year}</div>}
      <p className="intel-summary">{loc.summary}</p>

      <div className="intel-sub">RECENT EVENTS · {OBSERVATION_YEAR}</div>
      <ul className="intel-events">
        {loc.events.map((e) => (
          <li key={e.date + e.text}>
            <span className="ev-date">{e.date}</span>
            <span>{e.text}</span>
          </li>
        ))}
      </ul>

      <div className="intel-sub">FORECAST / SCENARIO</div>
      <p className="intel-summary" style={{ color: 'var(--cyan)' }}>{loc.forecast}</p>
      <div className="intel-row">
        <span className="k">2030 trend projection</span>
        <span className="v">
          {fmtSignal('annual_visitors', v2030)}k · PI {fmtSignal('visitor_pressure', p2030)} <Badge status={s2030}>{s2030.toUpperCase()}</Badge>
        </span>
      </div>

      <div className="intel-footer">
        DEMO / SIMULATED DATA · SOURCE: {DATASET_VERSION} · Confidence indicators are illustrative and not derived from live sensors. Alerts are
        generated by threshold rules on synthetic series, not issued by any agency.
      </div>
    </aside>
  );
}
