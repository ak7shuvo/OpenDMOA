'use client';

import { LOCATIONS, LOCATION_KEYS } from '@/lib/data/locations';
import { MONTHS, NOTABLE_ASSETS, PROJECTS, RAIN_NORMAL, SNAPSHOT_MONTH, projectStage } from '@/lib/data/registry';
import { YEARS, deltaAt, fmtSignal, getSignal, noise, statusAt, valueAt } from '@/lib/data/series';
import { SPEC_BY_ID } from '@/lib/data/signals';
import { OBSERVATION_YEAR } from '@/lib/data/layers';
import { WARNING_RULES, warningsFor } from '@/lib/data/warnings';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { statusColor, statusShort } from '@/lib/theme';
import type { LocationKey, Status } from '@/lib/types';
import { BarChart, HBar } from '../../charts/BarChart';
import { Legend, LineChart } from '../../charts/LineChart';
import { Badge, ConfBadge, Metric, MetricRow, Note, Section, SignalMeta } from '../../shared/ui';
import { CoreFrame } from '../CoreFrame';

export function ClimateCore() {
  return (
    <CoreFrame
      core="climate"
      views={{
        weather: Weather,
        'flood-landslide': FloodLandslide,
        ecosystem: Ecosystem,
        'early-warning': EarlyWarning,
      }}
    />
  );
}

function monthlyRain(loc: LocationKey, year: number) {
  const anomaly = valueAt('rainfall_anomaly', loc, year) / 100;
  return RAIN_NORMAL[loc].map((n, i) => Math.max(0, n * (1 + anomaly * (i >= 4 && i <= 8 ? 1.2 : 0.5)) * (1 + noise(`rain|${loc}|${year}|${i}`) * 0.12)));
}

/* ------------------------------ 02.1 Weather Observations ------------------------------ */

function Weather() {
  const { location, year } = useOpenDMO();
  const rain = getSignal('rainfall_anomaly', location, year);
  const temp = getSignal('temp_anomaly', location, year);
  const river = getSignal('river_stage', location, year);
  const sensors = valueAt('sensors_reporting', location, year);
  const obs = monthlyRain(location, year);
  const normal = RAIN_NORMAL[location];
  const lastObs = year === OBSERVATION_YEAR ? SNAPSHOT_MONTH : 11;
  const ytd = obs.slice(0, lastObs + 1).reduce((a, b) => a + b, 0);
  const ytdN = normal.slice(0, lastObs + 1).reduce((a, b) => a + b, 0);
  const wettest = obs.slice(0, lastObs + 1).indexOf(Math.max(...obs.slice(0, lastObs + 1)));
  const code = location.slice(0, 2).toUpperCase();
  const stations = [
    { id: `SYN-${code}-01`, kind: 'Rain gauge', reading: `${obs[lastObs].toFixed(0)} mm (${MONTHS[lastObs]})` },
    { id: `SYN-${code}-02`, kind: `River gauge · ${LOCATIONS[location].gauge}`, reading: `${fmtSignal('river_stage', river.value)} m peak` },
    { id: `SYN-${code}-03`, kind: 'Automatic weather station', reading: `${temp.value >= 0 ? '+' : ''}${temp.value.toFixed(1)} °C anomaly` },
    { id: `SYN-${code}-04`, kind: 'Soil-moisture probe', reading: `${Math.round(40 + rain.value * 0.6)} % vol.` },
  ];

  return (
    <div>
      <MetricRow cols={4}>
        <Metric s={rain} />
        <Metric s={temp} />
        <Metric s={river} />
        <div className="flex flex-col gap-1 bg-panel px-3 py-2">
          <span className="text-10 tracking-[.05em] text-faint">Year-to-date Rainfall</span>
          <span className="font-mono text-15 text-text">{ytd.toFixed(0)} <span className="text-10 text-faint">mm</span></span>
          <span className="font-mono text-9 text-faint">{((ytd / ytdN - 1) * 100).toFixed(0)}% VS NORMAL · WETTEST {MONTHS[wettest]}</span>
        </div>
      </MetricRow>

      <Section right={<SignalMeta s={rain} />}>MONTHLY RAINFALL · {year} · mm</Section>
      <BarChart
        ariaLabel="Monthly rainfall versus normal"
        bars={obs.map((v, i) => ({ label: MONTHS[i], value: i > lastObs ? null : v, color: v > normal[i] * 1.3 ? 'var(--amber)' : 'var(--cyan)' }))}
        line={normal}
        lineColor="var(--text-dim)"
        height={140}
      />
      <Legend items={[{ label: 'Observed', color: 'var(--cyan)' }, { label: '>130% of normal', color: 'var(--amber)' }, { label: '1991–2020 normal (synthetic)', color: 'var(--text-dim)', dashed: true }]} />

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Section>RAINFALL ANOMALY · %</Section>
          <LineChart ariaLabel="Rainfall anomaly series" series={[{ id: 'r', label: 'Rain', color: statusColor(rain.status), points: rain.history }]} refs={[{ value: 35, color: 'var(--red)', label: 'RISK 35' }]} year={year} height={110} />
        </div>
        <div>
          <Section>TEMPERATURE ANOMALY · °C</Section>
          <LineChart ariaLabel="Temperature anomaly series" series={[{ id: 't', label: 'Temp', color: statusColor(temp.status), points: temp.history }]} refs={[{ value: 1.5, color: 'var(--red)', label: 'RISK 1.5' }]} year={year} decimals={1} height={110} />
        </div>
      </div>

      <Section>STATIONS · {Math.round(sensors)} OF {Math.max(stations.length, Math.round(sensors))} SITE SENSORS REPORTING</Section>
      <table className="dtable">
        <thead><tr><th>STATION</th><th>TYPE</th><th>LATEST (SNAPSHOT)</th><th>STATE</th></tr></thead>
        <tbody>
          {stations.map((s, i) => {
            const up = i < Math.round(sensors);
            return (
              <tr key={s.id}>
                <td className="font-mono text-9.5 text-faint">{s.id}</td>
                <td className="text-text">{s.kind}</td>
                <td className="font-mono">{up ? s.reading : '—'}</td>
                <td>{up ? <Badge status="ok">REPORTING</Badge> : <Badge status="watch">NO DATA</Badge>}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <Note>Station IDs are synthetic placeholders. A real deployment would map these to national hydromet station codes.</Note>
    </div>
  );
}

/* ------------------------------ 02.2 Flood & Landslide Risk ------------------------------ */

const LIKE: Record<Status, number> = { ok: 0, watch: 1, risk: 2 };

function FloodLandslide() {
  const { location, year, setLayer, layers } = useOpenDMO();
  const river = getSignal('river_stage', location, year);
  const slide = getSignal('landslide_susceptibility', location, year);
  const visitors = valueAt('annual_visitors', location, year);
  const impact = visitors >= 600 ? 2 : visitors >= 300 ? 1 : 0;
  const hazards = [
    { id: 'F', name: 'Riverine / flash flood', like: LIKE[river.status], s: river.status },
    { id: 'L', name: 'Landslide', like: LIKE[slide.status], s: slide.status },
  ];
  const t = SPEC_BY_ID.river_stage.thresholds!;
  // representative 30-day hydrograph ending at the seasonal peak
  const hydro = Array.from({ length: 30 }, (_, i) => {
    const shape = Math.exp(-Math.pow((i - 24) / 6, 2));
    const base = river.value * 0.55;
    return { year: i + 1, value: +(base + (river.value - base) * shape + noise(`hy|${location}|${year}|${i}`) * 0.08).toFixed(2) };
  });
  const exposed = [
    ...NOTABLE_ASSETS.filter((a) => a.location === location && a.condition !== 'ok' && a.since <= year).map((a) => ({ id: a.id, name: a.name, kind: 'Asset', s: a.condition })),
    ...PROJECTS.filter((p) => p.location === location && p.exposure !== 'ok' && projectStage(p, year)).map((p) => ({ id: p.id, name: p.name, kind: 'Project', s: p.exposure })),
  ];

  return (
    <div>
      <div className="flex items-center justify-between">
        <Section>HAZARD MATRIX · {year}</Section>
      </div>
      <div className="grid grid-cols-[1fr_auto] gap-4">
        <div>
          <div className="grid grid-cols-[48px_repeat(3,1fr)] gap-px bg-line border border-line">
            {[2, 1, 0].map((like) => (
              <div key={like} className="contents">
                <div className="flex items-center bg-panel px-1.5 font-mono text-9 text-faint">{['LOW', 'MED', 'HIGH'][like]}</div>
                {[0, 1, 2].map((imp) => {
                  const sev = like + imp;
                  const tint = sev >= 3 ? 'rgba(194,111,99,0.14)' : sev >= 2 ? 'rgba(207,159,92,0.10)' : 'rgba(111,191,148,0.05)';
                  const here = hazards.filter((h) => h.like === like && impact === imp);
                  return (
                    <div key={imp} className="flex h-[38px] items-center justify-center gap-1.5" style={{ background: `linear-gradient(${tint},${tint}), var(--panel)` }}>
                      {here.map((h) => (
                        <span key={h.id} className="badge" style={{ color: statusColor(h.s), border: `1px solid ${statusColor(h.s)}` }} title={h.name}>
                          {h.id}
                        </span>
                      ))}
                    </div>
                  );
                })}
              </div>
            ))}
            <div className="bg-panel" />
            {['LOW', 'MED', 'HIGH'].map((l) => (
              <div key={l} className="bg-panel py-1 text-center font-mono text-9 text-faint">{l}</div>
            ))}
          </div>
          <div className="mt-1 flex justify-between font-mono text-9 text-faint">
            <span>↑ LIKELIHOOD (from signal status)</span>
            <span>IMPACT → visitor exposure ({fmtSignal('annual_visitors', visitors)}k/yr)</span>
          </div>
        </div>
        <div className="flex w-[150px] flex-col gap-1.5 text-11">
          {hazards.map((h) => (
            <div key={h.id} className="flex items-center justify-between border-b border-line pb-1">
              <span className="text-dim"><span className="font-mono text-faint">{h.id}</span> {h.name}</span>
              <Badge status={h.s}>{statusShort(h.s)}</Badge>
            </div>
          ))}
          <button className={`ctl mt-1${layers.risk ? ' on' : ''}`} onClick={() => setLayer('risk', !layers.risk)}>
            {layers.risk ? 'HIDE' : 'SHOW'} RISK LAYER ON MAP
          </button>
        </div>
      </div>

      <Section right={<SignalMeta s={river} />}>HYDROGRAPH · {LOCATIONS[location].gauge.toUpperCase()} · 30-DAY PEAK WINDOW · m</Section>
      <LineChart
        ariaLabel="30-day river stage hydrograph"
        series={[{ id: 'h', label: 'Stage', color: statusColor(river.status), points: hydro }]}
        refs={[{ value: t.watch, color: 'var(--amber)', label: `WATCH ${t.watch} m` }, { value: t.risk, color: 'var(--red)', label: `DANGER ${t.risk} m` }]}
        xLabel={(d) => `D${d}`}
        decimals={1}
        yMin={0}
        height={120}
      />
      <Note>Representative synthetic hydrograph scaled to the {year} seasonal peak. It is not a gauge record.</Note>

      <Section right={<SignalMeta s={slide} />}>LANDSLIDE SUSCEPTIBILITY · 2015–2030</Section>
      <LineChart
        ariaLabel="Landslide susceptibility series"
        series={[{ id: 'l', label: 'Susceptibility', color: statusColor(slide.status), points: slide.history }]}
        refs={[{ value: 50, color: 'var(--amber)', label: 'WATCH 50' }, { value: 70, color: 'var(--red)', label: 'RISK 70' }]}
        year={year}
        yMin={0}
        yMax={100}
        height={110}
      />

      <Section>EXPOSED ASSETS &amp; PROJECTS · {year}</Section>
      <table className="dtable">
        <tbody>
          {exposed.length === 0 && <tr><td className="text-faint">No assets or projects with elevated exposure at this site.</td></tr>}
          {exposed.map((e) => (
            <tr key={e.id}>
              <td className="font-mono text-9.5 text-faint">{e.id}</td>
              <td className="text-text">{e.name}</td>
              <td>{e.kind}</td>
              <td><Badge status={e.s}>{statusShort(e.s)}</Badge></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------ 02.3 Ecosystem Stress ------------------------------ */

const ECO = ['forest_cover', 'forest_cover_change', 'siltation', 'water_quality', 'biodiversity'];

function Ecosystem() {
  const { location, year, layers, setLayer } = useOpenDMO();
  const rows = ECO.map((id) => getSignal(id, location, year));
  const cover = rows[0];
  const v = (id: string) => valueAt(id, location, year);
  const comps = [
    { label: 'Forest loss', v: Math.min(100, Math.max(0, -v('forest_cover_change') * 50)) },
    { label: 'Channel siltation', v: v('siltation') },
    { label: 'Water-quality deficit', v: 100 - v('water_quality') },
    { label: 'Biodiversity deficit', v: 100 - v('biodiversity') },
  ];
  const stress = comps.reduce((a, c) => a + c.v, 0) / comps.length;
  const sStatus: Status = stress >= 55 ? 'risk' : stress >= 40 ? 'watch' : 'ok';
  const stressHist = YEARS.map((y) => ({
    year: y,
    value: +(((Math.min(100, Math.max(0, -valueAt('forest_cover_change', location, y) * 50)) + valueAt('siltation', location, y) + (100 - valueAt('water_quality', location, y)) + (100 - valueAt('biodiversity', location, y))) / 4).toFixed(1)),
    ...(y > OBSERVATION_YEAR ? { projected: true } : {}),
  }));
  const tone = (s: number) => (s >= 55 ? 'var(--red)' : s >= 40 ? 'var(--amber)' : 'var(--green)');

  return (
    <div>
      <div className="grid grid-cols-[170px_1fr] gap-4">
        <div className="border border-line bg-panel-alt px-3 py-2">
          <div className="text-10 tracking-[.05em] text-faint">Composite Ecosystem Stress</div>
          <div className="mt-1 font-mono text-20" style={{ color: tone(stress) }}>{stress.toFixed(0)}</div>
          <div className="mt-1"><Badge status={sStatus} /></div>
          <div className="mt-1.5 font-mono text-9 text-faint">MEAN OF 4 COMPONENTS · 0–100 · WATCH 40 · RISK 55</div>
          <button className={`ctl mt-2 w-full${layers.environment ? ' on' : ''}`} onClick={() => setLayer('environment', !layers.environment)}>
            {layers.environment ? 'HIDE' : 'SHOW'} ENVIRONMENT LAYER
          </button>
        </div>
        <div>
          <Section>STRESS COMPONENTS · {year}</Section>
          {comps.map((c) => <HBar key={c.label} label={c.label} value={c.v} color={tone(c.v)} />)}
        </div>
      </div>

      <Section>INDICATORS · {year}</Section>
      <table className="dtable">
        <thead><tr><th>INDICATOR</th><th className="num">VALUE</th><th className="num">Δ SINCE 2015</th><th>STATUS</th><th>CONF</th></tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td className="text-text">{r.label}</td>
              <td className="num">{fmtSignal(r.id, r.value)} <span className="text-faint">{r.unit}</span></td>
              <td className="num" style={{ color: 'var(--text-dim)' }}>{fmtSignal(r.id, r.value - r.history[0].value)}</td>
              <td><Badge status={r.status}>{statusShort(r.status)}</Badge></td>
              <td><ConfBadge c={r.confidence} /></td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Section right={<SignalMeta s={cover} />}>FOREST COVER · %</Section>
          <LineChart ariaLabel="Forest cover series" series={[{ id: 'fc', label: 'Cover', color: statusColor(cover.status), points: cover.history }]} year={year} decimals={0} height={110} />
        </div>
        <div>
          <Section>COMPOSITE STRESS · 0–100</Section>
          <LineChart ariaLabel="Composite ecosystem stress series" series={[{ id: 'st', label: 'Stress', color: tone(stress), points: stressHist }]} refs={[{ value: 55, color: 'var(--red)', label: 'RISK 55' }]} year={year} yMin={0} yMax={100} height={110} />
        </div>
      </div>
      <Note>Components are synthetic remote-sensing and field proxies. The composite is an unweighted mean — a real study would justify its weighting.</Note>
    </div>
  );
}

/* ------------------------------ 02.4 Early Warning ------------------------------ */

function EarlyWarning() {
  const { location, setLocation, year } = useOpenDMO();
  const warnings = warningsFor(location, year);
  const active = getSignal('active_warnings', location, year);
  const hist = YEARS.map((y) => ({
    label: String(y).slice(2),
    value: warningsFor(location, y).filter((w) => w.level === 'risk').length,
    color: y > OBSERVATION_YEAR ? 'var(--text-faint)' : y === year ? 'var(--cyan)' : 'var(--red)',
  }));

  return (
    <div>
      <Section right={<SignalMeta s={active} />}>
        ACTIVE · {LOCATIONS[location].short.toUpperCase()} · {year}
      </Section>
      {warnings.length === 0 && (
        <div className="intel-alert ok"><span className="ai">✓</span><span>No rules triggered for this site in {year}. Check the all-sites matrix below.</span></div>
      )}
      {warnings.map((w) => (
        <div key={w.id} className={`intel-alert${w.level === 'risk' ? ' risk' : ''}`}>
          <span className="ai">{w.level === 'risk' ? 'WARN' : 'ADVS'}</span>
          <span className="flex-1">
            <span className="text-text">{w.title}</span>
            <span className="block font-mono text-9 text-faint">{w.detail}</span>
          </span>
          <Badge status={w.level}>{w.level === 'risk' ? 'WARNING' : 'ADVISORY'}</Badge>
        </div>
      ))}

      <Section>ALL SITES · RULE STATUS · {year}</Section>
      <div className="overflow-x-auto">
        <table className="dtable">
          <thead>
            <tr>
              <th>SITE</th>
              {WARNING_RULES.map((r) => <th key={r.signalId} className="text-center">{SPEC_BY_ID[r.signalId].label.split(' ').slice(0, 2).join(' ').toUpperCase()}</th>)}
            </tr>
          </thead>
          <tbody>
            {LOCATION_KEYS.map((k) => (
              <tr key={k} className={`click${k === location ? ' sel' : ''}`} onClick={() => setLocation(k)}>
                <td className="text-text">{LOCATIONS[k].short}</td>
                {WARNING_RULES.map((r) => {
                  const s = statusAt(r.signalId, k, year);
                  return (
                    <td key={r.signalId} className="text-center font-mono text-9.5" style={{ color: statusColor(s) }} title={`${fmtSignal(r.signalId, valueAt(r.signalId, k, year))} ${SPEC_BY_ID[r.signalId].unit}`}>
                      {s === 'ok' ? '·' : s === 'watch' ? '△' : '▲'} {fmtSignal(r.signalId, valueAt(r.signalId, k, year))}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Note>Click a site to make it the active location everywhere.</Note>

      <Section>WARNING-LEVEL TRIGGERS PER YEAR · {LOCATIONS[location].short.toUpperCase()}</Section>
      <BarChart ariaLabel="Warning-level rule triggers per year" bars={hist} height={100} max={Math.max(3, ...hist.map((h) => h.value)) + 0.5} />

      <Section>RULES</Section>
      <table className="dtable">
        <thead><tr><th>SIGNAL</th><th className="num">ADVISORY</th><th className="num">WARNING</th><th>DIRECTION</th><th className="num">Δ YR HERE</th></tr></thead>
        <tbody>
          {WARNING_RULES.map((r) => {
            const t = SPEC_BY_ID[r.signalId].thresholds!;
            const d = deltaAt(r.signalId, location, year);
            return (
              <tr key={r.signalId}>
                <td className="text-text">{SPEC_BY_ID[r.signalId].label}</td>
                <td className="num">{t.worse === 'higher' ? '≥' : '≤'} {t.watch}</td>
                <td className="num">{t.worse === 'higher' ? '≥' : '≤'} {t.risk}</td>
                <td>{t.worse === 'higher' ? 'rising is worse' : 'falling is worse'}</td>
                <td className="num" style={{ color: 'var(--text-dim)' }}>{d >= 0 ? '+' : ''}{fmtSignal(r.signalId, d)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <Note>
        Illustrative thresholds for a research prototype. They are not official danger levels, and no warning shown here has been issued by any
        agency.
      </Note>
    </div>
  );
}
