'use client';

import { useMemo, useState } from 'react';
import { LOCATIONS } from '@/lib/data/locations';
import { ASSET_TYPES, MONTHS, NOTABLE_ASSETS, SNAPSHOT_MONTH, VISITOR_SEASONALITY, WEEKEND_SHARE, SENTIMENT_THEMES, assetCount } from '@/lib/data/registry';
import { deltaAt, fmt, fmtSignal, getSignal, statusFromThresholds, valueAt } from '@/lib/data/series';
import { SPEC_BY_ID } from '@/lib/data/signals';
import { OBSERVATION_YEAR } from '@/lib/data/layers';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { statusColor } from '@/lib/theme';
import { BarChart, HBar } from '../../charts/BarChart';
import { Legend, LineChart } from '../../charts/LineChart';
import { Badge, ConfBadge, Metric, MetricRow, Note, Section, SignalMeta, StatusDot } from '../../shared/ui';
import { CoreFrame } from '../CoreFrame';

export function ObservatoryCore() {
  return (
    <CoreFrame
      core="observatory"
      views={{
        'visitor-flow': VisitorFlow,
        'site-condition': SiteCondition,
        'community-sentiment': CommunitySentiment,
        'asset-registry': AssetRegistry,
      }}
    />
  );
}

/* ------------------------------ 01.1 Visitor Flow ------------------------------ */

function VisitorFlow() {
  const { location, year } = useOpenDMO();
  const loc = LOCATIONS[location];
  const visitors = getSignal('annual_visitors', location, year);
  const pressure = getSignal('visitor_pressure', location, year);
  const occ = getSignal('site_occupancy', location, year);

  const season = VISITOR_SEASONALITY[location];
  const total = season.reduce((a, b) => a + b, 0);
  const monthly = season.map((s) => (visitors.value * s) / total);
  const monthlyCap = (loc.capacityK / 12) * 1.25; // monthly peak allowance
  const observedUpTo = year === OBSERVATION_YEAR ? SNAPSHOT_MONTH : 11;
  const peakIdx = monthly.indexOf(Math.max(...monthly));
  const over = monthly.filter((m) => m > monthlyCap).length;
  const weekend = WEEKEND_SHARE[location];

  return (
    <div>
      <MetricRow cols={4}>
        <Metric s={visitors} />
        <Metric s={pressure} />
        <Metric s={occ} />
        <div className="flex flex-col gap-1 bg-panel px-3 py-2">
          <span className="text-10 tracking-[.05em] text-faint">Peak Month</span>
          <span className="font-mono text-15 text-text">{MONTHS[peakIdx]}</span>
          <span className="font-mono text-9" style={{ color: over ? 'var(--amber)' : 'var(--text-faint)' }}>
            {over} MONTH{over === 1 ? '' : 'S'} OVER ALLOWANCE
          </span>
        </div>
      </MetricRow>

      <Section right={<SignalMeta s={visitors} />}>MONTHLY VISITS · {year} · &apos;000</Section>
      <BarChart
        ariaLabel={`Monthly visits for ${loc.name} in ${year}`}
        decimals={0}
        bars={monthly.map((m, i) => ({
          label: MONTHS[i],
          value: i > observedUpTo ? null : m,
          color: m > monthlyCap ? 'var(--amber)' : year > OBSERVATION_YEAR ? 'var(--text-faint)' : 'var(--green)',
          note: m > monthlyCap ? 'over monthly allowance' : undefined,
        }))}
        line={season.map(() => monthlyCap)}
        lineColor="var(--red)"
      />
      <Legend items={[{ label: 'Monthly visits', color: 'var(--green)' }, { label: 'Over allowance', color: 'var(--amber)' }, { label: `Monthly allowance ${monthlyCap.toFixed(0)}k`, color: 'var(--red)', dashed: true }]} />
      {year === OBSERVATION_YEAR && <Note>Oct–Dec {year} are not yet observed in the snapshot and are shown as empty frames.</Note>}

      <Section>ANNUAL VISITORS 2015–2030 · &apos;000</Section>
      <LineChart
        ariaLabel="Annual visitors series"
        series={[{ id: 'v', label: 'Visitors', color: statusColor(visitors.status), points: visitors.history }]}
        refs={[{ value: loc.capacityK, color: 'var(--red)', label: `CAPACITY ${loc.capacityK}k` }]}
        year={year}
        height={140}
      />
      <Note>2020–21 dip reflects the modelled pandemic shock. Values after {OBSERVATION_YEAR} are trend projections (dashed) with reduced confidence.</Note>

      <Section>FLOW PATTERN · {year}</Section>
      <table className="dtable">
        <tbody>
          <tr><td>Weekend share of visits</td><td className="num">{(weekend * 100).toFixed(0)}%</td></tr>
          <tr><td>Average weekend day</td><td className="num">{fmt(((visitors.value * 1000 * weekend) / 104), 0)} visitors</td></tr>
          <tr><td>Average weekday</td><td className="num">{fmt(((visitors.value * 1000 * (1 - weekend)) / 261), 0)} visitors</td></tr>
          <tr><td>Change vs {year - 1}</td><td className="num">{deltaAt('annual_visitors', location, year) >= 0 ? '+' : ''}{fmtSignal('annual_visitors', deltaAt('annual_visitors', location, year))}k</td></tr>
          <tr><td>Change vs 2015</td><td className="num">{fmt(((visitors.value / valueAt('annual_visitors', location, 2015)) - 1) * 100, 0)}%</td></tr>
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------ 01.2 Site Condition ------------------------------ */

const CONDITION = ['trail_condition', 'sanitation', 'waste_load', 'signage', 'water_quality'];

function SiteCondition() {
  const { location, year } = useOpenDMO();
  const [selected, setSelected] = useState(CONDITION[0]);
  const rows = CONDITION.map((id) => getSignal(id, location, year));
  const sel = rows.find((r) => r.id === selected)!;
  const t = SPEC_BY_ID[selected].thresholds!;
  const assets = NOTABLE_ASSETS.filter((a) => a.location === location && a.since <= year);

  return (
    <div>
      <Section>CONDITION INDICATORS · {year}</Section>
      <table className="dtable">
        <thead>
          <tr><th>INDICATOR</th><th className="num">VALUE</th><th className="num">Δ YR</th><th className="num">2015</th><th>STATUS</th><th>CONF</th></tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const d = deltaAt(r.id, location, year);
            return (
              <tr key={r.id} className={`click${r.id === selected ? ' sel' : ''}`} onClick={() => setSelected(r.id)}>
                <td className="text-text">
                  {r.label} <span className="font-mono text-9 text-faint">{SPEC_BY_ID[r.id].thresholds?.worse === 'higher' ? '↓ better' : '↑ better'}</span>
                </td>
                <td className="num">{fmtSignal(r.id, r.value)} <span className="text-faint">{r.unit}</span></td>
                <td className="num" style={{ color: 'var(--text-dim)' }}>{d >= 0 ? '+' : ''}{fmtSignal(r.id, d)}</td>
                <td className="num" style={{ color: 'var(--text-faint)' }}>{fmtSignal(r.id, r.history[0].value)}</td>
                <td><Badge status={r.status}>{r.status.toUpperCase()}</Badge></td>
                <td><ConfBadge c={r.confidence} /></td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <Note>Select a row to chart its full series against the watch and risk thresholds.</Note>

      <Section right={<SignalMeta s={sel} />}>{sel.label.toUpperCase()} · 2015–2030</Section>
      <LineChart
        ariaLabel={`${sel.label} series`}
        series={[{ id: sel.id, label: sel.label, color: statusColor(sel.status), points: sel.history }]}
        refs={[
          { value: t.watch, color: 'var(--amber)', label: `WATCH ${t.watch}` },
          { value: t.risk, color: 'var(--red)', label: `RISK ${t.risk}` },
        ]}
        year={year}
        yMin={0}
        yMax={100}
        height={130}
      />

      <Section>REGISTERED ASSETS · CONDITION</Section>
      <table className="dtable">
        <thead><tr><th>ID</th><th>ASSET</th><th>SINCE</th><th>CONDITION</th><th>NOTE (2026 AUDIT)</th></tr></thead>
        <tbody>
          {assets.map((a) => (
            <tr key={a.id}>
              <td className="font-mono text-9.5 text-faint">{a.id}</td>
              <td className="text-text">{a.name}</td>
              <td className="font-mono">{a.since}</td>
              <td><Badge status={a.condition}>{a.condition.toUpperCase()}</Badge></td>
              <td>{a.note}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------ 01.3 Community Sentiment ------------------------------ */

function CommunitySentiment() {
  const { location, year } = useOpenDMO();
  const sent = getSignal('community_sentiment', location, year);
  const n = getSignal('survey_responses', location, year);
  const pressure = getSignal('visitor_pressure', location, year);
  const spec = SPEC_BY_ID.community_sentiment;
  const themes = SENTIMENT_THEMES.map((t) => {
    const v = Math.max(0, Math.min(100, sent.value + t.offset[location] * (1 + (year - OBSERVATION_YEAR) * 0.03)));
    return { ...t, v, s: statusFromThresholds(spec, v) };
  });
  const moe = n.value > 0 ? 98 / Math.sqrt(n.value) : NaN;
  const weakest = [...themes].sort((a, b) => a.v - b.v)[0];

  return (
    <div>
      <MetricRow cols={4}>
        <Metric s={sent} />
        <Metric s={n} note={`MOE ±${Number.isFinite(moe) ? moe.toFixed(1) : '—'} pts (95%)`} />
        <Metric s={pressure} />
        <div className="flex flex-col gap-1 bg-panel px-3 py-2">
          <span className="text-10 tracking-[.05em] text-faint">Weakest Theme</span>
          <span className="truncate text-12.5 text-text">{weakest.label}</span>
          <span className="font-mono text-9" style={{ color: statusColor(weakest.s) }}>{weakest.v.toFixed(0)} idx · {weakest.s.toUpperCase()}</span>
        </div>
      </MetricRow>

      <Section right={<SignalMeta s={sent} />}>THEMES · {year} · 0–100 (HIGHER = MORE FAVOURABLE)</Section>
      {themes.map((t) => (
        <HBar key={t.id} label={t.label} value={t.v} color={statusColor(t.s)} right={`${t.v.toFixed(0)} · ${t.s.toUpperCase()}`} />
      ))}

      <Section>SENTIMENT VS VISITOR PRESSURE · 2015–2030</Section>
      <LineChart
        ariaLabel="Sentiment versus visitor pressure"
        series={[
          { id: 's', label: 'Sentiment', color: 'var(--green)', points: sent.history },
          { id: 'p', label: 'Visitor pressure', color: 'var(--amber)', points: pressure.history },
        ]}
        refs={[{ value: spec.thresholds!.watch, color: 'var(--amber)', label: `SENTIMENT WATCH ${spec.thresholds!.watch}` }]}
        year={year}
        yMin={0}
        yMax={100}
        height={130}
      />
      <Legend items={[{ label: 'Community sentiment', color: 'var(--green)' }, { label: 'Visitor pressure index', color: 'var(--amber)' }]} />
      <Note>
        Theme scores are synthetic decompositions of the headline index. In a real deployment they would come from coded survey items; the margin of
        error shown assumes simple random sampling.
      </Note>
    </div>
  );
}

/* ------------------------------ 01.4 Asset Registry ------------------------------ */

function AssetRegistry() {
  const { location, year } = useOpenDMO();
  const [type, setType] = useState<string>('all');
  const guides = getSignal('registered_guides', location, year);

  const rows = useMemo(
    () =>
      ASSET_TYPES.map((t) => ({
        ...t,
        now: assetCount(t.id, location, year),
        y2015: assetCount(t.id, location, 2015),
        y2030: assetCount(t.id, location, 2030),
        prev: assetCount(t.id, location, Math.max(2015, year - 1)),
      })),
    [location, year],
  );
  const notable = NOTABLE_ASSETS.filter((a) => a.location === location && (type === 'all' || a.type === type));

  return (
    <div>
      <Section right={<span className="font-mono text-9 text-faint">SYN-v0.5 · registry extract · CONF HIGH</span>}>REGISTRY COUNTS · {year}</Section>
      <table className="dtable">
        <thead><tr><th>CATEGORY</th><th className="num">{year}</th><th className="num">Δ YR</th><th className="num">2015</th><th className="num">2030 PROJ</th></tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td className="text-text">{r.label}</td>
              <td className="num">{r.now}</td>
              <td className="num" style={{ color: 'var(--text-dim)' }}>{r.now - r.prev >= 0 ? '+' : ''}{r.now - r.prev}</td>
              <td className="num" style={{ color: 'var(--text-faint)' }}>{r.y2015}</td>
              <td className="num" style={{ color: 'var(--amber)' }}>{r.y2030}</td>
            </tr>
          ))}
          <tr>
            <td className="text-text">
              <span className="inline-flex items-center gap-1.5">Registered local guides <StatusDot status={guides.status} /></span>
            </td>
            <td className="num">{fmtSignal('registered_guides', guides.value)}</td>
            <td className="num" style={{ color: 'var(--text-dim)' }}>+{fmtSignal('registered_guides', deltaAt('registered_guides', location, year))}</td>
            <td className="num" style={{ color: 'var(--text-faint)' }}>{guides.history[0].value}</td>
            <td className="num" style={{ color: 'var(--amber)' }}>{guides.history[guides.history.length - 1].value}</td>
          </tr>
        </tbody>
      </table>

      <Section
        right={
          <select className="inp" value={type} onChange={(e) => setType(e.target.value)} aria-label="Filter by asset type">
            <option value="all">All types</option>
            {ASSET_TYPES.map((t) => (
              <option key={t.id} value={t.id}>{t.label}</option>
            ))}
          </select>
        }
      >
        NOTABLE ASSETS
      </Section>
      <table className="dtable">
        <thead><tr><th>ID</th><th>ASSET</th><th>TYPE</th><th>SINCE</th><th>STATE IN {year}</th></tr></thead>
        <tbody>
          {notable.length === 0 && (
            <tr><td colSpan={5} className="text-faint">No notable assets of this type are registered here. Choose another type or location.</td></tr>
          )}
          {notable.map((a) => {
            const exists = a.since <= year;
            return (
              <tr key={a.id}>
                <td className="font-mono text-9.5 text-faint">{a.id}</td>
                <td className={exists ? 'text-text' : 'text-faint'}>{a.name}</td>
                <td>{ASSET_TYPES.find((t) => t.id === a.type)?.label ?? a.type}</td>
                <td className="font-mono">{a.since}</td>
                <td>{exists ? <Badge status={a.condition}>{a.condition.toUpperCase()}</Badge> : <Badge status="muted">NOT YET REGISTERED</Badge>}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <Note>Registry schema mirrors a future asset API: id, type, registration year, and latest audited condition.</Note>
    </div>
  );
}
