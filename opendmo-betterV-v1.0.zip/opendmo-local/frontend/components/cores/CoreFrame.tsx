'use client';

import type { ReactNode } from 'react';
import { CORE_BY_ID } from '@/lib/data/cores';
import { LOCATIONS } from '@/lib/data/locations';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import type { CoreId } from '@/lib/types';
import { ProjectedTag } from '../shared/ui';

/** Core panel: submodule tabs + the active submodule view. Tabs and sidebar share state. */
export function CoreFrame({ core, views }: { core: CoreId; views: Record<string, () => ReactNode> }) {
  const { submodule, setSubmodule, location, year } = useOpenDMO();
  const def = CORE_BY_ID[core];
  const active = submodule[core] in views ? submodule[core] : def.sub[0].id;
  const View = views[active];
  return (
    <section className="core-panel" aria-label={def.name}>
      <div className="core-tabs" role="tablist">
        {def.sub.map((s, i) => (
          <button key={s.id} role="tab" aria-selected={active === s.id} className={`core-tab${active === s.id ? ' on' : ''}`} onClick={() => setSubmodule(core, s.id)}>
            <span className="n">{def.num}.{i + 1}</span>
            {s.name}
            {s.roadmap && <span className="badge watch">ROADMAP</span>}
          </button>
        ))}
      </div>
      <div className="flex items-center justify-between gap-2 border-b border-line px-4 py-1.5 font-mono text-9 tracking-meta text-faint">
        <span>
          {LOCATIONS[location].name.toUpperCase()} · {LOCATIONS[location].region.toUpperCase()}
        </span>
        <span className="flex items-center gap-2">
          <ProjectedTag year={year} />
          <span>YEAR {year}</span>
        </span>
      </div>
      <div className="core-body" role="tabpanel" key={`${active}`}>
        <View />
      </div>
    </section>
  );
}
