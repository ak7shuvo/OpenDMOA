'use client';

import { useMemo, useState } from 'react';
import { CORE_BY_ID } from '@/lib/data/cores';
import { DATASET_VERSION, OBSERVATION_YEAR, SNAPSHOT_ISO } from '@/lib/data/layers';
import { LOCATIONS } from '@/lib/data/locations';
import { BRIEFS, DATASETS, PUBLICATIONS, STAGES, datasetsCovering, stageAt, type Stage } from '@/lib/data/registry';
import { YEARS, fmtSignal, getSignal, statusAt, valueAt, worst } from '@/lib/data/series';
import { SPEC_BY_ID } from '@/lib/data/signals';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { statusColor, statusShort } from '@/lib/theme';
import type { CoreId } from '@/lib/types';
import { Badge, Metric, MetricRow, Note, Roadmap, Section } from '../../shared/ui';
import { CoreFrame } from '../CoreFrame';

export function LabCore() {
  return (
    <CoreFrame
      core="lab"
      views={{
        datasets: DatasetExplorer,
        briefs: PolicyBriefs,
        vrar: VrArRoadmap,
        publications: PublicationQueue,
      }}
    />
  );
}

/* ------------------------------ 04.1 Dataset Explorer ------------------------------ */

function DatasetExplorer() {
  const { location, year } = useOpenDMO();
  const [q, setQ] = useState('');
  const [core, setCore] = useState<CoreId | 'all'>('all');
  const [sel, setSel] = useState<string>('DS-01');
  const covering = new Set(datasetsCovering(location, year).map((d) => d.id));

  const list = DATASETS.filter(
    (d) => (core === 'all' || d.core === core) && (q === '' || `${d.id} ${d.name} ${d.signals.join(' ')}`.toLowerCase().includes(q.toLowerCase())),
  );
  const ds = DATASETS.find((d) => d.id === sel) ?? DATASETS[0];
  const coversLoc = ds.locations.includes(location);
  const years = YEARS.filter((y) => y >= ds.from && y <= ds.to);

  const csv = useMemo(() => {
    const head = ['location', 'year', ...ds.signals.map((s) => `${s} (${SPEC_BY_ID[s].unit})`), 'projected', 'source', 'snapshot'];
    const body = years.map((y) => [location, y, ...ds.signals.map((s) => valueAt(s, location, y)), y > OBSERVATION_YEAR, DATASET_VERSION, SNAPSHOT_ISO].join(','));
    return [`# ${ds.id} ${ds.name} — SYNTHETIC DEMO DATA, not observations`, head.join(','), ...body].join('\n');
  }, [ds, location, years]);

  const download = () => {
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `opendmo_${ds.id.toLowerCase()}_${location}_synthetic.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <MetricRow cols={4}>
        <Metric s={getSignal('active_datasets', location, year)} />
        <Metric s={getSignal('data_completeness', location, year)} />
        <Metric s={getSignal('sensors_reporting', location, year)} />
        <Metric s={getSignal('survey_responses', location, year)} />
      </MetricRow>

      <Section
        right={
          <span className="flex gap-1">
            <input className="inp w-[150px]" placeholder="Search name or signal" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search datasets" />
            <select className="inp" value={core} onChange={(e) => setCore(e.target.value as CoreId | 'all')} aria-label="Filter by core">
              <option value="all">All cores</option>
              {(['observatory', 'climate', 'economy', 'lab'] as CoreId[]).map((c) => (
                <option key={c} value={c}>{CORE_BY_ID[c].num} {CORE_BY_ID[c].short}</option>
              ))}
            </select>
          </span>
        }
      >
        CATALOGUE · {list.length} OF {DATASETS.length}
      </Section>
      <table className="dtable">
        <thead><tr><th>ID</th><th>DATASET</th><th>CORE</th><th>RANGE</th><th>SITES</th><th>COVERS {LOCATIONS[location].short.toUpperCase()} · {year}</th></tr></thead>
        <tbody>
          {list.length === 0 && <tr><td colSpan={6} className="text-faint">No datasets match. Clear the search or pick another core.</td></tr>}
          {list.map((d) => (
            <tr key={d.id} className={`click${d.id === sel ? ' sel' : ''}`} onClick={() => setSel(d.id)}>
              <td className="font-mono text-9.5 text-faint">{d.id}</td>
              <td className="text-text">{d.name}</td>
              <td className="font-mono">{CORE_BY_ID[d.core].num}</td>
              <td className="font-mono">{d.from}–{d.to}</td>
              <td className="font-mono">{d.locations.length}/4</td>
              <td>{covering.has(d.id) ? <Badge status="ok">YES</Badge> : <Badge status="muted">NO</Badge>}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <Section right={<button className="ctl" onClick={download} disabled={!coversLoc}>EXPORT CSV (SYNTHETIC)</button>}>
        PREVIEW · {ds.id} · {LOCATIONS[location].short.toUpperCase()}
      </Section>
      <div className="mb-2 font-mono text-9 text-faint">
        METHOD: {ds.method.toUpperCase()} · LICENCE {ds.licence} · PROVENANCE: GENERATED, NOT OBSERVED
      </div>
      {!coversLoc ? (
        <Note>This dataset does not cover {LOCATIONS[location].name}. Pick another site on the map or another dataset.</Note>
      ) : (
        <div className="max-h-[260px] overflow-auto">
          <table className="dtable">
            <thead>
              <tr>
                <th>YEAR</th>
                {ds.signals.map((s) => <th key={s} className="num">{SPEC_BY_ID[s].label.toUpperCase()} <span className="text-faint">{SPEC_BY_ID[s].unit}</span></th>)}
              </tr>
            </thead>
            <tbody>
              {years.map((y) => (
                <tr key={y} className={y === year ? 'sel' : ''}>
                  <td className="font-mono" style={{ color: y > OBSERVATION_YEAR ? 'var(--amber)' : 'var(--text)' }}>{y}{y > OBSERVATION_YEAR ? ' P' : ''}</td>
                  {ds.signals.map((s) => (
                    <td key={s} className="num" style={{ color: statusColor(statusAt(s, location, y)) }}>{fmtSignal(s, valueAt(s, location, y))}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ------------------------------ 04.2 Policy Briefs ------------------------------ */

function PolicyBriefs() {
  const { location, year } = useOpenDMO();
  const [scope, setScope] = useState<'site' | 'all'>('site');
  const list = BRIEFS.filter((b) => scope === 'all' || b.locations.includes(location));
  const [sel, setSel] = useState<string | null>(null);
  const brief = list.find((b) => b.id === sel) ?? list[0];

  return (
    <div>
      <Section
        right={
          <span className="flex gap-1">
            <button className={`ctl${scope === 'site' ? ' on' : ''}`} onClick={() => setScope('site')}>THIS SITE</button>
            <button className={`ctl${scope === 'all' ? ' on' : ''}`} onClick={() => setScope('all')}>ALL SITES</button>
          </span>
        }
      >
        BRIEFS · STAGE IN {year}
      </Section>
      <table className="dtable">
        <thead><tr><th>ID</th><th>TITLE</th><th>SITES</th><th>CORE</th><th>STAGE</th><th>EVIDENCE NOW</th></tr></thead>
        <tbody>
          {list.length === 0 && <tr><td colSpan={6} className="text-faint">No briefs for this site yet. Switch to all sites to browse others.</td></tr>}
          {list.map((b) => {
            const st = stageAt(b, year);
            const ev = worst(b.evidence.map((id) => statusAt(id, b.locations[0], year)));
            return (
              <tr key={b.id} className={`click${brief?.id === b.id ? ' sel' : ''}`} onClick={() => setSel(b.id)}>
                <td className="font-mono text-9.5 text-faint">{b.id}</td>
                <td className={st ? 'text-text' : 'text-faint'}>{b.title}</td>
                <td>{b.locations.map((l) => LOCATIONS[l].short).join(', ')}</td>
                <td className="font-mono">{CORE_BY_ID[b.core].num}</td>
                <td>{st ? <StageBadge s={st} /> : <Badge status="muted">OPENS {b.opened}</Badge>}</td>
                <td><Badge status={ev}>{statusShort(ev)}</Badge></td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {brief && (
        <>
          <Section>{brief.id} · {brief.title.toUpperCase()}</Section>
          <div className="grid grid-cols-[88px_1fr] gap-x-3 gap-y-1.5 text-11.5">
            <span className="font-mono text-9 text-faint">QUESTION</span>
            <span className="text-dim">{brief.question}</span>
            <span className="font-mono text-9 text-faint">DRAFT REC.</span>
            <span className="text-text">{brief.recommendation}</span>
            <span className="font-mono text-9 text-faint">OPENED</span>
            <span className="font-mono text-dim">{brief.opened}{brief.publishedYear ? ` · published ${brief.publishedYear}` : ''}</span>
          </div>
          <Section>LIVE EVIDENCE PANEL · {LOCATIONS[brief.locations[0]].short.toUpperCase()} · {brief.opened} → {year}</Section>
          <table className="dtable">
            <thead><tr><th>SIGNAL</th><th className="num">AT OPENING</th><th className="num">{year}</th><th className="num">DRIFT</th><th>STATUS</th></tr></thead>
            <tbody>
              {brief.evidence.map((id) => {
                const l = brief.locations[0];
                const a = valueAt(id, l, brief.opened);
                const b = valueAt(id, l, year);
                const s = statusAt(id, l, year);
                return (
                  <tr key={id}>
                    <td className="text-text">{SPEC_BY_ID[id].label} <span className="font-mono text-9 text-faint">{SPEC_BY_ID[id].unit}</span></td>
                    <td className="num" style={{ color: 'var(--text-dim)' }}>{fmtSignal(id, a)}</td>
                    <td className="num">{fmtSignal(id, b)}</td>
                    <td className="num" style={{ color: 'var(--text-dim)' }}>{b - a >= 0 ? '+' : ''}{fmtSignal(id, b - a)}</td>
                    <td><Badge status={s}>{statusShort(s)}</Badge></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <Note>Evidence values are pulled from the same series the observatory uses, so a brief&apos;s evidence panel updates when the data does.</Note>
        </>
      )}
    </div>
  );
}

function StageBadge({ s }: { s: Stage }) {
  return <Badge status={s === 'published' ? 'ok' : s === 'drafting' ? 'muted' : 'info'}>{s.toUpperCase()}</Badge>;
}

/* ------------------------------ 04.3 VR/AR Field Visualisation (roadmap only) ------------------------------ */

function VrArRoadmap() {
  const { location } = useOpenDMO();
  return (
    <div>
      <Roadmap>
        <b className="font-mono text-9.5 tracking-meta text-amber">FUTURE CAPABILITY · NOT FUNCTIONAL</b>
        <br />
        This panel is a mockup of a planned field-visualisation module. Nothing here captures, streams, or renders 3D data, and the controls are
        disabled on purpose.
      </Roadmap>

      <Section>MOCKUP · SITE VIEWER · {LOCATIONS[location].short.toUpperCase()}</Section>
      <div className="relative h-[190px] overflow-hidden border border-dashed border-line-strong bg-bg-deep" aria-label="Static mockup illustration">
        <svg viewBox="0 0 400 190" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden>
          <path d="M0,140 L50,110 L95,125 L150,78 L210,108 L260,70 L320,102 L400,84 L400,190 L0,190 Z" fill="none" stroke="var(--text-faint)" strokeDasharray="3 3" />
          <path d="M0,160 L80,140 L160,150 L240,132 L320,146 L400,136" fill="none" stroke="var(--text-faint)" strokeDasharray="2 4" />
          <line x1="200" y1="0" x2="200" y2="190" stroke="var(--border)" />
          <line x1="0" y1="95" x2="400" y2="95" stroke="var(--border)" />
        </svg>
        <span className="absolute left-2 top-2 font-mono text-9 text-faint">WIREFRAME PLACEHOLDER · NO SCENE LOADED</span>
        <span className="absolute bottom-2 right-2 font-mono text-9 text-amber">ROADMAP</span>
      </div>
      <div className="mt-2 flex flex-wrap gap-1" aria-label="Disabled mockup controls">
        {['LOAD 360° CAPTURE', 'OVERLAY SIGNALS', 'AR ANCHOR', 'COMPARE YEARS', 'EXPORT SCENE'].map((l) => (
          <button key={l} className="ctl" disabled title="Planned — not available in this prototype">{l}</button>
        ))}
      </div>

      <Section>PLANNED MILESTONES (INDICATIVE)</Section>
      <table className="dtable">
        <tbody>
          <tr><td className="font-mono text-faint">M1</td><td className="text-text">Georeferenced 360° photo sets per site</td><td>Needs field capture protocol and consent process</td></tr>
          <tr><td className="font-mono text-faint">M2</td><td className="text-text">Signal overlays on captured scenes</td><td>Needs real GIS layers and camera pose metadata</td></tr>
          <tr><td className="font-mono text-faint">M3</td><td className="text-text">Year-over-year visual comparison</td><td>Needs repeat captures from fixed stations</td></tr>
          <tr><td className="font-mono text-faint">M4</td><td className="text-text">Headset / mobile AR field mode</td><td>Needs device testing in low-connectivity conditions</td></tr>
        </tbody>
      </table>
      <Note>Scope decision per CONTRACT.md §3: VR/AR lives inside Research &amp; Policy Lab only and is never presented as working.</Note>
    </div>
  );
}

/* ------------------------------ 04.4 Publication Queue ------------------------------ */

function PublicationQueue() {
  const { location, year } = useOpenDMO();
  const [scope, setScope] = useState<'site' | 'all'>('site');
  const items = PUBLICATIONS.filter((p) => scope === 'all' || p.locations.includes(location))
    .map((p) => ({ p, st: stageAt(p, year) }))
    .filter((x) => x.st !== null) as { p: (typeof PUBLICATIONS)[number]; st: Stage }[];
  const queued = getSignal('publication_queue', location, year);

  return (
    <div>
      <MetricRow cols={4}>
        <Metric s={queued} />
        {(['internal review', 'peer review', 'published'] as Stage[]).map((s) => (
          <div key={s} className="flex flex-col gap-1 bg-panel px-3 py-2">
            <span className="text-10 tracking-[.05em] text-faint">{s[0].toUpperCase() + s.slice(1)}</span>
            <span className="font-mono text-15 text-text">{items.filter((i) => i.st === s).length}</span>
            <span className="font-mono text-9 text-faint">{scope === 'all' ? 'ALL SITES' : LOCATIONS[location].short.toUpperCase()} · {year}</span>
          </div>
        ))}
      </MetricRow>

      <Section
        right={
          <span className="flex gap-1">
            <button className={`ctl${scope === 'site' ? ' on' : ''}`} onClick={() => setScope('site')}>THIS SITE</button>
            <button className={`ctl${scope === 'all' ? ' on' : ''}`} onClick={() => setScope('all')}>ALL SITES</button>
          </span>
        }
      >
        QUEUE BY STAGE · {year}
      </Section>
      <div className="grid grid-cols-4 gap-px border border-line bg-line">
        {STAGES.map((s) => (
          <div key={s} className="min-h-[160px] bg-panel p-2">
            <div className="mb-2 flex items-center justify-between font-mono text-9 tracking-meta text-faint">
              <span>{s.toUpperCase()}</span>
              <span>{items.filter((i) => i.st === s).length}</span>
            </div>
            {items.filter((i) => i.st === s).map(({ p }) => (
              <div key={p.id} className="mb-1.5 border-b border-line pb-1.5">
                <div className="font-mono text-9 text-faint">{p.id} · {p.kind.toUpperCase()}</div>
                <div className="text-11 leading-[1.4] text-text">{p.title}</div>
                <div className="mt-0.5 font-mono text-9 text-dim">{p.datasets.join(' ')} · {p.locations.map((l) => LOCATIONS[l].short).join(', ')}</div>
              </div>
            ))}
          </div>
        ))}
      </div>
      <Note>
        Items appear in the year they were opened and move to published in their publication year. Titles are illustrative; every item cites the
        synthetic dataset IDs it depends on.
      </Note>
    </div>
  );
}
