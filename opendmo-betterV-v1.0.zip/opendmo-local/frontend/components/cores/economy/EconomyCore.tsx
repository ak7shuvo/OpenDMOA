'use client';

import { useMemo, useState } from 'react';
import { LOCATIONS, LOCATION_KEYS } from '@/lib/data/locations';
import { OBSERVATION_YEAR, YEAR_MAX, YEAR_MIN } from '@/lib/data/layers';
import { PROJECTS, REVENUE_MIX, projectStage } from '@/lib/data/registry';
import { confidenceAt, fmt, fmtSignal, getSignal, statusAt, statusFromThresholds, valueAt } from '@/lib/data/series';
import { SPEC_BY_ID } from '@/lib/data/signals';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { confShort, statusColor, statusShort } from '@/lib/theme';
import type { HistoryPoint, LocationKey, Status } from '@/lib/types';
import { HBar } from '../../charts/BarChart';
import { Legend, LineChart } from '../../charts/LineChart';
import { Badge, ConfBadge, Metric, MetricRow, Note, Section, SignalMeta } from '../../shared/ui';
import { CoreFrame } from '../CoreFrame';

export function EconomyCore() {
  return (
    <CoreFrame
      core="economy"
      views={{
        revenue: Revenue,
        scenario: Scenario,
        pipeline: Pipeline,
        growth: Growth,
      }}
    />
  );
}

/* ------------------------------ 03.1 Revenue Signals ------------------------------ */

function Revenue() {
  const { location, setLocation, year } = useOpenDMO();
  const rev = getSignal('revenue_index', location, year);
  const emp = getSignal('employment_index', location, year);
  const cap = getSignal('local_capture', location, year);
  const dem = getSignal('demand_index', location, year);
  const mix = REVENUE_MIX[location];

  return (
    <div>
      <MetricRow cols={4}>
        <Metric s={rev} />
        <Metric s={emp} />
        <Metric s={cap} />
        <Metric s={dem} />
      </MetricRow>

      <Section right={<SignalMeta s={rev} />}>REVENUE &amp; EMPLOYMENT · 2015–2030 · idx (2026 PANEL BASE)</Section>
      <LineChart
        ariaLabel="Revenue and employment index series"
        series={[
          { id: 'r', label: 'Revenue', color: 'var(--green)', points: rev.history },
          { id: 'e', label: 'Employment', color: 'var(--cyan)', points: emp.history },
          { id: 'c', label: 'Local capture %', color: 'var(--amber)', points: cap.history, width: 1.1 },
        ]}
        refs={[{ value: 50, color: 'var(--amber)', label: 'REVENUE WATCH 50' }]}
        year={year}
        height={140}
      />
      <Legend items={[{ label: 'Revenue index', color: 'var(--green)' }, { label: 'Employment index', color: 'var(--cyan)' }, { label: 'Local revenue capture %', color: 'var(--amber)' }]} />

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Section>SPEND COMPOSITION · % (2026 PANEL)</Section>
          {mix.map((m) => <HBar key={m.label} label={m.label} value={m.share} max={50} color="var(--cyan)" right={`${m.share}%`} />)}
        </div>
        <div>
          <Section>WHERE SPEND LANDS · {year}</Section>
          <div className="flex h-[14px] w-full border border-line">
            <span style={{ width: `${cap.value}%`, background: 'var(--green)', opacity: 0.8 }} />
            <span style={{ width: `${100 - cap.value}%`, background: 'var(--text-faint)', opacity: 0.5 }} />
          </div>
          <div className="mt-1 flex justify-between font-mono text-9 text-dim">
            <span style={{ color: 'var(--green)' }}>LOCAL {cap.value}%</span>
            <span>EXTERNAL {100 - cap.value}%</span>
          </div>
          <Note>Local capture counts spend retained by site-resident households and businesses. Below 45% triggers a watch flag.</Note>
        </div>
      </div>

      <Section>ALL SITES · {year}</Section>
      <table className="dtable">
        <thead><tr><th>SITE</th><th className="num">REVENUE</th><th className="num">EMPLOYMENT</th><th className="num">LOCAL CAPTURE</th><th className="num">DEMAND</th></tr></thead>
        <tbody>
          {LOCATION_KEYS.map((k) => (
            <tr key={k} className={`click${k === location ? ' sel' : ''}`} onClick={() => setLocation(k)}>
              <td className="text-text">{LOCATIONS[k].short}</td>
              {['revenue_index', 'employment_index', 'local_capture', 'demand_index'].map((id) => (
                <td key={id} className="num" style={{ color: statusColor(statusAt(id, k, year)) }}>{fmtSignal(id, valueAt(id, k, year))}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------ 03.2 Scenario Modelling ------------------------------ */

type Policy = 'none' | 'cap' | 'phased';
type Pathway = 'low' | 'central' | 'high';
type Inputs = { growth: number; policy: Policy; invest: number; pathway: Pathway };
const BASELINE: Inputs = { growth: 0, policy: 'none', invest: 0, pathway: 'central' };
const CLIMATE_MULT: Record<Pathway, number> = { low: 0.5, central: 1, high: 1.6 };
const SCEN_YEARS = [2026, 2027, 2028, 2029, 2030];

/**
 * Deliberately simple, fully transparent model (documented in the UI):
 *   V(t) = min(V0 + gV·(1+g)·t, cap(t))
 *   P(t) = V(t) / capacity · 55
 *   R(t) = R0 · (V/V0)^0.8 · (1 − 0.01·I) + 0.4·I·t
 *   L(t) = L0 + (gL·climate − 0.3·I)·t
 *   S(t) = S0 + gS·t − 0.3·max(0, P − 60) + 0.2·I·t
 */
function runScenario(loc: LocationKey, inp: Inputs) {
  const cap = LOCATIONS[loc].capacityK;
  const p = (id: string) => SPEC_BY_ID[id].profile![loc];
  const V0 = p('annual_visitors')[0], gV = p('annual_visitors')[2];
  const R0 = p('revenue_index')[0];
  const L0 = p('landslide_susceptibility')[0], gL = p('landslide_susceptibility')[2];
  const S0 = p('community_sentiment')[0], gS = p('community_sentiment')[2];
  return SCEN_YEARS.map((y) => {
    const t = y - OBSERVATION_YEAR;
    const limit = inp.policy === 'none' ? Infinity : inp.policy === 'cap' ? cap : cap * (1 - 0.025 * t);
    const V = Math.max(0, Math.min(V0 + gV * (1 + inp.growth / 100) * t, Math.max(limit, t === 0 ? V0 : 0)));
    const P = (V / cap) * 55;
    const R = R0 * Math.pow(V / V0, 0.8) * (1 - 0.01 * inp.invest) + 0.4 * inp.invest * t;
    const L = Math.min(100, Math.max(0, L0 + (gL * CLIMATE_MULT[inp.pathway] - 0.3 * inp.invest) * t));
    const S = Math.min(100, Math.max(0, S0 + gS * t - 0.3 * Math.max(0, P - 60) + 0.2 * inp.invest * t));
    return { year: y, V, P, R, L, S };
  });
}

const OUT: { key: 'V' | 'P' | 'R' | 'L' | 'S'; id: string; label: string; unit: string }[] = [
  { key: 'V', id: 'annual_visitors', label: 'Annual visitors', unit: "'000" },
  { key: 'P', id: 'visitor_pressure', label: 'Visitor pressure', unit: 'idx' },
  { key: 'R', id: 'revenue_index', label: 'Revenue index', unit: 'idx' },
  { key: 'L', id: 'landslide_susceptibility', label: 'Landslide index', unit: 'idx' },
  { key: 'S', id: 'community_sentiment', label: 'Community sentiment', unit: 'idx' },
];

function Scenario() {
  const { location, year } = useOpenDMO();
  const [inp, setInp] = useState<Inputs>(BASELINE);
  const base = useMemo(() => runScenario(location, BASELINE), [location]);
  const scen = useMemo(() => runScenario(location, inp), [location, inp]);
  const loc = LOCATIONS[location];
  const statusOf = (id: string, v: number): Status => (id === 'annual_visitors' ? statusFromThresholds(SPEC_BY_ID.visitor_pressure, (v / loc.capacityK) * 55) : statusFromThresholds(SPEC_BY_ID[id], v));
  const toPts = (rows: ReturnType<typeof runScenario>, k: 'P' | 'R' | 'L'): HistoryPoint[] => rows.map((r) => ({ year: r.year, value: +r[k].toFixed(1) }));
  const firstCross = (rows: ReturnType<typeof runScenario>, id: string, k: 'P' | 'L' | 'S', level: 'watch' | 'risk') =>
    rows.find((r) => {
      const s = statusFromThresholds(SPEC_BY_ID[id], r[k]);
      return level === 'watch' ? s !== 'ok' : s === 'risk';
    })?.year;

  const last = scen[scen.length - 1];
  const lastB = base[base.length - 1];
  const pWatch = firstCross(scen, 'visitor_pressure', 'P', 'watch');
  const lRisk = firstCross(scen, 'landslide_susceptibility', 'L', 'risk');
  const revDelta = ((last.R / lastB.R) - 1) * 100;
  const changed = JSON.stringify(inp) !== JSON.stringify(BASELINE);
  const worst: Status = [statusOf('visitor_pressure', last.P), statusOf('landslide_susceptibility', last.L), statusOf('community_sentiment', last.S)].reduce<Status>(
    (a, b) => (b === 'risk' || (b === 'watch' && a === 'ok') ? b : a), 'ok');

  return (
    <div>
      <Section right={<button className="ctl" onClick={() => setInp(BASELINE)} disabled={!changed}>RESET TO BASELINE</button>}>
        SCENARIO INPUTS · {loc.short.toUpperCase()} · 2026 → 2030
      </Section>
      <div className="grid grid-cols-2 gap-x-5 gap-y-3 text-11">
        <label className="flex flex-col gap-1">
          <span className="flex justify-between text-dim">Visitor growth vs baseline trend <span className="font-mono text-cyan">{inp.growth > 0 ? '+' : ''}{inp.growth}%</span></span>
          <input type="range" className="rng" min={-100} max={150} step={10} value={inp.growth} onChange={(e) => setInp({ ...inp, growth: +e.target.value })} />
        </label>
        <label className="flex flex-col gap-1">
          <span className="flex justify-between text-dim">Conservation reinvestment <span className="font-mono text-cyan">{inp.invest}% of revenue</span></span>
          <input type="range" className="rng" min={0} max={5} step={0.5} value={inp.invest} onChange={(e) => setInp({ ...inp, invest: +e.target.value })} />
        </label>
        <div className="flex flex-col gap-1">
          <span className="text-dim">Capacity policy</span>
          <div className="flex gap-1">
            {([['none', 'No cap'], ['cap', 'At capacity'], ['phased', 'Phased']] as [Policy, string][]).map(([k, l]) => (
              <button key={k} className={`ctl${inp.policy === k ? ' on' : ''}`} onClick={() => setInp({ ...inp, policy: k })} aria-pressed={inp.policy === k} title={k === 'phased' ? 'Cap falls 2.5% of capacity per year' : undefined}>{l.toUpperCase()}</button>
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-1">
          <span className="text-dim">Climate pathway (hazard trend)</span>
          <div className="flex gap-1">
            {(['low', 'central', 'high'] as Pathway[]).map((k) => (
              <button key={k} className={`ctl${inp.pathway === k ? ' on' : ''}`} onClick={() => setInp({ ...inp, pathway: k })} aria-pressed={inp.pathway === k}>
                {k.toUpperCase()} ×{CLIMATE_MULT[k]}
              </button>
            ))}
          </div>
        </div>
      </div>

      <Section>DECISION READOUT · 2030</Section>
      <div className={`intel-alert${worst === 'risk' ? ' risk' : worst === 'ok' ? ' ok' : ''}`}>
        <span className="ai">{worst === 'risk' ? '⚠' : worst === 'watch' ? '△' : '✓'}</span>
        <span className="text-11.5 text-dim">
          {pWatch === OBSERVATION_YEAR ? <>Visitor pressure is already at the watch level in {OBSERVATION_YEAR}; this scenario {last.P < 60 ? 'brings it back below' : 'keeps it above'} the threshold by 2030. </> : pWatch ? <>Visitor pressure reaches the watch level in <b className="font-mono text-text">{pWatch}</b>. </> : <>Visitor pressure stays below the watch level through 2030. </>}
          {lRisk === OBSERVATION_YEAR ? <>Landslide susceptibility is already in the risk band. </> : lRisk ? <>Landslide susceptibility enters the risk band in <b className="font-mono text-text">{lRisk}</b>. </> : <>Landslide susceptibility stays out of the risk band. </>}
          Revenue in 2030 is <b className="font-mono text-text">{revDelta >= 0 ? '+' : ''}{revDelta.toFixed(1)}%</b> against baseline.
        </span>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {(['P', 'R', 'L'] as const).map((k) => {
          const o = OUT.find((x) => x.key === k)!;
          const t = SPEC_BY_ID[o.id].thresholds!;
          return (
            <div key={k}>
              <Section>{o.label.toUpperCase()}</Section>
              <LineChart
                ariaLabel={`${o.label}: baseline versus scenario`}
                series={[
                  { id: 'b', label: 'Baseline', color: 'var(--text-faint)', points: toPts(base, k), dashed: true },
                  { id: 's', label: 'Scenario', color: 'var(--cyan)', points: toPts(scen, k) },
                ]}
                refs={[{ value: t.watch, color: 'var(--amber)', label: `W ${t.watch}` }]}
                height={110}
              />
            </div>
          );
        })}
      </div>
      <Legend items={[{ label: 'Baseline (trend)', color: 'var(--text-faint)', dashed: true }, { label: 'This scenario', color: 'var(--cyan)' }]} />

      <Section>2030 OUTCOMES</Section>
      <table className="dtable">
        <thead><tr><th>OUTPUT</th><th className="num">2026</th><th className="num">BASELINE 2030</th><th className="num">SCENARIO 2030</th><th>STATUS</th></tr></thead>
        <tbody>
          {OUT.map((o) => {
            const s = statusOf(o.id, last[o.key]);
            return (
              <tr key={o.key}>
                <td className="text-text">{o.label} <span className="font-mono text-9 text-faint">{o.unit}</span></td>
                <td className="num" style={{ color: 'var(--text-dim)' }}>{fmt(scen[0][o.key], 0)}</td>
                <td className="num" style={{ color: 'var(--text-dim)' }}>{fmt(lastB[o.key], 0)}</td>
                <td className="num">{fmt(last[o.key], 0)}</td>
                <td><Badge status={s}>{statusShort(s)}</Badge></td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <Note>
        Transparent toy model for exploring trade-offs, not a calibrated forecast. Visitors V = min(V₀ + trend·(1+g)·t, cap); pressure = V/capacity·55;
        revenue = R₀·(V/V₀)^0.8·(1−0.01·I) + 0.4·I·t; landslide = L₀ + (trend·climate − 0.3·I)·t; sentiment falls 0.3 pts per pressure point above 60.
        {year !== OBSERVATION_YEAR && ` Scenarios always start from the ${OBSERVATION_YEAR} observation, whatever year the slider shows.`}
      </Note>
    </div>
  );
}

/* ------------------------------ 03.3 Infrastructure Pipeline ------------------------------ */

function Pipeline() {
  const { location, year, layers, setLayer } = useOpenDMO();
  const [scope, setScope] = useState<'site' | 'all'>('site');
  const readiness = getSignal('infra_readiness', location, year);
  const active = getSignal('investment_pipeline', location, year);
  const rows = PROJECTS.filter((p) => scope === 'all' || p.location === location).map((p) => ({ p, stage: projectStage(p, year) }));
  const activeCost = rows.filter((r) => r.stage === 'construction').reduce((a, r) => a + r.p.costCr, 0);
  const span = YEAR_MAX - YEAR_MIN;
  const pct = (y: number) => ((y - YEAR_MIN) / span) * 100;

  return (
    <div>
      <MetricRow cols={3}>
        <Metric s={readiness} />
        <Metric s={active} />
        <div className="flex flex-col gap-1 bg-panel px-3 py-2">
          <span className="text-10 tracking-[.05em] text-faint">Under Construction · {scope === 'all' ? 'All Sites' : 'This Site'}</span>
          <span className="font-mono text-15 text-text">{activeCost} <span className="text-10 text-faint">BDT cr</span></span>
          <span className="font-mono text-9 text-faint">SYN-v0.5 · pipeline registry</span>
        </div>
      </MetricRow>

      <Section
        right={
          <span className="flex gap-1">
            <button className={`ctl${scope === 'site' ? ' on' : ''}`} onClick={() => setScope('site')}>THIS SITE</button>
            <button className={`ctl${scope === 'all' ? ' on' : ''}`} onClick={() => setScope('all')}>ALL SITES</button>
            <button className={`ctl${layers.infrastructure ? ' on' : ''}`} onClick={() => setLayer('infrastructure', !layers.infrastructure)}>
              {layers.infrastructure ? 'HIDE' : 'SHOW'} ON MAP
            </button>
          </span>
        }
      >
        PROJECTS · STAGE IN {year}
      </Section>
      <table className="dtable">
        <thead><tr><th>ID</th><th>PROJECT</th>{scope === 'all' && <th>SITE</th>}<th>STAGE</th><th className="w-[36%]">TIMELINE 2015–2030</th><th className="num">BDT CR</th><th>EXPOSURE</th></tr></thead>
        <tbody>
          {rows.map(({ p, stage }) => (
            <tr key={p.id}>
              <td className="font-mono text-9.5 text-faint">{p.id}</td>
              <td className={stage ? 'text-text' : 'text-faint'}>{p.name}</td>
              {scope === 'all' && <td>{LOCATIONS[p.location].short}</td>}
              <td>
                {stage === null ? <Badge status="muted">NOT LISTED</Badge> : stage === 'planned' ? <Badge status="muted">PLANNED</Badge> : stage === 'construction' ? <Badge status="info">BUILDING</Badge> : <Badge status="ok">COMPLETE</Badge>}
              </td>
              <td>
                <div className="relative h-[10px] bg-bg-deep" aria-label={`${p.start} to ${p.end}`}>
                  <span className="absolute inset-y-[2px]" style={{ left: `${pct(p.start)}%`, width: `${pct(p.end) - pct(p.start)}%`, background: 'var(--cyan)', opacity: stage === 'complete' ? 0.9 : 0.45 }} />
                  <span className="absolute inset-y-0 w-px" style={{ left: `${pct(year)}%`, background: year > OBSERVATION_YEAR ? 'var(--amber)' : 'var(--text)' }} />
                </div>
                <div className="flex justify-between font-mono text-9 text-faint"><span>{p.start}</span><span>{p.end}</span></div>
              </td>
              <td className="num">{p.costCr}</td>
              <td><Badge status={p.exposure}>{statusShort(p.exposure)}</Badge></td>
            </tr>
          ))}
        </tbody>
      </table>
      <Note>
        Stage is re-derived from the selected year: listed two years before start, building between start and end, complete after. Exposure is the
        project&apos;s hazard exposure. Project names and costs are illustrative.
      </Note>
    </div>
  );
}

/* ------------------------------ 03.4 Growth Forecast ------------------------------ */

function fan(points: HistoryPoint[], k80: number, k95: number) {
  const f = points.filter((p) => p.year >= OBSERVATION_YEAR);
  return {
    b95: f.map((p) => ({ year: p.year, lo: p.value * (1 - k95 * (p.year - OBSERVATION_YEAR)), hi: p.value * (1 + k95 * (p.year - OBSERVATION_YEAR)) })),
    b80: f.map((p) => ({ year: p.year, lo: p.value * (1 - k80 * (p.year - OBSERVATION_YEAR)), hi: p.value * (1 + k80 * (p.year - OBSERVATION_YEAR)) })),
  };
}

function Growth() {
  const { location, year } = useOpenDMO();
  const vis = getSignal('annual_visitors', location, year);
  const rev = getSignal('revenue_index', location, year);
  const fv = fan(vis.history, 0.05, 0.09);
  const fr = fan(rev.history, 0.04, 0.075);
  const cap = LOCATIONS[location].capacityK;

  return (
    <div>
      <Section right={<SignalMeta s={vis} />}>VISITOR FORECAST · &apos;000 · 80% / 95% BANDS</Section>
      <LineChart
        ariaLabel="Visitor forecast fan chart"
        series={[{ id: 'v', label: 'Visitors', color: 'var(--green)', points: vis.history }]}
        bands={[{ color: 'rgba(111,191,148,0.07)', points: fv.b95 }, { color: 'rgba(111,191,148,0.13)', points: fv.b80 }]}
        refs={[{ value: cap, color: 'var(--red)', label: `CAPACITY ${cap}k` }]}
        year={year}
        height={140}
      />
      <Section right={<SignalMeta s={rev} />}>REVENUE INDEX FORECAST · 80% / 95% BANDS</Section>
      <LineChart
        ariaLabel="Revenue forecast fan chart"
        series={[{ id: 'r', label: 'Revenue', color: 'var(--cyan)', points: rev.history }]}
        bands={[{ color: 'rgba(111,179,199,0.07)', points: fr.b95 }, { color: 'rgba(111,179,199,0.13)', points: fr.b80 }]}
        year={year}
        height={120}
      />

      <Section>FORECAST TABLE</Section>
      <table className="dtable">
        <thead><tr><th>YEAR</th><th className="num">VISITORS LOW</th><th className="num">CENTRAL</th><th className="num">HIGH</th><th>PRESSURE (CENTRAL)</th><th className="num">REVENUE</th><th>CONF</th></tr></thead>
        <tbody>
          {[2027, 2028, 2029, 2030].map((y, i) => {
            const b = fv.b80[i + 1];
            const central = valueAt('annual_visitors', location, y);
            const ps = statusAt('visitor_pressure', location, y);
            return (
              <tr key={y} className={y === year ? 'sel' : ''}>
                <td className="font-mono text-text">{y}</td>
                <td className="num" style={{ color: 'var(--text-dim)' }}>{fmt(b.lo, 0)}</td>
                <td className="num">{fmt(central, 0)}</td>
                <td className="num" style={{ color: 'var(--text-dim)' }}>{fmt(b.hi, 0)}</td>
                <td><Badge status={ps}>PI {fmtSignal('visitor_pressure', valueAt('visitor_pressure', location, y))}</Badge></td>
                <td className="num">{fmtSignal('revenue_index', valueAt('revenue_index', location, y))}</td>
                <td><ConfBadge c={confidenceAt('moderate', y)} /></td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <Note>
        Central path is the series engine&apos;s trend projection. Bands widen ±5% (80%) and ±9% (95%) per projected year for visitors — heuristic
        spreads, not statistically estimated intervals. Confidence steps down every two years beyond {OBSERVATION_YEAR} (currently{' '}
        {confShort(confidenceAt('moderate', 2030))} by 2030).
      </Note>
    </div>
  );
}
