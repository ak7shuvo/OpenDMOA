'use client';

import { useMemo } from 'react';
import { CORE_BY_ID } from '@/lib/data/cores';
import { LOCATIONS, LOCATION_KEYS } from '@/lib/data/locations';
import { DATASET_VERSION, OBSERVATION_YEAR, SNAPSHOT_ISO } from '@/lib/data/layers';
import { deltaAt, fmtSignal, getSignal } from '@/lib/data/series';
import { tickerItems } from '@/lib/data/warnings';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { confShort, statusColor } from '@/lib/theme';
import type { LocationKey } from '@/lib/types';
import { Sparkline } from '../charts/Sparkline';
import { LiveClock } from '../shared/LiveClock';

export function MonitoringStrip() {
  const { activeCore, location, year, setLocation, submodule } = useOpenDMO();
  const core = CORE_BY_ID[activeCore];
  const sub = core.sub.find((s) => s.id === submodule[activeCore]);
  const signals = useMemo(() => core.strip.map((id) => getSignal(id, location, year)), [core, location, year]);
  const proj = year > OBSERVATION_YEAR;
  const snap = new Date(SNAPSHOT_ISO);
  const MON = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const snapLabel = `${snap.getUTCDate()} ${MON[snap.getUTCMonth()]} ${SNAPSHOT_ISO.slice(11, 16)} UTC`;

  return (
    <section className="monitor" aria-label="Monitoring">
      <div className="monitor-top">
        <div className="field">
          <label htmlFor="loc">LOCATION</label>
          <select id="loc" className="loc-select" value={location} onChange={(e) => setLocation(e.target.value as LocationKey)}>
            {LOCATION_KEYS.map((k) => (
              <option key={k} value={k}>
                {LOCATIONS[k].name}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <span className="lbl">OBSERVATION YEAR</span>
          <span className="temporal-val" style={{ color: proj ? 'var(--amber)' : 'var(--cyan)' }}>
            {year}
            {proj ? ' (proj.)' : year < OBSERVATION_YEAR ? ' (hist.)' : ''}
          </span>
        </div>
        <div className="field">
          <span className="lbl">DATA SNAPSHOT</span>
          <span className="temporal-val" title={`${DATASET_VERSION}. Fixed snapshot — not refreshed from any live source.`}>
            {snapLabel}
          </span>
        </div>
        <div className="module-context">
          <span className="mlabel">ACTIVE MODULE</span>
          <span className="mname">
            {core.num} · {core.name}
            {sub ? <span className="text-dim"> / {sub.name}</span> : null}
          </span>
        </div>
        <div className="live-indicator" title="All values are simulated. The clock is your local time.">
          <span className="pulse" />
          SIMULATED · <LiveClock />
        </div>
      </div>

      <div className="signals">
        {signals.map((s) => {
          const d = deltaAt(s.id, location, year);
          const c = statusColor(s.status);
          return (
            <div key={s.id} className="signal" title={`${s.label} — ${s.source}`}>
              <div className="signal-head">
                <span className="signal-label">{s.label}</span>
                <span className="signal-flag" style={{ background: c, boxShadow: `0 0 5px ${c}` }} aria-label={s.status} />
              </div>
              <div>
                <div className="signal-value-row">
                  <span className="signal-value" style={{ color: proj ? 'var(--text-dim)' : undefined }}>{fmtSignal(s.id, s.value)}</span>
                  <span className="signal-unit">{s.unit}</span>
                </div>
                <Sparkline history={s.history} year={year} color={c} />
                <div className="signal-delta" style={{ color: s.status === 'risk' ? 'var(--red)' : d >= 0 ? 'var(--green)' : 'var(--amber)' }}>
                  {d >= 0 ? '+' : ''}
                  {fmtSignal(s.id, d)} vs {year - 1}
                </div>
                <div className="signal-meta">
                  {proj ? 'PROJ' : 'SYN'} · CONF {confShort(s.confidence)}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <Ticker year={year} />
    </section>
  );
}

function Ticker({ year }: { year: number }) {
  const items = useMemo(() => tickerItems(year), [year]);
  return (
    <div className="ticker" aria-label="Rule-derived alerts">
      <div className="ticker-track" key={year}>
        {[...items, ...items].map((t, i) => (
          <span className="it" key={i} aria-hidden={i >= items.length}>
            <span style={{ color: t.startsWith('ALERT') ? 'var(--red)' : t.startsWith('ADVISORY') ? 'var(--amber)' : 'var(--text-faint)' }}>▸</span> {t}
          </span>
        ))}
      </div>
    </div>
  );
}
