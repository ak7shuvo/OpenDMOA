"use client";

/**
 * OPERATIONS · Model Lab — the model runtime surface:
 *   installed models → available (approved GitHub) models → install/update
 *   → inspect metadata & requirements → enable/disable → schema-driven input
 *   form → RUN locally → output + full provenance → run history.
 * No ML logic lives here: the form is generated from each model's schema.json
 * and execution happens only on the backend runtime.
 */
import { useCallback, useEffect, useState } from 'react';
import { api, ApiOfflineError } from '@/lib/api/client';
import type { ApiAvailableModel, ApiDestination, ApiModel, ApiModelRunResult } from '@/lib/api/types';
import { DEMO_DESTINATIONS, DEMO_MODEL } from '@/lib/api/demo';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import type { LocationKey } from '@/lib/types';
import { ProvenanceBlock } from '../shared/ProvenanceBlock';
import { OpsFrame, OpsSection } from './OpsFrame';

export function ModelLab() {
  const { location, setLocation } = useOpenDMO();
  const [models, setModels] = useState<ApiModel[]>([DEMO_MODEL]);
  const [available, setAvailable] = useState<ApiAvailableModel[]>([]);
  const [dests, setDests] = useState<ApiDestination[]>(DEMO_DESTINATIONS);
  const [demo, setDemo] = useState(true);
  const [selectedId, setSelectedId] = useState(DEMO_MODEL.id);
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [datasetId, setDatasetId] = useState('');
  const [result, setResult] = useState<ApiModelRunResult | null>(null);
  const [runs, setRuns] = useState<ApiModelRunResult[]>([]);
  const [installRepo, setInstallRepo] = useState('opendmo-models/demo-tourism-demand');
  const [installRef, setInstallRef] = useState('main');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(() => {
    api
      .get<ApiModel[]>('/api/models')
      .then((m) => {
        setModels(m);
        setDemo(false);
        setSelectedId((s) => (m.some((x) => x.id === s) ? s : (m[0]?.id ?? '')));
      })
      .catch((e) => {
        if (!(e instanceof ApiOfflineError)) setError(String(e));
      });
    api.get<ApiAvailableModel[]>('/api/models/available').then(setAvailable).catch(() => {});
    api.get<ApiDestination[]>('/api/destinations').then(setDests).catch(() => {});
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const model = models.find((m) => m.id === selectedId) ?? null;

  useEffect(() => {
    if (demo) return;
    api
      .get<ApiModelRunResult[]>(`/api/models/runs?destination_id=${location}&limit=20`)
      .then(setRuns)
      .catch(() => {});
  }, [demo, location, result]);

  async function act(fn: () => Promise<unknown>, okMsg?: string) {
    setError(null);
    setNotice(null);
    setBusy(true);
    try {
      await fn();
      if (okMsg) setNotice(okMsg);
      load();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  const install = () => act(async () => {
    await api.post('/api/models/install', { repo: installRepo.trim(), ref: installRef.trim() || 'main' });
  }, 'model package installed & registered');

  const setStatus = (m: ApiModel, status: 'enabled' | 'disabled') =>
    act(() => api.post(`/api/models/${m.id}/status`, { version: m.version, status }), `model ${status}`);

  const run = () =>
    act(async () => {
      if (!model) throw new Error('select a model first');
      const numeric: Record<string, number> = {};
      for (const v of model.input_variables) {
        const raw = inputs[v.name];
        if (raw == null || raw.trim() === '') {
          if (v.required !== false) throw new Error(`missing input: ${v.label ?? v.name}`);
          continue;
        }
        numeric[v.name] = Number(raw);
      }
      const r = await api.post<ApiModelRunResult>('/api/models/run', {
        model_id: model.id,
        model_version: model.version,
        destination_id: location,
        inputs: numeric,
        dataset_id: datasetId.trim() || null,
      });
      setResult(r);
    });

  const readonly = demo;

  return (
    <OpsFrame
      kicker="OPS"
      title="Model Lab"
      right={demo ? <span className="badge watch">DEMO CONTRACT — RUNS NEED LOCAL API</span> : undefined}
    >
      <OpsSection right={
        <label className="flex items-center gap-2 font-mono text-9 tracking-meta text-faint">
          DESTINATION
          <select className="loc-select" value={location} onChange={(e) => setLocation(e.target.value as LocationKey)}>
            {dests.map((d) => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
        </label>
      }>
        INSTALLED MODELS
      </OpsSection>
      <div className="ops-list">
        {models.map((m) => (
          <div key={`${m.id}@${m.version}`} className={`ops-list-row${m.id === selectedId ? ' sel' : ''}`}
            onClick={() => { setSelectedId(m.id); setResult(null); }} role="button" tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && setSelectedId(m.id)}>
            <span className="font-mono text-9 tracking-data">{m.id} v{m.version}</span>
            <span>{m.name}</span>
            <span className="badge muted">{m.framework}</span>
            <span className={`badge ${m.status === 'enabled' ? 'ok' : 'muted'}`}>{m.status.toUpperCase()}</span>
            <button
              className="ops-mini"
              disabled={readonly}
              onClick={(e) => { e.stopPropagation(); setStatus(m, m.status === 'enabled' ? 'disabled' : 'enabled'); }}
            >
              {m.status === 'enabled' ? 'DISABLE' : 'ENABLE'}
            </button>
          </div>
        ))}
      </div>

      <OpsSection>INSTALL FROM APPROVED GITHUB REPOSITORY</OpsSection>
      <div className="ops-form">
        <div className="ops-inline">
          <input className="ops-input grow" value={installRepo} disabled={readonly} onChange={(e) => setInstallRepo(e.target.value)} placeholder="owner/repo" />
          <input className="ops-input w-24" value={installRef} disabled={readonly} onChange={(e) => setInstallRef(e.target.value)} placeholder="main" />
          <button className="ops-btn" onClick={install} disabled={readonly || busy}>INSTALL / UPDATE</button>
        </div>
        {available.length > 0 && (
          <div className="ops-note">
            Approved: {available.map((a) => `${a.repo}@${a.ref}`).join(' · ')}. Packages are validated against the
            model package contract before registration; package code is never executed at install time (docs/MODEL-INSTALL.md).
          </div>
        )}
      </div>

      {model && (
        <>
          <OpsSection right={<span className="badge muted">{model.license} · {model.source_repo}</span>}>
            MODEL — {model.name.toUpperCase()} v{model.version}
          </OpsSection>
          <p className="ops-note">{model.description}</p>
          {model.training_data && <p className="ops-note">TRAINING DATA: {model.training_data}</p>}

          <OpsSection>INPUTS — SCHEMA-DRIVEN</OpsSection>
          <div className="ops-form">
            {model.input_variables.map((v) => (
              <label key={v.name} className="ops-field">
                <span className="ops-label">
                  {v.label ?? v.name}
                  {v.unit ? ` · ${v.unit}` : ''}
                  {v.required !== false ? ' *' : ''}
                </span>
                <input
                  className="ops-input"
                  type="number"
                  step="any"
                  min={v.min ?? undefined}
                  max={v.max ?? undefined}
                  value={inputs[v.name] ?? ''}
                  disabled={readonly}
                  onChange={(e) => setInputs((s) => ({ ...s, [v.name]: e.target.value }))}
                />
              </label>
            ))}
            <label className="ops-field">
              <span className="ops-label">LINK DATASET (PROVENANCE, OPTIONAL)</span>
              <input className="ops-input" value={datasetId} disabled={readonly} onChange={(e) => setDatasetId(e.target.value)} placeholder="JAF-MONTHLY-INDICATORS-01" />
            </label>
            <button className="ops-btn run" onClick={run} disabled={readonly || busy || model.status !== 'enabled'}>
              RUN MODEL LOCALLY
            </button>
            {model.status !== 'enabled' && <span className="badge muted">MODEL DISABLED</span>}
          </div>

          {result && (
            <>
              <OpsSection right={<span className={`badge ${result.status === 'success' ? 'ok' : 'risk'}`}>{result.status.toUpperCase()}</span>}>
                OUTPUT
              </OpsSection>
              <div className="kv-block">
                {Object.entries(result.outputs).map(([k, v]) => (
                  <div className="prov-row" key={k}>
                    <span className="prov-k">{model.output_variables.find((o) => o.name === k)?.label ?? k}</span>
                    <span className="prov-v">
                      {typeof v === 'object' && v !== null ? `${(v as { value?: unknown }).value} ${(v as { unit?: string }).unit ?? ''}` : String(v)}
                    </span>
                  </div>
                ))}
                {result.error && <div className="ops-msg err">{result.error}</div>}
              </div>
              <ProvenanceBlock prov={result} />
            </>
          )}
        </>
      )}

      <OpsSection>RECENT RUNS — THIS DESTINATION</OpsSection>
      {runs.length ? (
        <div className="ops-list">
          {runs.map((r) => (
            <div key={r.run_id} className="ops-list-row">
              <span className="font-mono text-9 tracking-data">{r.run_id}</span>
              <span>{r.method.id} v{r.method.version}</span>
              <span className={`badge ${r.status === 'success' ? 'ok' : 'risk'}`}>{r.status}</span>
              <span className="font-mono text-9 tracking-data text-faint">{r.timestamp ? new Date(r.timestamp).toLocaleString() : ''}</span>
            </div>
          ))}
        </div>
      ) : (
        <div className="ops-note">{demo ? 'Demo mode: run history requires the local API.' : 'No runs recorded for this destination yet.'}</div>
      )}

      {notice && <div className="ops-msg ok">{notice}</div>}
      {error && <div className="ops-msg err">{error}</div>}
      <p className="ops-note">
        Execution is local; inputs, outputs, model version, dataset link and timestamp are recorded in{' '}
        <code>model_runs</code> for reproducibility (docs/PROVENANCE.md). Only whitelisted artifact formats are
        loadable — arbitrary downloaded code is never executed.
      </p>
    </OpsFrame>
  );
}
