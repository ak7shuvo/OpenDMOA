"use client";

/**
 * OPERATIONS · GIS — layer registry and spatial context.
 * The map in the left panel remains SCHEMATIC until a real map provider is
 * integrated; every demo layer stays clearly labelled as such (CONTRACT §7).
 */
import { LAYERS } from '@/lib/data/layers';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { LOCATIONS } from '@/lib/data/locations';
import { OpsFrame, OpsSection } from './OpsFrame';

export function GisOps() {
  const { layers, toggleLayer, location } = useOpenDMO();
  return (
    <OpsFrame kicker="OPS" title="GIS" right={<span className="badge watch">SCHEMATIC MAP — NOT LIVE GIS</span>}>
      <OpsSection right={<span className="font-mono text-9 tracking-data text-faint">DESTINATION · {LOCATIONS[location].name.toUpperCase()}</span>}>
        LAYER REGISTRY
      </OpsSection>
      <div className="ops-list">
        {LAYERS.map((l) => (
          <div key={l.id} className="ops-list-row">
            <button className={`layer-btn${layers[l.id] ? ' on' : ''}`} onClick={() => toggleLayer(l.id)} aria-pressed={layers[l.id]}>
              {l.name}
            </button>
            <span className="ops-list-desc">{l.describes}</span>
            <span className="badge muted">DEMO GEOMETRY</span>
          </div>
        ))}
      </div>
      <OpsSection>SPATIAL CONTEXT POLICY</OpsSection>
      <p className="ops-note">
        All geometry currently shown is synthetic and schematic — it is not survey-grade, not to scale,
        and not a live feed. When PostGIS is enabled, layers in <code>gis_layers</code> (see{' '}
        <code>database/schema.sql</code>) can hold real geometries associated with destinations, datasets
        and model results. Until then, nothing on this page claims live GIS data. Optional approximate
        browser location is documented in docs/PRIVACY.md and is never transmitted externally.
      </p>
    </OpsFrame>
  );
}
