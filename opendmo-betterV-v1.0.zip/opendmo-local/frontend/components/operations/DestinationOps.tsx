"use client";

/**
 * OPERATIONS · Destination — the authoritative analytical context.
 * Selecting a destination here updates the shared context (GIS, monitoring,
 * analytical panels, data-entry and model-input context on the other pages).
 */
import { useEffect, useState } from 'react';
import { api, ApiOfflineError } from '@/lib/api/client';
import type { ApiDestination } from '@/lib/api/types';
import { DEMO_DESTINATIONS } from '@/lib/api/demo';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { LOCATIONS } from '@/lib/data/locations';
import type { LocationKey } from '@/lib/types';
import { OpsFrame, OpsSection } from './OpsFrame';

export function DestinationOps() {
  const { location, setLocation } = useOpenDMO();
  const [dests, setDests] = useState<ApiDestination[]>(DEMO_DESTINATIONS);
  const [demo, setDemo] = useState(true);

  useEffect(() => {
    api
      .get<ApiDestination[]>('/api/destinations')
      .then((d) => {
        setDests(d);
        setDemo(false);
      })
      .catch((e) => {
        if (!(e instanceof ApiOfflineError)) console.error(e);
      });
  }, []);

  const active = dests.find((d) => d.id === location) ?? dests[0];
  const localDef = LOCATIONS[location as LocationKey];

  return (
    <OpsFrame kicker="OPS" title="Destination" right={demo ? <span className="badge watch">SAMPLE RECORDS</span> : undefined}>
      <OpsSection right={<span className="font-mono text-9 tracking-data text-faint">{dests.length} destinations</span>}>
        PILOT DESTINATIONS — CONTRACT §4 FIXED SET
      </OpsSection>
      <div className="ops-grid">
        {dests.map((d) => (
          <button
            key={d.id}
            className={`dest-card${d.id === location ? ' on' : ''}`}
            onClick={() => setLocation(d.id as LocationKey)}
            aria-pressed={d.id === location}
          >
            <span className="font-mono text-9 tracking-meta text-faint">{d.id.toUpperCase()}</span>
            <span className="dest-name">{d.name}</span>
            <span className="text-9 text-faint">{d.region}</span>
            {d.capacity_k != null && <span className="font-mono text-9 tracking-data text-dim">CAPACITY ≈ {d.capacity_k}K/YR</span>}
          </button>
        ))}
      </div>

      <OpsSection>ACTIVE CONTEXT</OpsSection>
      <div className="kv-block">
        <div className="prov-row"><span className="prov-k">DESTINATION</span><span className="prov-v">{active?.name}</span></div>
        <div className="prov-row"><span className="prov-k">REGION</span><span className="prov-v">{active?.region}</span></div>
        <div className="prov-row"><span className="prov-k">COORDINATES</span><span className="prov-v">{active?.latitude ?? '—'}°, {active?.longitude ?? '—'}° (approximate)</span></div>
        <div className="prov-row"><span className="prov-k">MODELLED CAPACITY</span><span className="prov-v">{active?.capacity_k != null ? `${active.capacity_k},000 visitors/yr` : 'not modelled'}</span></div>
        {localDef && (
          <>
            <div className="prov-row"><span className="prov-k">ENVIRONMENT</span><span className="prov-v">{localDef.envChange}</span></div>
            <div className="prov-row"><span className="prov-k">PRESSURE</span><span className="prov-v">{localDef.tourismPressure}</span></div>
          </>
        )}
      </div>
      <p className="ops-note">
        The researcher-selected destination is the authoritative analytical context. It drives the GIS
        panel, monitoring strip, all four analytical cores, and is the default destination on the Data
        Operations and Model Lab pages. Browser/network location is never used as a substitute (see
        docs/PRIVACY.md).
      </p>
    </OpsFrame>
  );
}
