"use client";

/**
 * OPERATIONS · Data Operations — researcher-facing data workflow:
 *   create dataset (metadata-driven variable definitions)
 *   → enter observations (form generated from variable defs)
 *   → import CSV/JSON → validate → quality indicators → versioned registry.
 * Falls back to clearly-labelled demo fixtures when the local API is offline.
 * This is a research/DMO workstation surface, not a generic CRUD grid.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { api, ApiOfflineError } from '@/lib/api/client';
import type { ApiDataset, ApiObservation, ApiQuality, ApiVariableDef } from '@/lib/api/types';
import { DEMO_DATASETS, DEMO_DESTINATIONS, DEMO_QUALITY, DEMO_VARIABLES } from '@/lib/api/demo';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import type { LocationKey } from '@/lib/types';
import { OpsFrame, OpsSection } from './OpsFrame';

/** Preset variable library — datasets define their own; these are starters. */
const VARIABLE_LIBRARY: ApiVariableDef[] = DEMO_VARIABLES;

export function DataOps() {
  const { location } = useOpenDMO();
  const [datasets, setDatasets] = useState<ApiDataset[]>(DEMO_DATASETS);
  const [demo, setDemo] = useState(true);
  const [selected, setSelected] = useState<string>(DEMO_DATASETS[0]?.id ?? '');
  const [observations, setObservations] = useState<ApiObservation[]>([]);
  const [quality, setQuality] = useState<ApiQuality | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // create-dataset form
  const [dsName, setDsName] = useState('Monthly Indicators');
  const [pickedVars, setPickedVars] = useState<Set<string>>(new Set(['visitors', 'hotel_occupancy', 'rainfall']));
  const [customVar, setCustomVar] = useState({ name: '', label: '', unit: '' });

  // entry form state: period + {var: value-string}
  const [period, setPeriod] = useState('2026-09');
  const [entry, setEntry] = useState<Record<string, string>>({});

  // import state
  const [importFmt, setImportFmt] = useState<'csv' | 'json'>('csv');
  const [importText, setImportText] = useState('period,variable,value,unit
2026-09,visitors,1250,count
2026-09,hotel_occupancy,72,percent');

  const activeDs = useMemo(() => datasets.find((d) => d.id === selected) ?? null, [datasets, selected]);

  const load = useCallback(() => {
    api
      .get<ApiDataset[]>(`/api/datasets?destination_id=${location}`)
      .then((d) => {
        setDatasets(d);
        setDemo(false);
        setSelected((s) => (d.some((x) => x.id === s) ? s : (d[0]?.id ?? '')));
      })
      .catch((e) => {
        if (!(e instanceof ApiOfflineError)) setError(String(e));
      });
  }, [location]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!activeDs) return;
    if (demo) {
      setQuality(DEMO_QUALITY);
      setObservations([]);
      return;
    }
    api.get<ApiObservation[]>(`/api/datasets/${activeDs.id}/observations`).then(setObservations).catch(() => {});
    api.get<ApiQuality>(`/api/datasets/${activeDs.id}/quality`).then(setQuality).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeDs?.id, demo]);

  const variables = activeDs?.variable_defs ?? [];

  const pivot = useMemo(() => {
    const periods = [...new Set(observations.map((o) => o.period))].sort();
    return { periods, rows: observations };
  }, [observations]);

  async function act(fn: () => Promise<unknown>, okMsg: string) {
    setError(null);
    setNotice(null);
    try {
      await fn();
      setNotice(okMsg);
      load();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }

  const createDataset = () =>
    act(async () => {
      const defs = [
        ...VARIABLE_LIBRARY.filter((v) => pickedVars.has(v.name)),
        ...(customVar.name
          ? [{ name: customVar.name.trim(), label: customVar.label || customVar.name, unit: customVar.unit, type: 'float', description: '', required: false, min: null, max: null, source: 'researcher-entry' }]
          : []),
      ];
      if (!defs.length) throw new Error('pick at least one variable definition');
      const ds = await api.post<ApiDataset>('/api/datasets', {
        destination_id: location,
        name: dsName.trim(),
        variable_defs: defs,
        provenance: { entered_by: 'researcher', mode: 'manual' },
      });
      setSelected(ds.id);
    }, 'dataset created (new version)');

  const submitEntry = () =>
    act(async () => {
      if (!activeDs) throw new Error('no dataset selected');
      const obs = variables
        .filter((v) => entry[v.name]?.trim() !== '' && entry[v.name] != null)
        .map((v) => ({ period, variable: v.name, value: Number(entry[v.name]), unit: v.unit || null }));
      if (!obs.length) throw new Error('no values entered');
      await api.post(`/api/datasets/${activeDs.id}/observations`, { observations: obs, mode: 'insert' });
      setEntry({});
    }, `${obsCount()} observation(s) stored`);

  const obsCount = () =>
    variables.filter((v) => entry[v.name]?.trim() !== '' && entry[v.name] != null).length;

  const doImport = () =>
    act(async () => {
      if (!activeDs) throw new Error('no dataset selected');
      await api.post(`/api/datasets/${activeDs.id}/import`, { format: importFmt, content: importText });
    }, 'import complete');

  const doValidate = () =>
    act(async () => {
      if (!activeDs) throw new Error('no dataset selected');
      const q = await api.post<ApiQuality>(`/api/datasets/${activeDs.id}/validate`);
      setQuality(q);
    }, 'dataset validated');

  const readonly = demo;

  return (
    <OpsFrame
      kicker="OPS"
      title="Data Operations"
      right={demo ? <span className="badge watch">DEMO CONTRACT — WRITES NEED LOCAL API</span> : undefined}
    >
      <OpsSection right={<span className="font-mono text-9 tracking-data text-faint">DESTINATION · {location.toUpperCase()}</span>}>
        DATASETS — VERSIONED, DESTINATION-SPECIFIC
      </OpsSection>
      <div className="ops-list">
        {datasets
          .filter((d) => demo || d.destination_id === location)
          .map((d) => (
            <div key={d.id} className={`ops-list-row${d.id === selected ? ' sel' : ''}`} onClick={() => setSelected(d.id)} role="button" tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && setSelected(d.id)}>
              <span className="font-mono text-9 tracking-data">{d.id}</span>
              <span>{d.name}</span>
              <span className="badge muted">v{d.version}</span>
              <span className={`badge ${d.status === 'validated' ? 'ok' : d.status === 'archived' ? 'muted' : 'watch'}`}>{d.status.toUpperCase()}</span>
              {d.quality_score != null && <span className="font-mono text-9 tracking-data text-dim">Q {d.quality_score}/100</span>}
            </div>
          ))}
        {!datasets.length && <div className="ops-note">No datasets for this destination yet — create one below.</div>}
      </div>

      {activeDs && (
        <>
          <OpsSection right={<span>{variables.length} defined variables</span>}>MANUAL DATA ENTRY — FORM GENERATED FROM VARIABLE DEFINITIONS</OpsSection>
          <div className="ops-form">
            <label className="ops-field">
              <span className="ops-label">PERIOD</span>
              <input className="ops-input" value={period} onChange={(e) => setPeriod(e.target.value)} placeholder="2026-09" disabled={readonly} />
            </label>
            {variables.map((v) => (
              <label key={v.name} className="ops-field" title={v.description || v.name}>
                <span className="ops-label">
                  {v.label || v.name}
                  {v.unit ? ` · ${v.unit}` : ''}
                  {v.required ? ' *' : ''}
                </span>
                <input
                  className="ops-input"
                  type="number"
                  min={v.min ?? undefined}
                  max={v.max ?? undefined}
                  step="any"
                  value={entry[v.name] ?? ''}
                  disabled={readonly}
                  onChange={(e) => setEntry((s) => ({ ...s, [v.name]: e.target.value }))}
                />
              </label>
            ))}
            <button className="ops-btn" onClick={submitEntry} disabled={readonly}>
              STORE OBSERVATIONS
            </button>
          </div>

          <OpsSection>IMPORT — CSV / JSON (ORIGINAL STAYS LOCAL)</OpsSection>
          <div className="ops-form">
            <div className="ops-radio">
              {(['csv', 'json'] as const).map((f) => (
                <button key={f} className={`layer-btn${importFmt === f ? ' on' : ''}`} onClick={() => setImportFmt(f)} disabled={readonly}>
                  {f.toUpperCase()}
                </button>
              ))}
            </div>
            <textarea
              className="ops-textarea"
              rows={4}
              value={importText}
              disabled={readonly}
              onChange={(e) => setImportText(e.target.value)}
              spellCheck={false}
            />
            <button className="ops-btn" onClick={doImport} disabled={readonly}>IMPORT</button>
          </div>
        </>
      )}

      <div className="ops-2col">
        <div>
          <OpsSection right={quality ? <span className={`badge ${quality.level === 'high' ? 'ok' : quality.level === 'moderate' ? 'watch' : 'risk'}`}>Q {quality.quality_score}/100</span> : undefined}>
            DATA QUALITY & VALIDATION
          </OpsSection>
          {quality ? (
            <div className="kv-block">
              <div className="prov-row"><span className="prov-k">OBSERVATIONS</span><span className="prov-v">{quality.observations}</span></div>
              <div className="prov-row"><span className="prov-k">COMPLETENESS</span><span className="prov-v">{quality.completeness_pct}%</span></div>
              <div className="prov-row"><span className="prov-k">FLAGS</span><span className="prov-v">{Object.entries(quality.flags).map(([k, v]) => `${k}:${v}`).join('  ') || 'none'}</span></div>
              <div className="prov-row"><span className="prov-k">MISSING VARIABLES</span><span className="prov-v">{quality.variables_missing.join(', ') || 'none'}</span></div>
              <button className="ops-btn" onClick={doValidate} disabled={readonly || !activeDs}>VALIDATE DATASET</button>
            </div>
          ) : (
            <div className="ops-note">Select a dataset to inspect quality.</div>
          )}
        </div>
        <div>
          <OpsSection>OBSERVATIONS {pivot.periods.length ? `· ${pivot.periods[0]} … ${pivot.periods[pivot.periods.length - 1]}` : ''}</OpsSection>
          {observations.length ? (
            <div className="ops-tablewrap">
              <table className="dtable">
                <thead>
                  <tr><th>PERIOD</th><th>VARIABLE</th><th>VALUE</th><th>UNIT</th><th>FLAG</th></tr>
                </thead>
                <tbody>
                  {observations.slice(0, 200).map((o, i) => (
                    <tr key={i}>
                      <td className="font-mono">{o.period}</td>
                      <td>{o.variable}</td>
                      <td className="font-mono">{o.value}</td>
                      <td>{o.unit ?? ''}</td>
                      <td><span className={`badge ${o.quality_flag === 'ok' ? 'muted' : 'watch'}`}>{o.quality_flag}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="ops-note">{demo ? 'Demo mode: observations are not persisted without the local API.' : 'No observations stored yet — enter data above or import CSV/JSON.'}</div>
          )}
        </div>
      </div>

      <OpsSection>NEW DATASET (NEXT VERSION BUMPS AUTOMATICALLY)</OpsSection>
      <div className="ops-form">
        <label className="ops-field">
          <span className="ops-label">DATASET NAME</span>
          <input className="ops-input" value={dsName} onChange={(e) => setDsName(e.target.value)} disabled={readonly} />
        </label>
        <div className="ops-radio">
          {VARIABLE_LIBRARY.map((v) => (
            <button
              key={v.name}
              className={`layer-btn${pickedVars.has(v.name) ? ' on' : ''}`}
              disabled={readonly}
              onClick={() =>
                setPickedVars((s) => {
                  const n = new Set(s);
                  if (n.has(v.name)) n.delete(v.name);
                  else n.add(v.name);
                  return n;
                })
              }
            >
              {v.label}
            </button>
          ))}
        </div>
        <div className="ops-inline">
          <input className="ops-input" placeholder="custom_variable" value={customVar.name} disabled={readonly}
            onChange={(e) => setCustomVar((s) => ({ ...s, name: e.target.value.replace(/[^a-z0-9_]/g, '') }))} />
          <input className="ops-input" placeholder="Label" value={customVar.label} disabled={readonly}
            onChange={(e) => setCustomVar((s) => ({ ...s, label: e.target.value }))} />
          <input className="ops-input" placeholder="unit" value={customVar.unit} disabled={readonly}
            onChange={(e) => setCustomVar((s) => ({ ...s, unit: e.target.value }))} />
        </div>
        <button className="ops-btn" onClick={createDataset} disabled={readonly}>CREATE DATASET</button>
      </div>

      {notice && <div className="ops-msg ok">{notice}</div>}
      {error && <div className="ops-msg err">{error}</div>}
      <p className="ops-note">
        Raw inputs → derived variables → model features (X) → model → output (Y). Derived variables and
        model features are computed on the backend only (docs/CALCULATIONS.md); the frontend never holds
        equations. Everything entered here stays in the local database.
      </p>
    </OpsFrame>
  );
}
