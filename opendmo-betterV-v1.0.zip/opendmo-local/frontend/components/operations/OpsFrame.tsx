"use client';

/**
 * Shared frame for Operations / Research-System sections.
 * Keeps the Mission Control idiom: mono section label, restrained borders,
 * dense data rows — NOT a generic SaaS card grid.
 */
import type { ReactNode } from 'react';
import { useEffect, useState } from 'react';
import { probeBackend } from '@/lib/api/client';
import type { ApiHealth } from '@/lib/api/types';

export function BackendBadge({ health }: { health: ApiHealth | null }) {
  if (!health) return <span className="badge muted">DEMO MODE — LOCAL API OFFLINE</span>;
  return (
    <span className="badge ok" title={`Database: ${health.database}`}>
      LOCAL RUNTIME · {health.database.toUpperCase()}
    </span>
  );
}

export function OpsFrame({
  kicker,
  title,
  right,
  children,
}: {
  kicker: string;
  title: string;
  right?: ReactNode;
  children: ReactNode;
}) {
  const [health, setHealth] = useState<ApiHealth | null>(null);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    let live = true;
    probeBackend().then((h) => {
      if (live) {
        setHealth(h);
        setChecked(true);
      }
    });
    return () => {
      live = false;
    };
  }, []);

  return (
    <section className="core-panel ops-panel" aria-label={title}>
      <div className="core-tabs">
        <div className="core-tab on" style={{ cursor: 'default' }}>
          <span className="n">{kicker}</span>
          {title}
        </div>
        <div className="ml-auto flex items-center gap-2 pr-2">
          {checked ? <BackendBadge health={health} /> : <span className="badge muted">CONNECTING…</span>}
          {right}
        </div>
      </div>
      <div className="core-body ops-body">{children}</div>
    </section>
  );
}

/** Sub-section divider in the intel idiom: MONO LABEL ———— */
export function OpsSection({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="intel-sub">
      <span>{children}</span>
      {right ? <span className="order-last shrink-0 pl-2 normal-case tracking-normal">{right}</span> : null}
    </div>
  );
}
