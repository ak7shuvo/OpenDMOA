"use client";

/** RESEARCH/SYSTEM · Methodology / Calculation Registry — every calculation
 *  with formula, method, reference, weights; plus an inline calculator that
 *  runs on the backend and returns full provenance. */
import { useCallback, useEffect, useState } from 'react';
import { api, ApiOfflineError } from '@/lib/api/client';
import type { ApiCalculation, ApiProvenance } from '@/lib/api/types';
import { DEMO_CALCULATIONS } from '@/lib/api/demo';
import { useOpenDMO } from '@/lib/state/OpenDMOContext';
import { ProvenanceBlock } from '../shared/ProvenanceBlock';
import { OpsFrame, OpsSection } from '../operations/OpsFrame';

export function MethodologyRegistry() {
  const { location } = useOpenDMO();
  const [calcs, setCalcs] = useState<ApiCalculation[]>(DEMO_CALCULATIONS);
  const [demo, setDemo] = useState(true);
  const [selected, setSelected] = useState<string>('pressure.tourism_index');
  const [values, setValues] = useState<Record<string, string>>({});
  const [result, setResult] = useState<(ApiProvenance & { formula?: string }) | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    api
      .get<ApiCalculation[]>('/api/calculations')
      .then((c) => { setCalcs(c); setDemo(false); })
      .catch((e) => { if (!(e instanceof ApiOfflineError)) console.error(e); });
  }, []);

  useEffect(() => { load(); }, [load]);

  const calc = calcs.find((c) => c.id === selected) ?? null;

  const run = async () => {
    setError(null);
    try {
      const inputs: Record<string, number> = {};
      for (const k of calc?.inputs ?? []) {
        const raw = values[k];
        if (raw == null || raw.trim() === '') throw new Error(`missing input: ${k}`);
        inputs[k] = Number(raw);
      }
      const r = await api.post<ApiProvenance & { formula: string }>('/api/calculations/run', {
        calculation_id: selected,
        destination_id: location,
        inputs,
      });
      setResult(r);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  };

  return (
    <OpsFrame kicker="SYS" title="Methodology / Calculation Registry" right={demo ? <span className="badge watch">SAMPLE RECORDS — RUNS NEED LOCAL API</span> : undefined}>
      <OpsSection right={<span className="font-mono text-9 tracking-data text-faint">{calcs.length} calculation(s)</span>}>
        CALCULATION REGISTRY — METHODOLOGY, FORMULA, REFERENCE, WEIGHTS, VERSION
      </OpsSection>
      <div className="ops-list">
        {calcs.map((c) => (
          <div key={`${c.id}@${c.version}`} className={`ops-list-row${c.id === selected ? ' sel' : ''}`}
            role="button" tabIndex={0}
            onClick={() => { setSelected(c.id); setResult(null); }}
            onKeyDown={(e) => e.key === 'Enter' && setSelected(c.id)}>
            <span className="font-mono text-9 tracking-data">{c.id} v{c.version}</span>
            <span>{c.name}</span>
            <span className="badge muted">{c.category.toUpperCase()}</span>
          </div>
        ))}
      </div>

      {calc && (
        <>
          <OpsSection>{calc.name.toUpperCase()} — v{calc.version}</OpsSection>
          <div className="kv-block">
            <div className="prov-row"><span className="prov-k">FORMULA</span><span className="prov-v font-mono">{calc.formula}</span></div>
            <div className="prov-row"><span className="prov-k">METHOD</span><span className="prov-v">{calc.method}</span></div>
            <div className="prov-row"><span className="prov-k">REFERENCE</span><span className="prov-v">{calc.reference}</span></div>
            <div className="prov-row"><span className="prov-k">WEIGHTS</span><span className="prov-v">{Object.keys(calc.weights).length ? JSON.stringify(calc.weights) : 'none (single-formula)'}</span></div>
            <div className="prov-row"><span className="prov-k">INPUTS</span><span className="prov-v">{calc.inputs.join(', ')}</span></div>
          </div>

          <OpsSection>RUN — DESTINATION · {location.toUpperCase()}</OpsSection>
          <div className="ops-form">
            {calc.inputs.map((k) => (
              <label key={k} className="ops-field">
                <span className="ops-label">{k}</span>
                <input className="ops-input" type="number" step="any" value={values[k] ?? ''} disabled={demo}
                  onChange={(e) => setValues((s) => ({ ...s, [k]: e.target.value }))} />
              </label>
            ))}
            <button className="ops-btn run" onClick={run} disabled={demo}>RUN CALCULATION</button>
          </div>
          {result && (
            <>
              <OpsSection>RESULT</OpsSection>
              <div className="kv-block">
                {Object.entries(result.outputs).map(([k, v]) => (
                  <div className="prov-row" key={k}><span className="prov-k">{k.toUpperCase()}</span><span className="prov-v">{v == null ? 'undefined (division by zero base)' : String(v)}</span></div>
                ))}
              </div>
              <ProvenanceBlock prov={result} />
            </>
          )}
          {error && <div className="ops-msg err">{error}</div>}
        </>
      )}
      <p className="ops-note">
        Custom OpenDMO indices declare methodology, formula, variables, weights, source and version in the
        backend registry (backend/app/calculations). Every execution writes a calculation_runs record —
        docs/CALCULATIONS.md and docs/PROVENANCE.md.
      </p>
    </OpsFrame>
  );
}
