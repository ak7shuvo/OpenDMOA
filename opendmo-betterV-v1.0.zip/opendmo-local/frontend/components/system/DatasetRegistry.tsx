"use client";

/** RESEARCH/SYSTEM · Dataset Registry — every versioned dataset with its
 *  destination, status, quality score and observation preview. */
import { useCallback, useEffect, useState } from 'react';
import { api, ApiOfflineError } from '@/lib/api/client';
import type { ApiDataset, ApiObservation, ApiQuality } from '@/lib/api/types';
import { DEMO_DATASETS, DEMO_QUALITY } from '@/lib/api/demo';
import { OpsFrame, OpsSection } from '../operations/OpsFrame';

export function DatasetRegistry() {
  const [datasets, setDatasets] = useState<ApiDataset[]>(DEMO_DATASETS);
  const [demo, setDemo] = useState(true);
  const [open, setOpen] = useState<string | null>(null);
  const [obs, setObs] = useState<ApiObservation[]>([]);
  const [quality, setQuality] = useState<ApiQuality | null>(null);

  const load = useCallback(() => {
    api
      .get<ApiDataset[]>('/api/datasets')
      .then((d) => { setDatasets(d); setDemo(false); })
      .catch((e) => { if (!(e instanceof ApiOfflineError)) console.error(e); });
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!open || demo) {
      if (demo) setQuality(DEMO_QUALITY);
      return;
    }
    api.get<ApiObservation[]>(`/api/datasets/${open}/observations`).then(setObs).catch(() => {});
    api.get<ApiQuality>(`/api/datasets/${open}/quality`).then(setQuality).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, demo]);

  return (
    <OpsFrame kicker="SYS" title="Dataset Registry" right={demo ? <span className="badge watch">SAMPLE RECORDS</span> : undefined}>
      <OpsSection right={<span className="font-mono text-9 tracking-data text-faint">{datasets.length} dataset version(s)</span>}>
        REGISTERED DATASETS
      </OpsSection>
      <div className="ops-list">
        {datasets.map((d) => (
          <div key={d.id} className="reg-item">
            <div className={`ops-list-row${open === d.id ? ' sel' : ''}`} role="button" tabIndex={0}
              onClick={() => setOpen(open === d.id ? null : d.id)}
              onKeyDown={(e) => e.key === 'Enter' && setOpen(open === d.id ? null : d.id)}>
              <span className="font-mono text-9 tracking-data">{d.id}</span>
              <span>{d.name}</span>
              <span className="badge muted">{d.destination_id}</span>
              <span className="badge muted">v{d.version}</span>
              <span className={`badge ${d.status === 'validated' ? 'ok' : d.status === 'archived' ? 'muted' : 'watch'}`}>{d.status.toUpperCase()}</span>
              {d.quality_score != null && <span className="font-mono text-9 tracking-data text-dim">Q {d.quality_score}/100</span>}
            </div>
            {open === d.id && (
              <div className="reg-detail">
                <div className="kv-block">
                  <div className="prov-row"><span className="prov-k">VARIABLES DEFINED</span><span className="prov-v">{d.variable_defs.map((v) => `${v.label || v.name}${v.unit ? ` (${v.unit})` : ''}`).join(', ')}</span></div>
                  <div className="prov-row"><span className="prov-k">PROVENANCE</span><span className="prov-v">{JSON.stringify(d.provenance)}</span></div>
                  {quality && (
                    <>
                      <div className="prov-row"><span className="prov-k">OBSERVATIONS</span><span className="prov-v">{quality.observations} · completeness {quality.completeness_pct}% · flags {Object.entries(quality.flags).map(([k, v]) => `${k}:${v}`).join(' ') || 'none'}</span></div>
                      <div className="prov-row"><span className="prov-k">QUALITY</span><span className="prov-v">{quality.quality_score}/100 ({quality.level})</span></div>
                    </>
                  )}
                </div>
                {obs.length > 0 && (
                  <div className="ops-tablewrap">
                    <table className="dtable">
                      <thead><tr><th>PERIOD</th><th>VARIABLE</th><th>VALUE</th><th>FLAG</th></tr></thead>
                      <tbody>
                        {obs.slice(0, 60).map((o, i) => (
                          <tr key={i}><td className="font-mono">{o.period}</td><td>{o.variable}</td><td className="font-mono">{o.value}</td><td>{o.quality_flag}</td></tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
      <p className="ops-note">
        Datasets are versioned per destination (unique destination × name × version). Archived datasets are
        immutable. Dataset contract: docs/DATASET-CONTRACT.md.
      </p>
    </OpsFrame>
  );
}
