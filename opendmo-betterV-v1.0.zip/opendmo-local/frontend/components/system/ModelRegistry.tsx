"use client";

/** RESEARCH/SYSTEM · Model Registry — full metadata inspection for every
 *  registered model package: identity, provenance, licence, training data,
 *  variable contract, status. */
import { useEffect, useState } from 'react';
import { api, ApiOfflineError } from '@/lib/api/client';
import type { ApiModel } from '@/lib/api/types';
import { DEMO_MODEL } from '@/lib/api/demo';
import { OpsFrame, OpsSection } from '../operations/OpsFrame';

export function ModelRegistry() {
  const [models, setModels] = useState<ApiModel[]>([DEMO_MODEL]);
  const [demo, setDemo] = useState(true);
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => {
    api
      .get<ApiModel[]>('/api/models')
      .then((m) => { setModels(m); setDemo(false); })
      .catch((e) => { if (!(e instanceof ApiOfflineError)) console.error(e); });
  }, []);

  return (
    <OpsFrame kicker="SYS" title="Model Registry" right={demo ? <span className="badge watch">SAMPLE RECORD</span> : undefined}>
      <OpsSection right={<span className="font-mono text-9 tracking-data text-faint">{models.length} registered version(s)</span>}>
        REGISTERED MODEL PACKAGES
      </OpsSection>
      <div className="ops-list">
        {models.map((m) => {
          const key = `${m.id}@${m.version}`;
          const isOpen = open === key;
          return (
            <div key={key} className={`reg-item${isOpen ? ' sel' : ''}`}>
              <div className="ops-list-row" role="button" tabIndex={0}
                onClick={() => setOpen(isOpen ? null : key)}
                onKeyDown={(e) => e.key === 'Enter' && setOpen(isOpen ? null : key)}>
                <span className="font-mono text-9 tracking-data">{key}</span>
                <span>{m.name}</span>
                <span className="badge muted">{m.task}</span>
                <span className="badge muted">{m.framework}</span>
                <span className={`badge ${m.status === 'enabled' ? 'ok' : 'muted'}`}>{m.status.toUpperCase()}</span>
              </div>
              {isOpen && (
                <div className="kv-block reg-detail">
                  <div className="prov-row"><span className="prov-k">DESCRIPTION</span><span className="prov-v">{m.description}</span></div>
                  <div className="prov-row"><span className="prov-k">SOURCE</span><span className="prov-v">{m.source_repo} @ {m.source_ref}</span></div>
                  <div className="prov-row"><span className="prov-k">LICENSE</span><span className="prov-v">{m.license}</span></div>
                  <div className="prov-row"><span className="prov-k">TRAINING DATA</span><span className="prov-v">{m.training_data || 'not declared'}</span></div>
                  <div className="prov-row"><span className="prov-k">EXPECTED UNITS</span><span className="prov-v">{Object.entries(m.expected_units).map(([k, v]) => `${k}: ${v}`).join('  ') || 'not declared'}</span></div>
                  <div className="prov-row"><span className="prov-k">INPUTS (X)</span><span className="prov-v">{m.input_variables.map((v) => `${v.name}${v.unit ? ` (${v.unit})` : ''}`).join(', ')}</span></div>
                  <div className="prov-row"><span className="prov-k">OUTPUTS (Y)</span><span className="prov-v">{m.output_variables.map((v) => `${v.name}${v.unit ? ` (${v.unit})` : ''}`).join(', ')}</span></div>
                  <div className="prov-row"><span className="prov-k">INSTALLED</span><span className="prov-v">{m.installed_at ? new Date(m.installed_at).toLocaleString() : 'bundled / demo'}</span></div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <p className="ops-note">
        Registration records the complete metadata.json of each package. A model may only execute when its
        framework is on the runtime whitelist and its status is ENABLED. See docs/MODEL-PACKAGE-CONTRACT.md.
      </p>
    </OpsFrame>
  );
}
