'use client';

import type { ReactNode } from 'react';
import type { Confidence, Signal, Status } from '@/lib/types';
import { confShort, statusColor, statusLabel, statusShort } from '@/lib/theme';
import { fmtSignal } from '@/lib/data/series';

export function Badge({ status, children }: { status: Status | 'info' | 'muted'; children?: ReactNode }) {
  const label = children ?? (status === 'info' || status === 'muted' ? '' : statusLabel(status));
  return <span className={`badge ${status}`}>{label}</span>;
}

export function StatusDot({ status, size = 6, glow = true }: { status: Status; size?: number; glow?: boolean }) {
  const c = statusColor(status);
  return (
    <span
      aria-label={statusShort(status)}
      className="inline-block shrink-0 rounded-full"
      style={{ width: size, height: size, background: c, boxShadow: glow ? `0 0 5px ${c}` : 'none' }}
    />
  );
}

/** Section divider in the intel-panel idiom: MONO LABEL ———— */
export function Section({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="intel-sub">
      <span>{children}</span>
      {right ? <span className="order-last shrink-0 pl-2 normal-case tracking-normal">{right}</span> : null}
    </div>
  );
}

export function ProjectedTag({ year }: { year: number }) {
  if (year <= 2026) return null;
  return <Badge status="watch">PROJECTED {year}</Badge>;
}

/** Source · confidence · snapshot — CONTRACT.md §6 on every signal display */
export function SignalMeta({ s, className = '' }: { s: Pick<Signal, 'source' | 'confidence' | 'lastUpdated'>; className?: string }) {
  return (
    <span className={`whitespace-nowrap font-mono text-9 tracking-data text-faint ${className}`} title={`Snapshot ${s.lastUpdated}`}>
      {s.source} · CONF {confShort(s.confidence)}
    </span>
  );
}

export function ConfBadge({ c }: { c: Confidence }) {
  return <Badge status={c === 'high' ? 'ok' : c === 'moderate' ? 'info' : 'muted'}>CONF {confShort(c)}</Badge>;
}

/** Compact KPI tile used inside core views. */
export function Metric({ s, note }: { s: Signal; note?: string }) {
  return (
    <div className="flex min-w-0 flex-col gap-1 bg-panel px-3 py-2">
      <div className="flex items-start justify-between gap-2">
        <span className="text-10 tracking-[.05em] text-faint">{s.label}</span>
        <StatusDot status={s.status} />
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="font-mono text-15 text-text">{fmtSignal(s.id, s.value)}</span>
        <span className="font-mono text-10 text-faint">{s.unit}</span>
      </div>
      <span className="truncate font-mono text-9 text-faint">{note ?? `CONF ${confShort(s.confidence)} · ${statusShort(s.status)}`}</span>
    </div>
  );
}

export function MetricRow({ children, cols = 4 }: { children: ReactNode; cols?: number }) {
  return (
    <div className="metric-row grid gap-px border border-line bg-line" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
      {children}
    </div>
  );
}

export function Note({ children }: { children: ReactNode }) {
  return <p className="m-0 mt-2 text-11 leading-[1.55] text-dim">{children}</p>;
}

export function Roadmap({ children }: { children: ReactNode }) {
  return (
    <div className="border border-line border-l-2 bg-panel-alt px-2.5 py-2 text-11 text-dim" style={{ borderLeftColor: 'var(--amber)' }}>
      {children}
    </div>
  );
}
