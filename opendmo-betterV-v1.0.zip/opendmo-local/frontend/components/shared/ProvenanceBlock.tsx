"use client';

/**
 * Provenance / traceability block — every important result answers:
 * what data, what variables, what formula/model, what version, when, what quality.
 * CONTRACT: this component renders ONLY backend-provided provenance objects.
 */
import type { ApiProvenance } from '@/lib/api/types';

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="prov-row">
      <span className="prov-k">{k}</span>
      <span className="prov-v">{v}</span>
    </div>
  );
}

export function ProvenanceBlock({ prov }: { prov: ApiProvenance | null }) {
  if (!prov) return null;
  const method = prov.method;
  return (
    <div className="prov-block" aria-label="Provenance">
      <div className="prov-title">PROVENANCE / TRACEABILITY</div>
      <Row k="RUN" v={prov.run_id} />
      <Row k="METHOD" v={`${method.type.toUpperCase()} · ${method.id} v${method.version}`} />
      {method.source_repo ? <Row k="SOURCE REPO" v={method.source_repo} /> : null}
      <Row k="DESTINATION" v={prov.destination} />
      <Row
        k="INPUTS"
        v={Object.entries(prov.inputs)
          .map(([k, v]) => `${k}=${v}`)
          .join('  ')}
      />
      <Row
        k="OUTPUTS"
        v={Object.entries(prov.outputs)
          .map(([k, v]) => `${k}=${typeof v === 'object' && v !== null ? (v as { value?: unknown }).value ?? JSON.stringify(v) : v}`)
          .join('  ')}
      />
      {prov.source ? (
        <>
          <Row k="DATASET" v={`${prov.source.dataset_id} v${prov.source.dataset_version} (${prov.source.dataset_name})`} />
          <Row k="DATA QUALITY" v={prov.source.quality_score != null ? `score ${prov.source.quality_score}/100` : 'not scored'} />
        </>
      ) : (
        <Row k="DATASET" v="manual inputs (no dataset linked)" />
      )}
      <Row k="CALCULATED" v={prov.timestamp ? new Date(prov.timestamp).toLocaleString() : '—'} />
    </div>
  );
}
