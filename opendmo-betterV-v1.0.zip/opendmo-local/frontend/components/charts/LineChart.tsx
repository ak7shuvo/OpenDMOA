'use client';

import type { HistoryPoint } from '@/lib/types';
import { useWidth } from '../shared/useWidth';

export type LineSeries = { id: string; label: string; color: string; points: HistoryPoint[]; dashed?: boolean; width?: number };
export type Band = { color: string; points: { year: number; lo: number; hi: number }[] };
export type RefLine = { value: number; color: string; label: string };

type Props = {
  series: LineSeries[];
  year?: number;
  refs?: RefLine[];
  bands?: Band[];
  height?: number;
  unit?: string;
  yMin?: number;
  yMax?: number;
  decimals?: number;
  xLabel?: (x: number) => string;
  ariaLabel: string;
};

/**
 * Multi-series line chart on a shared x axis (years by default).
 * Points flagged `projected` are drawn dashed after the observation year.
 */
export function LineChart({ series, year, refs = [], bands = [], height = 150, unit = '', yMin, yMax, decimals = 0, xLabel, ariaLabel }: Props) {
  const [ref, w] = useWidth<HTMLDivElement>();
  const pad = { l: 34, r: 8, t: 8, b: 16 };
  const all = series.flatMap((s) => s.points);
  if (!all.length) return <div ref={ref} style={{ height }} />;
  const xs = all.map((p) => p.year);
  const x0 = Math.min(...xs);
  const x1 = Math.max(...xs);
  const ys = [...all.map((p) => p.value), ...refs.map((r) => r.value), ...bands.flatMap((b) => b.points.flatMap((p) => [p.lo, p.hi]))];
  let lo = yMin ?? Math.min(...ys);
  let hi = yMax ?? Math.max(...ys);
  if (hi === lo) { hi += 1; lo -= 1; }
  const span = hi - lo;
  if (yMin === undefined) lo -= span * 0.08;
  if (yMax === undefined) hi += span * 0.08;
  const iw = Math.max(10, w - pad.l - pad.r);
  const ih = height - pad.t - pad.b;
  const X = (x: number) => pad.l + ((x - x0) / (x1 - x0 || 1)) * iw;
  const Y = (y: number) => pad.t + ih - ((y - lo) / (hi - lo)) * ih;
  const ticks = [lo, lo + (hi - lo) / 2, hi];
  const xticks = iw < 220 ? [x0, x1] : x1 - x0 > 8 ? [x0, x0 + Math.round((x1 - x0) / 3), x0 + Math.round((2 * (x1 - x0)) / 3), x1] : Array.from({ length: x1 - x0 + 1 }, (_, i) => x0 + i);
  const path = (pts: HistoryPoint[]) => pts.map((p, i) => `${i ? 'L' : 'M'}${X(p.year).toFixed(1)},${Y(p.value).toFixed(1)}`).join(' ');

  return (
    <div ref={ref} className="w-full" style={{ height }} role="img" aria-label={ariaLabel}>
      {w > 0 && (
        <svg width={w} height={height} className="block">
          {ticks.map((t, i) => (
            <g key={i}>
              <line x1={pad.l} x2={w - pad.r} y1={Y(t)} y2={Y(t)} stroke="var(--border)" />
              <text x={pad.l - 4} y={Y(t) + 3} textAnchor="end" fontSize={9} fill="var(--text-faint)" fontFamily="var(--mono)">
                {t.toFixed(decimals)}
              </text>
            </g>
          ))}
          {xticks.map((t, i) => (
            <text key={t} x={X(t)} y={height - 3} textAnchor={i === 0 ? 'start' : i === xticks.length - 1 ? 'end' : 'middle'} fontSize={9} fill="var(--text-faint)" fontFamily="var(--mono)">
              {xLabel ? xLabel(t) : t}
            </text>
          ))}
          {x0 <= 2026 && x1 > 2026 && !xLabel && (
            <rect x={X(2026)} y={pad.t} width={X(x1) - X(2026)} height={ih} fill="rgba(207,159,92,0.035)" />
          )}
          {bands.map((b, i) => {
            const top = b.points.map((p, j) => `${j ? 'L' : 'M'}${X(p.year)},${Y(p.hi)}`).join(' ');
            const bot = [...b.points].reverse().map((p) => `L${X(p.year)},${Y(p.lo)}`).join(' ');
            return <path key={i} d={`${top} ${bot} Z`} fill={b.color} stroke="none" />;
          })}
          {refs.map((r, i) => (
            <g key={i}>
              <line x1={pad.l} x2={w - pad.r} y1={Y(r.value)} y2={Y(r.value)} stroke={r.color} strokeDasharray="2 3" opacity={0.7} />
              <text x={w - pad.r - 2} y={Y(r.value) - 3} textAnchor="end" fontSize={8.5} fill={r.color} fontFamily="var(--mono)">
                {r.label}
              </text>
            </g>
          ))}
          {series.map((s) => {
            const cut = s.points.findIndex((p) => p.projected);
            const obs = cut === -1 ? s.points : s.points.slice(0, cut);
            const proj = cut <= 0 ? (cut === 0 ? s.points : []) : s.points.slice(cut - 1);
            return (
              <g key={s.id}>
                {obs.length > 1 && <path d={path(obs)} fill="none" stroke={s.color} strokeWidth={s.width ?? 1.5} strokeDasharray={s.dashed ? '4 3' : undefined} />}
                {proj.length > 1 && <path d={path(proj)} fill="none" stroke={s.color} strokeWidth={s.width ?? 1.5} strokeDasharray="4 3" opacity={0.75} />}
              </g>
            );
          })}
          {year !== undefined && year >= x0 && year <= x1 && (
            <g>
              <line x1={X(year)} x2={X(year)} y1={pad.t} y2={pad.t + ih} stroke="var(--cyan)" opacity={0.8} />
              {series.map((s) => {
                const p = s.points.find((q) => q.year === year);
                return p ? <circle key={s.id} cx={X(year)} cy={Y(p.value)} r={2.6} fill={s.color} stroke="var(--bg-deep)" /> : null;
              })}
            </g>
          )}
          {unit && (
            <text x={pad.l} y={pad.t - 1} fontSize={8.5} fill="var(--text-faint)" fontFamily="var(--mono)" dy={-1}>
              {unit}
            </text>
          )}
        </svg>
      )}
    </div>
  );
}

export function Legend({ items }: { items: { label: string; color: string; dashed?: boolean }[] }) {
  return (
    <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 font-mono text-9 text-dim">
      {items.map((i) => (
        <span key={i.label} className="flex items-center gap-1.5">
          <svg width="14" height="6" aria-hidden>
            <line x1="0" x2="14" y1="3" y2="3" stroke={i.color} strokeWidth="1.5" strokeDasharray={i.dashed ? '3 2' : undefined} />
          </svg>
          {i.label}
        </span>
      ))}
    </div>
  );
}
