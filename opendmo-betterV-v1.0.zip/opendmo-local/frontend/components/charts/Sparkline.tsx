import type { HistoryPoint } from '@/lib/types';

/** 100×20 sparkline: observed solid, projected dashed, marker at the selected year. */
export function Sparkline({ history, year, color }: { history: HistoryPoint[]; year: number; color: string }) {
  const vals = history.map((p) => p.value);
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const range = max - min || 1;
  const step = 100 / (history.length - 1);
  const xy = history.map((p, i) => [i * step, 18 - ((p.value - min) / range) * 16 + 1] as const);
  const cut = history.findIndex((p) => p.projected);
  const obs = cut === -1 ? xy : xy.slice(0, cut);
  const proj = cut === -1 ? [] : xy.slice(cut - 1);
  const d = (pts: readonly (readonly [number, number])[]) => pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const yi = history.findIndex((p) => p.year === year);
  return (
    <svg className="signal-spark" viewBox="0 0 100 20" preserveAspectRatio="none" aria-hidden>
      <path d={d(obs)} fill="none" stroke={color} strokeWidth={1.4} opacity={0.85} vectorEffect="non-scaling-stroke" />
      {proj.length > 1 && (
        <path d={d(proj)} fill="none" stroke={color} strokeWidth={1.2} opacity={0.6} strokeDasharray="3 2" vectorEffect="non-scaling-stroke" />
      )}
      {yi >= 0 && <line x1={xy[yi][0]} x2={xy[yi][0]} y1={0} y2={20} stroke="var(--cyan)" strokeWidth={1} opacity={0.7} vectorEffect="non-scaling-stroke" />}
    </svg>
  );
}
