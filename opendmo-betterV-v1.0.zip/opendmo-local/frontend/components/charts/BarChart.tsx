'use client';

import { useWidth } from '../shared/useWidth';

export type Bar = { label: string; value: number | null; color: string; note?: string };

/** Categorical bars with an optional reference line series (e.g. monthly normal). */
export function BarChart({ bars, line, lineColor = 'var(--cyan)', height = 140, decimals = 0, ariaLabel, max }: {
  bars: Bar[]; line?: number[]; lineColor?: string; height?: number; decimals?: number; ariaLabel: string; max?: number;
}) {
  const [ref, w] = useWidth<HTMLDivElement>();
  const pad = { l: 34, r: 6, t: 10, b: 16 };
  const vals = [...bars.map((b) => b.value ?? 0), ...(line ?? [])];
  const hi = max ?? Math.max(1, ...vals) * 1.08;
  const iw = Math.max(10, w - pad.l - pad.r);
  const ih = height - pad.t - pad.b;
  const bw = iw / bars.length;
  const Y = (v: number) => pad.t + ih - (v / hi) * ih;
  return (
    <div ref={ref} className="w-full" style={{ height }} role="img" aria-label={ariaLabel}>
      {w > 0 && (
        <svg width={w} height={height} className="block">
          {[0, hi / 2, hi].map((t, i) => (
            <g key={i}>
              <line x1={pad.l} x2={w - pad.r} y1={Y(t)} y2={Y(t)} stroke="var(--border)" />
              <text x={pad.l - 4} y={Y(t) + 3} textAnchor="end" fontSize={9} fill="var(--text-faint)" fontFamily="var(--mono)">
                {t.toFixed(decimals)}
              </text>
            </g>
          ))}
          {bars.map((b, i) => {
            const x = pad.l + i * bw + bw * 0.18;
            const bwi = bw * 0.64;
            return (
              <g key={b.label}>
                {b.value === null ? (
                  <rect x={x} y={pad.t} width={bwi} height={ih} fill="none" stroke="var(--border)" strokeDasharray="2 2" />
                ) : (
                  <rect x={x} y={Y(b.value)} width={bwi} height={Math.max(0, pad.t + ih - Y(b.value))} fill={b.color} opacity={0.85}>
                    <title>{`${b.label}: ${b.value.toFixed(decimals)}${b.note ? ` · ${b.note}` : ''}`}</title>
                  </rect>
                )}
                <text x={x + bwi / 2} y={height - 3} textAnchor="middle" fontSize={8.5} fill="var(--text-faint)" fontFamily="var(--mono)">
                  {b.label.slice(0, 3)}
                </text>
              </g>
            );
          })}
          {line && (
            <path
              d={line.map((v, i) => `${i ? 'L' : 'M'}${(pad.l + i * bw + bw / 2).toFixed(1)},${Y(v).toFixed(1)}`).join(' ')}
              fill="none" stroke={lineColor} strokeWidth={1.3} strokeDasharray="3 2"
            />
          )}
        </svg>
      )}
    </div>
  );
}

/** Horizontal percentage/score bar row — dense table-friendly. */
export function HBar({ label, value, max = 100, color, right }: { label: string; value: number; max?: number; color: string; right?: string }) {
  return (
    <div className="grid grid-cols-[150px_1fr_64px] items-center gap-2 border-b border-line py-[5px] text-11">
      <span className="truncate text-dim">{label}</span>
      <span className="relative h-[6px] bg-bg-deep">
        <span className="absolute inset-y-0 left-0" style={{ width: `${Math.max(0, Math.min(100, (value / max) * 100))}%`, background: color, opacity: 0.85 }} />
      </span>
      <span className="text-right font-mono text-10.5 text-text">{right ?? value.toFixed(0)}</span>
    </div>
  );
}
