# OpenDMO — Architecture Notes

Companion to `CONTRACT.md` (product/design rules) and `PROMPT.md` (the build
handoff). This document describes the current prototype's structure and the
proposed path to a full build.

---

## 1. Current state: `index.html` (v0.4.2-alpha)

A single self-contained file — no build step, no dependencies, opens
directly in a browser.

```
index.html
├── <style>            all CSS, custom-property token system in :root
└── <script> (IIFE)
    ├── DATA MODEL      CORES, MODULE_SIGNALS, LAYERS, LOCATIONS, TICKER_ITEMS
    ├── state{}         activeCore, location, year, base, layers{}
    ├── BUILD SIDEBAR   renders 4 cores + submodules from CORES[]
    ├── SIGNALS         renders KPI cells + sparklines per active core
    ├── LOCATION SELECT populates <select>, wires change → updateMapSelection + renderIntel
    ├── MAP             builds markers from LOCATIONS{}, base-layer switch, layer toggle pills
    ├── INTEL PANEL     renderIntel() — fully keyed off LOCATIONS[state.location]
    ├── TICKER          scrolling alert strip
    └── CLOCK / LIVE SIM setInterval-driven jitter on visible KPI values
```

**What's real in this version:** sidebar navigation, location selection, map
markers, layer toggle UI, time slider UI, live-updating KPI values (simulated
jitter), and a fully data-driven intelligence panel.

**What's not yet real:** only Observatory-style KPI cards exist per core —
switching core relabels the same 6-cell grid rather than opening a distinct
module view. GIS layers toggle visually but don't yet filter map content.
Time slider changes the year label but doesn't yet re-drive location data.

This is intentional for a prototype — it establishes the visual contract
(see `CONTRACT.md`) before the data/module depth is built out.

---

## 2. Architecture decision for v1: single-file vs. Next.js

| | Single HTML (scaled up) | Next.js + TypeScript + Tailwind |
|---|---|---|
| Good when | scope stays close to current depth, needs to stay a zero-build static artifact, or run offline/air-gapped | four cores are built out in full per `CONTRACT.md §3`, each with sub-views, filtering, and growing state |
| Risk | a single script tag holding 4 modules × 4 submodules of real UI will likely exceed ~5,000 lines and become hard to maintain | requires a build step and hosting decision |

**Recommendation:** migrate to **Next.js + TypeScript + Tailwind** once any
core moves past "KPI cards + one detail panel" — which `CONTRACT.md §3`
requires for all four. This also matches the stack already used elsewhere on
this team (see the team's other tourism-frontend project for consistency).

### Proposed structure (Next.js)

```
opendmo/
├── app/
│   ├── layout.tsx                 shell: sidebar + monitoring strip (persistent)
│   ├── page.tsx                   default → observatory
│   ├── observatory/page.tsx
│   ├── climate-risk/page.tsx
│   ├── future-economy/page.tsx
│   └── research-lab/page.tsx
├── components/
│   ├── sidebar/                   Sidebar, CoreBlock, Submodule
│   ├── monitoring/                MonitoringStrip, SignalCell, Sparkline, Ticker
│   ├── gis/                       MapCanvas, MapMarker, LayerControls, TimeSlider, Legend
│   ├── intel/                     IntelPanel, IntelRow, AlertCard, EventList, ForecastBlock
│   └── shared/                    Badge, StatusDot, LiveClock
├── lib/
│   ├── data/                      typed mock data — one file per core + locations.ts
│   ├── state/                     shared context: activeCore, location, year, layers
│   └── theme.ts                   port of the CSS custom-property token system
├── styles/
│   └── tokens.css or tailwind.config.ts   OpenDMO palette from CONTRACT.md §5
├── CONTRACT.md
├── ARCHITECTURE.md
├── PROMPT.md
└── README.md
```

### State ownership

A single shared context (`OpenDMOContext`) holds:
```ts
{
  activeCore: 'observatory' | 'climate' | 'economy' | 'lab',
  location: LocationKey,
  year: number,          // 2015–2030
  layers: Record<LayerId, boolean>,
  baseLayer: 'satellite' | 'terrain' | 'analytical',
}
```
Both the GIS panel and whichever core page is active read from and write to
this context — location selection and year must stay in sync everywhere,
per `CONTRACT.md §1` (IA flow: LOCATION → TIME → ...).

### Data layer shape

Design every mock data object as if a real API will replace it later:

```ts
type Signal = {
  id: string;
  label: string;
  unit: string;
  value: number;
  history: { year: number; value: number }[];
  status: 'ok' | 'watch' | 'risk';
  source: string;        // e.g. "OpenDMO synthetic dataset v0.4"
  confidence: 'high' | 'moderate' | 'low';
  lastUpdated: string;   // ISO timestamp
};
```
This shape (value + history + status + source + confidence + timestamp)
should be reused across all four cores so a real backend can later swap in
without touching component code — see `CONTRACT.md §6` on data integrity.

---

## 3. Migration checklist

1. Set up Next.js + TS + Tailwind; port `CONTRACT.md §5` tokens into
   `tailwind.config.ts` as custom colors/fonts (don't use Tailwind defaults)
2. Rebuild the three-zone layout (sidebar / monitoring strip / GIS + intel)
   as the persistent app shell in `app/layout.tsx`
3. Port `LOCATIONS`, `MODULE_SIGNALS`, `LAYERS` from the prototype into
   typed `lib/data/*.ts` files, extended with `history`, `source`,
   `confidence` per the shape above
4. Build each core's four submodule views per `CONTRACT.md §3`
5. Wire GIS layer toggles to actually filter/annotate map content, not just
   toggle button state
6. Wire the time slider to re-derive signal values and forecasts from
   `history`, not just relabel the year
7. Write `README.md`: run instructions, mock-vs-real-ready data map, and an
     explicit list of what a real deployment needs (live data sources, auth,
     hosting, a real GIS tile provider)


---

## 4. Target architecture (v0.6): local research & model runtime

```
Frontend (interface) → Local API (FastAPI) → Data/Calculation/Model services
→ local PostgreSQL + PostGIS → local ML model runtime
```
The frontend talks to the backend only through `lib/api/client.ts`, which falls back to clearly-labelled demo fixtures when the API is offline. Persistence, the calculation registry, the model registry and provenance live in `backend/`; `database/schema.sql` is the reference DDL.
