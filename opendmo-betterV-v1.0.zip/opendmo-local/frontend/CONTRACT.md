# OpenDMO — Product & Design Contract

**OpenDMO** — *Destination Management, Observatory & Analytical Platform*

This document is the source of truth for what OpenDMO is, who it's for, and
what must never drift during future development. Any build prompt, PR, or
redesign should be checked against this contract before merging.

---

## 1. What this is

OpenDMO is an open-source landscape mission-control / research command center
for destination researchers, DMOs (Destination Management Organisations),
policymakers, and students working on tourism, climate, and land-use in
Bangladesh — piloted on **Sylhet** and the **Chittagong Hill Tracts (CHT)**.

It is **not**:
- a marketing website or landing page
- a portfolio site
- a conventional SaaS admin dashboard
- a real-time production system connected to live APIs (yet)

It **is**:
- a dense, operational monitoring workstation
- a shared spatial (GIS) intelligence layer under four analytical modules
- explicit about being demo/simulated data until real integrations exist

## 2. Information architecture (fixed)

```
LOCATION → TIME → OBSERVATION → CHANGE → RISK → FORECAST → SCENARIO → DECISION
```

Every module and every panel exists to move a user along this chain. GIS is
the shared spatial layer across all four cores — it is not a fifth core.

## 3. The four core modules (fixed set, fixed order)

| # | Core | Covers |
|---|------|--------|
| 01 | **Destination Observatory** | Visitor Flow, Site Condition, Community Sentiment, Asset Registry |
| 02 | **Climate & Risk** | Weather Observations, Flood & Landslide Risk, Ecosystem Stress, Early Warning |
| 03 | **Future & Economy** | Revenue Signals, Scenario Modelling, Infrastructure Pipeline, Growth Forecast |
| 04 | **Research & Policy Lab** | Dataset Explorer, Policy Briefs, VR/AR Field Visualisation, Publication Queue |

VR/AR is a labeled **future capability** inside Research & Policy Lab —
never a standalone core, never presented as functional today.

## 4. Pilot locations (fixed for v1)

- **Jaflong** — Sylhet Division
- **Ratargul Swamp Forest** — Sylhet Division
- **Sajek Valley** — Chittagong Hill Tracts
- **Bandarban Hill District** — Chittagong Hill Tracts

New locations may be added later but must not replace or reduce this set
without a deliberate scope decision.

## 5. Visual system (do not soften or genericize)

**Palette**
| Token | Hex | Use |
|---|---|---|
| `--bg` | `#090c0a` | app background |
| `--panel` | `#0f1412` | panel surfaces |
| `--panel-alt` | `#131a17` | hover/active surfaces |
| `--text` | `#d9e4dd` | primary text |
| `--text-dim` | `#8a9890` | secondary text |
| `--text-faint` | `#54615a` | metadata/labels |
| `--green` | `#6fbf94` | nominal / positive signal |
| `--cyan` | `#6fb3c7` | temporal / informational accent |
| `--amber` | `#cf9f5c` | elevated / watch status |
| `--red` | `#c26f63` | active risk status |

**Type**: monospace for data, timestamps, coordinates, and system labels;
system-ui sans for prose, summaries, and navigation labels. No serif.

**Rules**
- No neon, no cyberpunk glow overload, no fake 3D
- No rounded SaaS-card kit, no soft drop shadows, no gradient decoration
- Hairline 1px borders, a subtle 34px grid texture, restrained glow only on
  live/status indicators
- Dense information hierarchy is a feature, not a flaw to fix — do not add
  whitespace-heavy "cleanup" passes that thin out the data
- Every value on screen carries a status flag (nominal / watch / risk) via
  color, not decoration for its own sake

## 6. Data integrity rule (non-negotiable)

All figures, alerts, and forecasts are **demo/simulated**. The interface
must always:
- label data sources and confidence/data-quality where shown
- never claim or imply a live API connection unless one genuinely exists
- keep timestamps and freshness indicators honest about what they represent

## 7. What "done" looks like for v1

- All four cores are genuinely distinct — not the same KPI cards relabeled
- GIS panel drives location context for whichever core is active
- Time slider and layer toggles produce visible, correct state changes
- Intelligence panel content is fully keyed per location
- VR/AR panel is present, clearly marked as roadmap, and does nothing else
- A short README states plainly what is mock vs. real-ready, and what a real
  deployment would still need

## 8. Change control

Any future prompt (including the one in `PROMPT.md`) must be checked against
this contract. If a future request conflicts with something here — e.g.
"add a fifth core" or "make it look like a typical dashboard" — flag the
conflict explicitly rather than silently complying.


---

## 9. Local-first principles (v0.6)

1. Research data stays local by default; no cloud dependency.
2. The backend owns all logic — validation, equations, model execution, provenance. React is the interface only.
3. Demo/synthetic data is always labelled; schematic GIS is labelled as not-live.
4. The four cores, GIS, monitoring and this visual identity are preserved — Operations and Research/System sections support the cores; this product never becomes a generic admin panel.
