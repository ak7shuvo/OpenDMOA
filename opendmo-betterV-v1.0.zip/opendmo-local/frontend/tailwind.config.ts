import type { Config } from 'tailwindcss';

/**
 * OpenDMO token system — CONTRACT.md §5.
 * The theme is REPLACED (not extended) for colors, radii, shadows and type
 * sizes so Tailwind's default palette / rounded-card kit cannot creep in.
 * Colors resolve to the CSS custom properties in styles/tokens.css so the
 * single source of truth stays identical to the prototype.
 */
const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}', './lib/**/*.{ts,tsx}'],
  theme: {
    colors: {
      transparent: 'transparent',
      current: 'currentColor',
      bg: 'var(--bg)',
      'bg-deep': 'var(--bg-deep)',
      panel: 'var(--panel)',
      'panel-alt': 'var(--panel-alt)',
      'panel-raised': 'var(--panel-raised)',
      line: 'var(--border)',
      'line-strong': 'var(--border-strong)',
      text: 'var(--text)',
      dim: 'var(--text-dim)',
      faint: 'var(--text-faint)',
      green: 'var(--green)',
      'green-dim': 'var(--green-dim)',
      cyan: 'var(--cyan)',
      amber: 'var(--amber)',
      red: 'var(--red)',
    },
    fontFamily: {
      mono: ['var(--mono)'],
      sans: ['var(--sans)'],
    },
    // Prototype type scale, px-exact. Named by size so usage stays legible.
    fontSize: {
      '9': ['9px', { lineHeight: '1.35' }],
      '9.5': ['9.5px', { lineHeight: '1.35' }],
      '10': ['10px', { lineHeight: '1.4' }],
      '10.5': ['10.5px', { lineHeight: '1.4' }],
      '11': ['11px', { lineHeight: '1.45' }],
      '11.5': ['11.5px', { lineHeight: '1.45' }],
      '12': ['12px', { lineHeight: '1.6' }],
      '12.5': ['12.5px', { lineHeight: '1.5' }],
      '13': ['13px', { lineHeight: '1.4' }],
      '15': ['15px', { lineHeight: '1.3' }],
      '20': ['20px', { lineHeight: '1.1' }],
    },
    borderRadius: { none: '0', sm: '1px', DEFAULT: '2px', md: '3px', full: '9999px' },
    boxShadow: { none: 'none' },
    extend: {
      letterSpacing: { label: '.09em', meta: '.06em', data: '.04em' },
    },
  },
  plugins: [],
};
export default config;
