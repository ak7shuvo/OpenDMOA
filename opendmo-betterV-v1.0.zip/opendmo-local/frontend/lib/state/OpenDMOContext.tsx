'use client';

/**
 * Single shared context — ARCHITECTURE.md §2 "State ownership".
 * activeCore is derived from the route (the URL is the source of truth for
 * which core is open); everything else lives here and survives navigation
 * because the provider sits in the root layout.
 */
import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { usePathname } from 'next/navigation';
import type { BaseLayer, CoreId, LayerId, LocationKey } from '../types';
import { CORES, coreFromPath } from '../data/cores';
import { LAYERS, OBSERVATION_YEAR } from '../data/layers';

export type OpenDMOState = {
  activeCore: CoreId;
  location: LocationKey;
  year: number; // 2015–2030
  layers: Record<LayerId, boolean>;
  baseLayer: BaseLayer;
  /** active submodule per core (additive to the ARCHITECTURE shape) */
  submodule: Record<CoreId, string>;
};

type Actions = {
  setLocation: (l: LocationKey) => void;
  setYear: (y: number) => void;
  toggleLayer: (id: LayerId) => void;
  setLayer: (id: LayerId, on: boolean) => void;
  setBaseLayer: (b: BaseLayer) => void;
  setSubmodule: (core: CoreId, sub: string) => void;
};

const Ctx = createContext<(OpenDMOState & Actions) | null>(null);

export function OpenDMOProvider({ children }: { children: ReactNode }) {
  const pathname = usePathname() ?? '/';
  const activeCore = coreFromPath(pathname);

  const [location, setLocation] = useState<LocationKey>('jaflong');
  const [year, setYearRaw] = useState<number>(OBSERVATION_YEAR);
  const [layers, setLayers] = useState<Record<LayerId, boolean>>(
    () => Object.fromEntries(LAYERS.map((l) => [l.id, l.on])) as Record<LayerId, boolean>,
  );
  const [baseLayer, setBaseLayer] = useState<BaseLayer>('satellite');
  const [submodule, setSubmoduleMap] = useState<Record<CoreId, string>>(
    () => Object.fromEntries(CORES.map((c) => [c.id, c.sub[0].id])) as Record<CoreId, string>,
  );

  const setYear = useCallback((y: number) => setYearRaw(Math.max(2015, Math.min(2030, Math.round(y)))), []);
  const toggleLayer = useCallback((id: LayerId) => setLayers((s) => ({ ...s, [id]: !s[id] })), []);
  const setLayer = useCallback((id: LayerId, on: boolean) => setLayers((s) => ({ ...s, [id]: on })), []);
  const setSubmodule = useCallback((core: CoreId, sub: string) => setSubmoduleMap((s) => ({ ...s, [core]: sub })), []);

  const value = useMemo(
    () => ({ activeCore, location, year, layers, baseLayer, submodule, setLocation, setYear, toggleLayer, setLayer, setBaseLayer, setSubmodule }),
    [activeCore, location, year, layers, baseLayer, submodule, setYear, toggleLayer, setLayer, setSubmodule],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useOpenDMO() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useOpenDMO must be used inside <OpenDMOProvider>');
  return v;
}
