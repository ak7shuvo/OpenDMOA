import type { LocationDef, LocationKey } from '../types';

/**
 * CONTRACT.md §4 — four pilot locations, fixed for v1.
 * x/y are SCHEMATIC canvas positions (the map is not to scale).
 * Narrative fields describe the 2026 observation snapshot; all numeric
 * values shown next to them are re-derived from the series engine per year.
 */
export const LOCATIONS: Record<LocationKey, LocationDef> = {
  jaflong: {
    key: 'jaflong', name: 'Jaflong', short: 'Jaflong', region: 'Sylhet Division', x: 22, y: 30,
    lat: '25.17° N', lon: '92.02° E', gauge: 'Piyain', capacityK: 730,
    envChange: 'Stone-extraction pressure on streambed, monitored since 2021',
    tourismPressure: 'High weekend density, moderate weekday flow',
    summary:
      'Jaflong shows sustained visitor growth alongside rising riverbank erosion risk. Community-reported stone extraction continues to be the dominant environmental pressure signal for this sector.',
    events: [
      { date: '22 SEP', text: 'Riverbank monitoring station recalibrated' },
      { date: '14 SEP', text: 'Community sentiment survey completed (n=118)' },
      { date: '03 SEP', text: 'Seasonal flow advisory issued' },
    ],
    forecast: 'Moderate confidence: erosion risk trending upward through Q4 2026 without intervention.',
  },
  ratargul: {
    key: 'ratargul', name: 'Ratargul Swamp Forest', short: 'Ratargul', region: 'Sylhet Division', x: 34, y: 46,
    lat: '25.08° N', lon: '91.99° E', gauge: 'Goyain', capacityK: 400,
    envChange: 'Canopy cover stable, minor siltation near boat channel',
    tourismPressure: 'Boat-access controlled, capacity within limits',
    summary:
      'Ratargul remains within nominal operating parameters. Boat-access controls appear to be holding visitor pressure below prior-year peak levels, though monsoon timing continues to govern the tourism season length.',
    events: [
      { date: '20 SEP', text: 'Boat capacity audit — within limits' },
      { date: '09 SEP', text: 'Canopy survey (satellite pass) archived' },
    ],
    forecast: 'High confidence: conditions stable through Q4 2026, pending monsoon retreat timing.',
  },
  sajek: {
    key: 'sajek', name: 'Sajek Valley', short: 'Sajek', region: 'Chittagong Hill Tracts', x: 64, y: 64,
    lat: '23.38° N', lon: '92.29° E', gauge: 'Kassalong (nearest)', capacityK: 480,
    envChange: 'Slope destabilisation near km 18 access road, tracked since 2023',
    tourismPressure: 'Rapid resort development, peak-season overload',
    summary:
      'Sajek Valley continues rapid tourism-driven growth. Infrastructure readiness has not kept pace with visitor volume, and slope stability along the primary access corridor remains the leading risk signal.',
    events: [
      { date: '23 SEP', text: 'New resort registration (unit 41)' },
      { date: '17 SEP', text: 'Slope stability field visit logged' },
      { date: '05 SEP', text: 'Access-road advisory extended' },
    ],
    forecast: 'Low-moderate confidence: infrastructure strain likely to intensify without phased capacity limits.',
  },
  bandarban: {
    key: 'bandarban', name: 'Bandarban Hill District', short: 'Bandarban', region: 'Chittagong Hill Tracts', x: 78, y: 74,
    lat: '22.20° N', lon: '92.22° E', gauge: 'Sangu', capacityK: 700,
    envChange: 'Deforestation signal on eastern ridge, accelerating since 2022',
    tourismPressure: 'Restricted access, several routes closed',
    summary:
      'Bandarban is under an active flash-flood warning following sustained upstream rainfall. Several tourism routes remain closed pending hydrological reassessment; deforestation on the eastern ridge continues to compound runoff risk.',
    events: [
      { date: '24 SEP', text: 'Flash-flood warning issued, sector-wide' },
      { date: '24 SEP', text: 'Three routes closed pending assessment' },
      { date: '18 SEP', text: 'Ridge deforestation signal confirmed (satellite)' },
    ],
    forecast: 'Low confidence during active event: reassess after warning window closes (est. 48–72h).',
  },
};

export const LOCATION_KEYS = Object.keys(LOCATIONS) as LocationKey[];
