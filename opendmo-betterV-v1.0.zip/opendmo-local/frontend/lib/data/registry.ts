/**
 * Synthetic registries — each array stands in for a future API collection
 * (see README "Mock vs real-ready"). All names of projects, briefs and
 * publications are invented for demonstration.
 */
import type { LocationKey, Project, ProjectStage, Status, CoreId } from '../types';

/* ------------------------------ 03 · Infrastructure pipeline ------------------------------ */

export const PROJECTS: Project[] = [
  { id: 'IP-101', name: 'Piyain riverbank revetment', location: 'jaflong', type: 'hazard', start: 2024, end: 2027, costCr: 48, exposure: 'watch', dx: -4, dy: 6 },
  { id: 'IP-102', name: 'Solid-waste transfer station', location: 'jaflong', type: 'waste', start: 2022, end: 2025, costCr: 12, exposure: 'ok', dx: 5, dy: -5 },
  { id: 'IP-103', name: 'Mobile coverage & visitor counters', location: 'jaflong', type: 'digital', start: 2019, end: 2021, costCr: 3, exposure: 'ok', dx: 6, dy: 4 },
  { id: 'IP-201', name: 'Boat-channel desiltation', location: 'ratargul', type: 'water', start: 2025, end: 2026, costCr: 9, exposure: 'ok', dx: -5, dy: 4 },
  { id: 'IP-202', name: 'Community eco-lodge cluster', location: 'ratargul', type: 'accommodation', start: 2027, end: 2029, costCr: 15, exposure: 'ok', dx: 5, dy: 5 },
  { id: 'IP-301', name: 'Access road km 12–22 slope stabilisation', location: 'sajek', type: 'hazard', start: 2026, end: 2029, costCr: 86, exposure: 'risk', dx: -7, dy: -3 },
  { id: 'IP-302', name: 'Piped water supply scheme', location: 'sajek', type: 'water', start: 2023, end: 2027, costCr: 34, exposure: 'watch', dx: 5, dy: -5 },
  { id: 'IP-303', name: 'Resort wastewater treatment', location: 'sajek', type: 'waste', start: 2027, end: 2030, costCr: 22, exposure: 'watch', dx: 6, dy: 3 },
  { id: 'IP-401', name: 'Sangu flood gauges & sirens', location: 'bandarban', type: 'digital', start: 2025, end: 2026, costCr: 6, exposure: 'risk', dx: -6, dy: -4 },
  { id: 'IP-402', name: 'Ruma–Boga Lake road upgrade', location: 'bandarban', type: 'road', start: 2021, end: 2025, costCr: 110, exposure: 'risk', dx: 4, dy: -7 },
  { id: 'IP-403', name: 'Hill homestay certification', location: 'bandarban', type: 'accommodation', start: 2028, end: 2030, costCr: 5, exposure: 'ok', dx: -5, dy: 6 },
];

export function projectStage(p: Project, year: number): ProjectStage | null {
  if (year < p.start - 2) return null; // not yet in the pipeline
  if (year < p.start) return 'planned';
  if (year < p.end) return 'construction';
  return 'complete';
}

/* ------------------------------ 01 · Asset registry ------------------------------ */

/** [count in 2026, growth/yr before, growth/yr after, first registered] */
export const ASSET_TYPES: { id: string; label: string; unit: string; counts: Record<LocationKey, [number, number, number, number]> }[] = [
  { id: 'homestay', label: 'Registered homestays', unit: 'ct', counts: { jaflong: [38, 3, 2, 2016], ratargul: [22, 2, 2, 2017], sajek: [64, 6, 3, 2016], bandarban: [47, 2, 3, 2015] } },
  { id: 'resort', label: 'Resorts & hotels', unit: 'ct', counts: { jaflong: [17, 1, 1, 2015], ratargul: [4, 0.3, 0.5, 2019], sajek: [41, 4, 2, 2016], bandarban: [29, 1, 1.5, 2015] } },
  { id: 'boat', label: 'Licensed boats', unit: 'ct', counts: { jaflong: [92, 5, 2, 2015], ratargul: [120, 4, 0, 2015], sajek: [0, 0, 0, 2030], bandarban: [34, 1, 2, 2015] } },
  { id: 'eatery', label: 'Food outlets', unit: 'ct', counts: { jaflong: [71, 4, 3, 2015], ratargul: [18, 1, 1, 2016], sajek: [53, 5, 3, 2016], bandarban: [44, 1, 2, 2015] } },
  { id: 'viewpoint', label: 'Managed viewpoints / trails', unit: 'ct', counts: { jaflong: [6, 0.3, 0.3, 2015], ratargul: [3, 0.1, 0.2, 2015], sajek: [5, 0.4, 0.2, 2016], bandarban: [11, 0.3, 0.4, 2015] } },
];

export function assetCount(typeId: string, loc: LocationKey, year: number): number {
  const t = ASSET_TYPES.find((a) => a.id === typeId);
  if (!t) return 0;
  const [base, past, future, first] = t.counts[loc];
  if (year < first) return 0;
  const v = year <= 2026 ? base - past * (2026 - year) : base + future * (year - 2026);
  return Math.max(0, Math.round(v));
}

export const NOTABLE_ASSETS: { id: string; name: string; location: LocationKey; type: string; since: number; condition: Status; note: string }[] = [
  { id: 'AS-J01', name: 'Zero Point riverside viewpoint', location: 'jaflong', type: 'viewpoint', since: 2015, condition: 'watch', note: 'Bank erosion within 40 m of platform' },
  { id: 'AS-J02', name: 'Mamar Bazar boat ghat', location: 'jaflong', type: 'boat', since: 2015, condition: 'ok', note: 'Queue marking installed 2024' },
  { id: 'AS-J03', name: 'Khasia village walking route', location: 'jaflong', type: 'viewpoint', since: 2018, condition: 'ok', note: 'Community-guided only' },
  { id: 'AS-R01', name: 'Swamp-forest watchtower', location: 'ratargul', type: 'viewpoint', since: 2015, condition: 'ok', note: 'Structural check passed 2025' },
  { id: 'AS-R02', name: 'Motorghat boat station', location: 'ratargul', type: 'boat', since: 2015, condition: 'ok', note: 'Capacity-controlled launch point' },
  { id: 'AS-S01', name: 'Konglak Para trail', location: 'sajek', type: 'viewpoint', since: 2016, condition: 'watch', note: 'Gully erosion on upper section' },
  { id: 'AS-S02', name: 'Ruilui Para resort strip', location: 'sajek', type: 'resort', since: 2016, condition: 'risk', note: 'Density exceeds water supply' },
  { id: 'AS-S03', name: 'Helipad viewpoint', location: 'sajek', type: 'viewpoint', since: 2017, condition: 'ok', note: '—' },
  { id: 'AS-B01', name: 'Nilgiri viewpoint complex', location: 'bandarban', type: 'viewpoint', since: 2015, condition: 'watch', note: 'Access road partially closed' },
  { id: 'AS-B02', name: 'Boga Lake homestay cluster', location: 'bandarban', type: 'homestay', since: 2015, condition: 'risk', note: 'Route closed pending assessment' },
  { id: 'AS-B03', name: 'Sangu river boat landing', location: 'bandarban', type: 'boat', since: 2015, condition: 'risk', note: 'Suspended during flood warning' },
];

/* ------------------------------ Seasonal profiles ------------------------------ */

export const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

/** relative monthly visitor share (normalised at use) */
export const VISITOR_SEASONALITY: Record<LocationKey, number[]> = {
  jaflong: [11, 10, 9, 7, 5, 5, 7, 8, 8, 9, 10, 11],
  ratargul: [3, 2, 2, 3, 6, 11, 15, 17, 16, 12, 8, 5],
  sajek: [14, 12, 8, 5, 4, 5, 7, 7, 7, 9, 10, 12],
  bandarban: [14, 13, 10, 6, 4, 3, 4, 5, 6, 9, 12, 14],
};

/** synthetic 1991–2020-style monthly rainfall normal, mm */
export const RAIN_NORMAL: Record<LocationKey, number[]> = {
  jaflong: [9, 26, 104, 336, 530, 830, 810, 630, 505, 222, 32, 8],
  ratargul: [8, 25, 100, 330, 520, 820, 800, 620, 500, 220, 30, 8],
  sajek: [8, 20, 62, 155, 340, 590, 650, 530, 340, 205, 52, 10],
  bandarban: [8, 20, 60, 150, 330, 580, 640, 520, 330, 200, 50, 10],
};

/** month index (0-based) of the last observed month in the snapshot year */
export const SNAPSHOT_MONTH = 8; // September 2026 (partial)

/** weekday / weekend split of visits */
export const WEEKEND_SHARE: Record<LocationKey, number> = { jaflong: 0.58, ratargul: 0.49, sajek: 0.63, bandarban: 0.52 };

/* ------------------------------ 01 · Sentiment themes ------------------------------ */

export const SENTIMENT_THEMES: { id: string; label: string; offset: Record<LocationKey, number> }[] = [
  { id: 'livelihood', label: 'Livelihood benefit', offset: { jaflong: 6, ratargul: 4, sajek: 10, bandarban: -4 } },
  { id: 'crowding', label: 'Crowding tolerance', offset: { jaflong: -14, ratargul: 2, sajek: -18, bandarban: 6 } },
  { id: 'culture', label: 'Cultural respect by visitors', offset: { jaflong: -3, ratargul: 3, sajek: -9, bandarban: -6 } },
  { id: 'environment', label: 'Environmental condition', offset: { jaflong: -11, ratargul: 5, sajek: -7, bandarban: -10 } },
  { id: 'voice', label: 'Say in tourism decisions', offset: { jaflong: -6, ratargul: -2, sajek: -15, bandarban: -8 } },
];

/* ------------------------------ 03 · Revenue composition ------------------------------ */

export const REVENUE_MIX: Record<LocationKey, { label: string; share: number }[]> = {
  jaflong: [
    { label: 'Accommodation', share: 22 }, { label: 'Food & beverage', share: 27 }, { label: 'Transport', share: 21 },
    { label: 'Guiding & boats', share: 19 }, { label: 'Crafts & retail', share: 11 },
  ],
  ratargul: [
    { label: 'Accommodation', share: 9 }, { label: 'Food & beverage', share: 18 }, { label: 'Transport', share: 24 },
    { label: 'Guiding & boats', share: 41 }, { label: 'Crafts & retail', share: 8 },
  ],
  sajek: [
    { label: 'Accommodation', share: 46 }, { label: 'Food & beverage', share: 24 }, { label: 'Transport', share: 20 },
    { label: 'Guiding & boats', share: 4 }, { label: 'Crafts & retail', share: 6 },
  ],
  bandarban: [
    { label: 'Accommodation', share: 31 }, { label: 'Food & beverage', share: 22 }, { label: 'Transport', share: 23 },
    { label: 'Guiding & boats', share: 13 }, { label: 'Crafts & retail', share: 11 },
  ],
};

/* ------------------------------ 04 · Datasets ------------------------------ */

export type Dataset = {
  id: string;
  name: string;
  core: CoreId;
  signals: string[];
  locations: LocationKey[];
  from: number;
  to: number;
  method: string;
  licence: string;
};

const ALL: LocationKey[] = ['jaflong', 'ratargul', 'sajek', 'bandarban'];

export const DATASETS: Dataset[] = [
  { id: 'DS-01', name: 'Visitor counts & pressure', core: 'observatory', signals: ['annual_visitors', 'visitor_pressure', 'site_occupancy'], locations: ALL, from: 2015, to: 2026, method: 'Synthetic gate-count model', licence: 'CC-BY-4.0' },
  { id: 'DS-02', name: 'Site condition audits', core: 'observatory', signals: ['trail_condition', 'sanitation', 'waste_load', 'signage'], locations: ALL, from: 2018, to: 2026, method: 'Synthetic audit scores', licence: 'CC-BY-4.0' },
  { id: 'DS-03', name: 'Community sentiment survey', core: 'observatory', signals: ['community_sentiment', 'survey_responses'], locations: ALL, from: 2017, to: 2026, method: 'Synthetic panel survey', licence: 'CC-BY-4.0' },
  { id: 'DS-04', name: 'Guide & asset registry', core: 'observatory', signals: ['registered_guides'], locations: ALL, from: 2016, to: 2026, method: 'Synthetic registry extract', licence: 'CC-BY-4.0' },
  { id: 'DS-05', name: 'Hydromet observations', core: 'climate', signals: ['rainfall_anomaly', 'temp_anomaly', 'river_stage'], locations: ALL, from: 2015, to: 2026, method: 'Synthetic station series', licence: 'CC-BY-4.0' },
  { id: 'DS-06', name: 'Slope susceptibility model', core: 'climate', signals: ['landslide_susceptibility'], locations: ['jaflong', 'sajek', 'bandarban'], from: 2019, to: 2026, method: 'Synthetic index model', licence: 'CC-BY-4.0' },
  { id: 'DS-07', name: 'Forest & ecosystem indicators', core: 'climate', signals: ['forest_cover', 'forest_cover_change', 'siltation', 'water_quality', 'biodiversity'], locations: ALL, from: 2015, to: 2026, method: 'Synthetic remote-sensing proxies', licence: 'CC-BY-4.0' },
  { id: 'DS-08', name: 'Tourism economy panel', core: 'economy', signals: ['revenue_index', 'employment_index', 'local_capture'], locations: ALL, from: 2016, to: 2026, method: 'Synthetic household/business panel', licence: 'CC-BY-4.0' },
  { id: 'DS-09', name: 'Infrastructure readiness', core: 'economy', signals: ['infra_readiness'], locations: ALL, from: 2020, to: 2026, method: 'Synthetic readiness scoring', licence: 'CC-BY-4.0' },
  { id: 'DS-10', name: 'Scenario projections 2027–30', core: 'economy', signals: ['annual_visitors', 'revenue_index', 'landslide_susceptibility'], locations: ALL, from: 2027, to: 2030, method: 'Deterministic trend projection', licence: 'CC-BY-4.0' },
  { id: 'DS-11', name: 'Sensor network metadata', core: 'lab', signals: ['sensors_reporting', 'data_completeness'], locations: ALL, from: 2021, to: 2026, method: 'Synthetic sensor log', licence: 'CC-BY-4.0' },
];

export function datasetsCovering(loc: LocationKey, year: number): Dataset[] {
  return DATASETS.filter((d) => d.locations.includes(loc) && (year > 2026 ? d.to >= 2026 || d.from > 2026 : d.from <= year && d.to >= year));
}

/* ------------------------------ 04 · Briefs & publications ------------------------------ */

export type Stage = 'drafting' | 'internal review' | 'peer review' | 'published';
export const STAGES: Stage[] = ['drafting', 'internal review', 'peer review', 'published'];

export type Brief = {
  id: string;
  title: string;
  locations: LocationKey[];
  core: CoreId;
  opened: number;
  stage: Stage;
  publishedYear?: number;
  evidence: string[];
  question: string;
  recommendation: string;
};

export const BRIEFS: Brief[] = [
  {
    id: 'PB-01', title: 'Phased capacity limits for Sajek Valley', locations: ['sajek'], core: 'economy', opened: 2026, stage: 'internal review',
    evidence: ['visitor_pressure', 'infra_readiness', 'landslide_susceptibility', 'local_capture'],
    question: 'Should peak-season overnight capacity be capped until access-road stabilisation completes?',
    recommendation: 'Introduce a phased overnight cap tied to infrastructure readiness milestones, reviewed annually.',
  },
  {
    id: 'PB-02', title: 'Streambed extraction controls at Jaflong', locations: ['jaflong'], core: 'climate', opened: 2025, stage: 'peer review',
    evidence: ['siltation', 'water_quality', 'river_stage', 'community_sentiment'],
    question: 'Which extraction controls reduce riverbank erosion without removing local livelihoods?',
    recommendation: 'Zone extraction away from the visitor reach and pair enforcement with alternative guide employment.',
  },
  {
    id: 'PB-03', title: 'Boat-access model: lessons from Ratargul', locations: ['ratargul'], core: 'observatory', opened: 2023, stage: 'published', publishedYear: 2024,
    evidence: ['visitor_pressure', 'site_occupancy', 'community_sentiment'],
    question: 'Can licensed boat quotas hold visitor pressure below capacity in a wetland site?',
    recommendation: 'Retain the quota system; publish daily quota use to reduce informal launches.',
  },
  {
    id: 'PB-04', title: 'Flash-flood route closure protocol, Bandarban', locations: ['bandarban'], core: 'climate', opened: 2026, stage: 'drafting',
    evidence: ['river_stage', 'rainfall_anomaly', 'active_warnings', 'revenue_index'],
    question: 'At what gauge level should tourism routes close, and who authorises reopening?',
    recommendation: 'Draft: close routes at the watch stage for the Sangu gauge; reopen only after a 48 h falling limb.',
  },
  {
    id: 'PB-05', title: 'Local revenue capture in CHT homestays', locations: ['sajek', 'bandarban'], core: 'economy', opened: 2025, stage: 'internal review',
    evidence: ['local_capture', 'employment_index', 'revenue_index'],
    question: 'How much tourism spend stays with hill communities, and what raises it?',
    recommendation: 'Prioritise community-owned homestay certification over new resort permits.',
  },
  {
    id: 'PB-06', title: 'Ridge reforestation priorities, Bandarban', locations: ['bandarban'], core: 'climate', opened: 2022, stage: 'published', publishedYear: 2023,
    evidence: ['forest_cover', 'forest_cover_change', 'biodiversity', 'landslide_susceptibility'],
    question: 'Which ridge segments give the largest runoff reduction per hectare replanted?',
    recommendation: 'Target the eastern ridge above the Sangu corridor first.',
  },
  {
    id: 'PB-07', title: 'Guide certification standard for Sylhet sites', locations: ['jaflong', 'ratargul'], core: 'observatory', opened: 2021, stage: 'published', publishedYear: 2022,
    evidence: ['registered_guides', 'community_sentiment'],
    question: 'Does a shared certification standard improve visitor conduct and guide income?',
    recommendation: 'Adopt the shared standard; renew certification every two years.',
  },
];

export type Publication = {
  id: string;
  title: string;
  kind: string;
  locations: LocationKey[];
  opened: number;
  stage: Stage;
  publishedYear?: number;
  datasets: string[];
};

export const PUBLICATIONS: Publication[] = [
  { id: 'PQ-01', title: 'Visitor pressure indices for small-site destinations', kind: 'Working paper', locations: ['jaflong', 'ratargul'], opened: 2025, stage: 'peer review', datasets: ['DS-01'] },
  { id: 'PQ-02', title: 'A synthetic benchmark dataset for CHT tourism research', kind: 'Dataset note', locations: ['sajek', 'bandarban'], opened: 2026, stage: 'internal review', datasets: ['DS-01', 'DS-08'] },
  { id: 'PQ-03', title: 'Monsoon timing and season length at Ratargul', kind: 'Journal article', locations: ['ratargul'], opened: 2023, stage: 'published', publishedYear: 2024, datasets: ['DS-05'] },
  { id: 'PQ-04', title: 'Slope risk and access corridors in Sajek', kind: 'Working paper', locations: ['sajek'], opened: 2026, stage: 'drafting', datasets: ['DS-06', 'DS-09'] },
  { id: 'PQ-05', title: 'Flash-flood exposure of tourism routes, Sangu basin', kind: 'Journal article', locations: ['bandarban'], opened: 2026, stage: 'internal review', datasets: ['DS-05', 'DS-06'] },
  { id: 'PQ-06', title: 'Community sentiment survey: methods note', kind: 'Methods note', locations: ALL, opened: 2022, stage: 'published', publishedYear: 2023, datasets: ['DS-03'] },
  { id: 'PQ-07', title: 'Stone extraction and streambed change, Jaflong 2015–2025', kind: 'Journal article', locations: ['jaflong'], opened: 2025, stage: 'peer review', datasets: ['DS-07'] },
];

/** stage of a brief/publication as it stood in `year`; null if not yet opened */
export function stageAt(item: { opened: number; stage: Stage; publishedYear?: number }, year: number): Stage | null {
  if (year < item.opened) return null;
  if (item.stage === 'published' && item.publishedYear && year < item.publishedYear) return 'peer review';
  return item.stage;
}
