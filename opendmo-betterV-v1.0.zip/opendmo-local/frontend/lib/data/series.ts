/**
 * Series engine — resolves any signal × location × year into the
 * ARCHITECTURE.md `Signal` shape. Deterministic: the same inputs always
 * produce the same numbers, so screenshots and exports are reproducible.
 *
 * A real backend replaces `valueAt` + `getSignal`; components never touch
 * the specs directly.
 */
import type { Confidence, HistoryPoint, LocationKey, SeriesContext, Signal, SignalSpec, Status } from '../types';
import { SPEC_BY_ID, COMPOSITE_SIGNALS } from './signals';
import { OBSERVATION_YEAR, SNAPSHOT_ISO, YEAR_MAX, YEAR_MIN } from './layers';

export const YEARS: number[] = Array.from({ length: YEAR_MAX - YEAR_MIN + 1 }, (_, i) => YEAR_MIN + i);

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** deterministic noise in [-1, 1] */
export function noise(key: string): number {
  let t = hash(key) + 0x6d2b79f5;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return (((t ^ (t >>> 14)) >>> 0) / 4294967296) * 2 - 1;
}

const SHOCKS: Record<string, Record<number, number>> = {
  covid: { 2020: 0.32, 2021: 0.62 },
  'covid-mild': { 2020: 0.82, 2021: 0.92 },
};

const cache = new Map<string, number>();

function round(v: number, d: number): number {
  const f = Math.pow(10, d);
  return Math.round(v * f) / f;
}

function ctxFor(loc: LocationKey, year: number): SeriesContext {
  return {
    loc,
    year,
    get: (id) => valueAt(id, loc, year),
    statusOf: (id) => statusAt(id, loc, year),
  };
}

export function valueAt(id: string, loc: LocationKey, year: number): number {
  const key = `${id}|${loc}|${year}`;
  const hit = cache.get(key);
  if (hit !== undefined) return hit;
  const spec = SPEC_BY_ID[id];
  if (!spec) throw new Error(`Unknown signal: ${id}`);

  let v: number;
  if (spec.derive) {
    v = spec.derive(ctxFor(loc, year));
  } else if (spec.profile) {
    const [base, past, future, amp] = spec.profile[loc];
    const dt = year - OBSERVATION_YEAR;
    v = dt <= 0 ? base + past * dt : base + future * dt;
    const shock = spec.shock ? SHOCKS[spec.shock][year] : undefined;
    if (shock) v *= shock;
    if (dt !== 0) v += noise(key) * amp * (dt > 0 ? 0.3 : 1); // projections are smoothed
  } else {
    v = 0;
  }
  if (spec.min !== undefined) v = Math.max(spec.min, v);
  if (spec.max !== undefined) v = Math.min(spec.max, v);
  v = round(v, spec.decimals);
  cache.set(key, v);
  return v;
}

export function statusFromThresholds(spec: SignalSpec, v: number): Status {
  const t = spec.thresholds;
  if (!t) return 'ok';
  if (t.worse === 'higher') return v >= t.risk ? 'risk' : v >= t.watch ? 'watch' : 'ok';
  return v <= t.risk ? 'risk' : v <= t.watch ? 'watch' : 'ok';
}

export function statusAt(id: string, loc: LocationKey, year: number): Status {
  const spec = SPEC_BY_ID[id];
  const v = valueAt(id, loc, year);
  return spec.statusFn ? spec.statusFn(v, ctxFor(loc, year)) : statusFromThresholds(spec, v);
}

const LEVELS: Confidence[] = ['high', 'moderate', 'low'];
export function confidenceAt(base: Confidence, year: number): Confidence {
  if (year <= OBSERVATION_YEAR) return base;
  const drop = Math.ceil((year - OBSERVATION_YEAR) / 2);
  return LEVELS[Math.min(LEVELS.length - 1, LEVELS.indexOf(base) + drop)];
}

export function historyOf(id: string, loc: LocationKey): HistoryPoint[] {
  return YEARS.map((y) => ({ year: y, value: valueAt(id, loc, y), ...(y > OBSERVATION_YEAR ? { projected: true } : {}) }));
}

/** The one function a real API client would replace. */
export function getSignal(id: string, loc: LocationKey, year: number): Signal {
  const spec = SPEC_BY_ID[id];
  return {
    id,
    label: spec.label,
    unit: spec.unit,
    value: valueAt(id, loc, year),
    history: historyOf(id, loc),
    status: statusAt(id, loc, year),
    source: spec.source,
    confidence: confidenceAt(spec.confidence, year),
    lastUpdated: SNAPSHOT_ISO,
  };
}

export function deltaAt(id: string, loc: LocationKey, year: number): number {
  const prev = year > YEAR_MIN ? valueAt(id, loc, year - 1) : valueAt(id, loc, year);
  return round(valueAt(id, loc, year) - prev, SPEC_BY_ID[id].decimals);
}

const RANK: Record<Status, number> = { ok: 0, watch: 1, risk: 2 };
export function worst(list: Status[]): Status {
  return list.reduce<Status>((a, b) => (RANK[b] > RANK[a] ? b : a), 'ok');
}

export function compositeStatus(loc: LocationKey, year: number): Status {
  return worst(COMPOSITE_SIGNALS.map((id) => statusAt(id, loc, year)));
}

export function thresholdsOf(id: string) {
  return SPEC_BY_ID[id].thresholds;
}

export function fmt(v: number, decimals: number): string {
  if (!Number.isFinite(v)) return '—';
  return v.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

export function fmtSignal(id: string, v: number): string {
  return fmt(v, SPEC_BY_ID[id].decimals);
}

export function isProjected(year: number): boolean {
  return year > OBSERVATION_YEAR;
}
