/**
 * Signal specifications — one entry per measurable quantity.
 * Profiles are anchored so that the 2026 value equals the prototype's
 * observation value; history before/after 2026 comes from the trend terms.
 *
 * Profile = [value2026, trend/yr before 2026, trend/yr after 2026, noise]
 */
import type { SignalSpec, Status } from '../types';
import { LOCATIONS } from './locations';
import { BRIEFS, PROJECTS, PUBLICATIONS, datasetsCovering, stageAt } from './registry';

const SRC = {
  visitors: 'SYN-v0.5 · gate-count model',
  audit: 'SYN-v0.5 · site audit',
  survey: 'SYN-v0.5 · panel survey',
  registry: 'SYN-v0.5 · registry extract',
  hydromet: 'SYN-v0.5 · station series',
  slope: 'SYN-v0.5 · susceptibility model',
  eco: 'SYN-v0.5 · remote-sensing proxy',
  econ: 'SYN-v0.5 · economy panel',
  pipeline: 'SYN-v0.5 · pipeline registry',
  meta: 'SYN-v0.5 · platform metadata',
};

const pressureStatus = (ratio: number): Status => (ratio >= 80 / 55 ? 'risk' : ratio >= 60 / 55 ? 'watch' : 'ok');

export const SPECS: SignalSpec[] = [
  /* ---------------- 01 · Destination Observatory ---------------- */
  {
    id: 'annual_visitors', label: 'Annual Visitors', unit: "'000", decimals: 0, source: SRC.visitors, confidence: 'moderate', min: 0, shock: 'covid',
    profile: { jaflong: [820, 38, 30, 45], ratargul: [310, 9, 6, 20], sajek: [540, 42, 35, 30], bandarban: [260, -8, 22, 40] },
    statusFn: (v, c) => pressureStatus(v / LOCATIONS[c.loc].capacityK),
  },
  {
    id: 'visitor_pressure', label: 'Visitor Pressure Index', unit: 'idx', decimals: 0, source: SRC.visitors, confidence: 'moderate',
    thresholds: { watch: 60, risk: 80, worse: 'higher' },
    derive: (c) => (c.get('annual_visitors') / LOCATIONS[c.loc].capacityK) * 55,
  },
  {
    id: 'site_occupancy', label: 'Site Occupancy (peak)', unit: '%', decimals: 0, source: SRC.visitors, confidence: 'moderate', min: 0, max: 100, shock: 'covid',
    thresholds: { watch: 85, risk: 95, worse: 'higher' },
    profile: { jaflong: [74, 1.2, 0.8, 3], ratargul: [61, 0.6, 0.5, 3], sajek: [92, 1.5, 0.6, 2], bandarban: [38, -1.5, 3, 5] },
  },
  {
    id: 'community_sentiment', label: 'Community Sentiment', unit: 'idx', decimals: 0, source: SRC.survey, confidence: 'moderate', min: 0, max: 100,
    thresholds: { watch: 65, risk: 50, worse: 'lower' },
    profile: { jaflong: [81, -0.4, -0.6, 2], ratargul: [84, 0.2, 0, 2], sajek: [63, -1.6, -1.2, 2.5], bandarban: [69, -0.8, 0.5, 3] },
  },
  {
    id: 'trail_condition', label: 'Trail / Access Condition', unit: 'idx', decimals: 0, source: SRC.audit, confidence: 'high', min: 0, max: 100,
    thresholds: { watch: 60, risk: 45, worse: 'lower' },
    profile: { jaflong: [58, -1, -0.8, 3], ratargul: [77, 0.3, 0.2, 2], sajek: [52, -1.8, -1.2, 3], bandarban: [44, -2, 1, 4] },
  },
  {
    id: 'registered_guides', label: 'Registered Local Guides', unit: 'ct', decimals: 0, source: SRC.registry, confidence: 'high', min: 0,
    thresholds: { watch: 40, risk: 20, worse: 'lower' },
    profile: { jaflong: [143, 9, 6, 4], ratargul: [58, 4, 3, 3], sajek: [96, 8, 7, 4], bandarban: [71, 3, 4, 4] },
  },
  {
    id: 'sanitation', label: 'Sanitation Provision', unit: 'idx', decimals: 0, source: SRC.audit, confidence: 'high', min: 0, max: 100,
    thresholds: { watch: 60, risk: 45, worse: 'lower' },
    profile: { jaflong: [55, 0.8, 1, 3], ratargul: [72, 0.8, 0.6, 2], sajek: [49, 0.5, 1.5, 3], bandarban: [58, 0.4, 0.8, 3] },
  },
  {
    id: 'waste_load', label: 'Solid-Waste Load', unit: 'idx', decimals: 0, source: SRC.audit, confidence: 'moderate', min: 0, max: 100,
    thresholds: { watch: 60, risk: 80, worse: 'higher' },
    profile: { jaflong: [68, 2, 1.2, 3], ratargul: [34, 0.8, 0.5, 2], sajek: [74, 3, 2, 3], bandarban: [41, 0.5, 1.2, 3] },
  },
  {
    id: 'signage', label: 'Signage & Safety Coverage', unit: '%', decimals: 0, source: SRC.audit, confidence: 'high', min: 0, max: 100,
    thresholds: { watch: 60, risk: 40, worse: 'lower' },
    profile: { jaflong: [66, 2, 1.5, 3], ratargul: [81, 2, 1, 2], sajek: [58, 2.5, 2, 3], bandarban: [47, 1, 1.5, 3] },
  },

  /* ---------------- 02 · Climate & Risk ---------------- */
  {
    id: 'rainfall_anomaly', label: 'Rainfall Anomaly', unit: '%', decimals: 0, source: SRC.hydromet, confidence: 'high',
    thresholds: { watch: 15, risk: 35, worse: 'higher' },
    profile: { jaflong: [23, 0.9, 1.2, 8], ratargul: [12, 0.9, 1.0, 7], sajek: [18, 1.1, 1.3, 8], bandarban: [41, 1.5, 1.5, 10] },
  },
  {
    id: 'landslide_susceptibility', label: 'Landslide Susceptibility', unit: 'idx', decimals: 0, source: SRC.slope, confidence: 'moderate', min: 0, max: 100,
    thresholds: { watch: 50, risk: 70, worse: 'higher' },
    profile: { jaflong: [38, 0.8, 0.8, 2], ratargul: [14, 0.2, 0.2, 1], sajek: [67, 2.2, 1.6, 2], bandarban: [74, 2.4, 1.5, 2.5] },
  },
  {
    id: 'river_stage', label: 'River Stage (peak)', unit: 'm', decimals: 1, source: SRC.hydromet, confidence: 'high', min: 0,
    thresholds: { watch: 4.0, risk: 5.5, worse: 'higher' },
    profile: { jaflong: [4.2, 0.08, 0.07, 0.35], ratargul: [2.8, 0.03, 0.03, 0.25], sajek: [3.1, 0.05, 0.05, 0.3], bandarban: [5.6, 0.12, 0.08, 0.45] },
  },
  {
    id: 'forest_cover_change', label: 'Forest Cover Change', unit: '%/yr', decimals: 1, source: SRC.eco, confidence: 'moderate',
    thresholds: { watch: -0.5, risk: -1.2, worse: 'lower' },
    profile: { jaflong: [-0.6, -0.03, -0.02, 0.2], ratargul: [0.1, 0, 0, 0.1], sajek: [-1.1, -0.06, -0.04, 0.2], bandarban: [-1.4, -0.08, -0.05, 0.25] },
  },
  {
    id: 'temp_anomaly', label: 'Temperature Anomaly', unit: '°C', decimals: 1, source: SRC.hydromet, confidence: 'high',
    thresholds: { watch: 0.8, risk: 1.5, worse: 'higher' },
    profile: { jaflong: [1.1, 0.04, 0.04, 0.15], ratargul: [1.0, 0.04, 0.04, 0.15], sajek: [1.2, 0.05, 0.04, 0.15], bandarban: [1.3, 0.05, 0.05, 0.15] },
  },
  {
    id: 'active_warnings', label: 'Early Warnings Active', unit: 'ct', decimals: 0, source: 'SYN-v0.5 · rule engine', confidence: 'moderate',
    thresholds: { watch: 1, risk: 2, worse: 'higher' },
    derive: (c) => ['rainfall_anomaly', 'landslide_susceptibility', 'river_stage'].filter((id) => c.statusOf(id) === 'risk').length,
  },
  {
    id: 'forest_cover', label: 'Forest Cover', unit: '%', decimals: 1, source: SRC.eco, confidence: 'moderate', min: 0, max: 100,
    profile: { jaflong: [21, -0.13, -0.13, 0.2], ratargul: [86, 0.05, 0.02, 0.4], sajek: [38, -0.45, -0.4, 0.4], bandarban: [44, -0.55, -0.6, 0.5] },
    statusFn: (_v, c) => c.statusOf('forest_cover_change'),
  },
  {
    id: 'siltation', label: 'Channel Siltation', unit: 'idx', decimals: 0, source: SRC.eco, confidence: 'moderate', min: 0, max: 100,
    thresholds: { watch: 50, risk: 70, worse: 'higher' },
    profile: { jaflong: [62, 1.5, 1, 3], ratargul: [41, 1.2, 0.8, 2], sajek: [30, 1, 1, 2], bandarban: [57, 2, 1.2, 3] },
  },
  {
    id: 'water_quality', label: 'Water Quality', unit: 'idx', decimals: 0, source: SRC.eco, confidence: 'moderate', min: 0, max: 100,
    thresholds: { watch: 60, risk: 45, worse: 'lower' },
    profile: { jaflong: [54, -1, -0.6, 3], ratargul: [71, -0.4, -0.3, 2], sajek: [66, -0.7, -0.5, 2], bandarban: [49, -1.2, -0.4, 3] },
  },
  {
    id: 'biodiversity', label: 'Biodiversity Indicator', unit: 'idx', decimals: 0, source: SRC.eco, confidence: 'low', min: 0, max: 100,
    thresholds: { watch: 60, risk: 45, worse: 'lower' },
    profile: { jaflong: [52, -1, -0.7, 2], ratargul: [78, -0.3, -0.2, 2], sajek: [57, -1.3, -0.9, 2], bandarban: [61, -1.1, -0.8, 2] },
  },

  /* ---------------- 03 · Future & Economy ---------------- */
  {
    id: 'revenue_index', label: 'Tourism Revenue Signal', unit: 'idx', decimals: 0, source: SRC.econ, confidence: 'moderate', min: 0, shock: 'covid',
    thresholds: { watch: 50, risk: 35, worse: 'lower' },
    profile: { jaflong: [88, 3, 2.5, 3], ratargul: [74, 2, 1.5, 3], sajek: [96, 5, 3, 3], bandarban: [41, -2, 4, 4] },
  },
  {
    id: 'employment_index', label: 'Local Employment Index', unit: 'idx', decimals: 0, source: SRC.econ, confidence: 'moderate', min: 0, shock: 'covid-mild',
    thresholds: { watch: 55, risk: 40, worse: 'lower' },
    profile: { jaflong: [71, 1, 0.8, 2], ratargul: [66, 0.8, 0.6, 2], sajek: [78, 2, 1.2, 2], bandarban: [52, -0.8, 1.2, 3] },
  },
  {
    id: 'infra_readiness', label: 'Infrastructure Readiness', unit: '%', decimals: 0, source: SRC.econ, confidence: 'moderate', min: 0, max: 100,
    thresholds: { watch: 60, risk: 40, worse: 'lower' },
    profile: { jaflong: [54, 1.8, 2, 3], ratargul: [68, 1.5, 1.2, 2], sajek: [41, 2.5, 3, 3], bandarban: [47, 1, 2, 3] },
  },
  {
    id: 'demand_index', label: 'Seasonal Demand Index', unit: 'idx', decimals: 0, source: SRC.econ, confidence: 'low', min: 0, shock: 'covid',
    thresholds: { watch: 50, risk: 35, worse: 'lower' },
    profile: { jaflong: [93, 3, 2, 3], ratargul: [71, 2, 1.5, 3], sajek: [98, 5, 3, 3], bandarban: [44, -1.5, 5, 5] },
  },
  {
    id: 'investment_pipeline', label: 'Active Pipeline Projects', unit: 'ct', decimals: 0, source: SRC.pipeline, confidence: 'high',
    thresholds: { watch: 0, risk: -1, worse: 'lower' },
    derive: (c) => PROJECTS.filter((p) => p.location === c.loc && p.start <= c.year && c.year <= p.end).length,
  },
  {
    id: 'local_capture', label: 'Local Revenue Capture', unit: '%', decimals: 0, source: SRC.econ, confidence: 'low', min: 0, max: 100,
    thresholds: { watch: 45, risk: 30, worse: 'lower' },
    profile: { jaflong: [46, -0.4, 0, 2], ratargul: [58, 0.2, 0.3, 2], sajek: [31, -1, -0.5, 2], bandarban: [52, 0.1, 0.4, 3] },
  },

  /* ---------------- 04 · Research & Policy Lab ---------------- */
  {
    id: 'active_datasets', label: 'Datasets Covering Site', unit: 'ct', decimals: 0, source: SRC.meta, confidence: 'high',
    thresholds: { watch: 6, risk: 3, worse: 'lower' },
    derive: (c) => datasetsCovering(c.loc, c.year).length,
  },
  {
    id: 'briefs_open', label: 'Policy Briefs Open', unit: 'ct', decimals: 0, source: SRC.meta, confidence: 'high',
    thresholds: { watch: 3, risk: 5, worse: 'higher' },
    derive: (c) => BRIEFS.filter((b) => b.locations.includes(c.loc) && (stageAt(b, c.year) ?? 'published') !== 'published').length,
  },
  {
    id: 'sensors_reporting', label: 'Field Sensors Reporting', unit: 'ct', decimals: 0, source: SRC.meta, confidence: 'high', min: 0,
    thresholds: { watch: 4, risk: 2, worse: 'lower' },
    profile: { jaflong: [7, 0.5, 0.5, 0.6], ratargul: [5, 0.4, 0.4, 0.4], sajek: [5, 0.4, 0.6, 0.5], bandarban: [3, 0.2, 0.6, 0.5] },
  },
  {
    id: 'survey_responses', label: 'Survey Responses (yr)', unit: 'n', decimals: 0, source: SRC.survey, confidence: 'high', min: 0, shock: 'covid',
    thresholds: { watch: 50, risk: 25, worse: 'lower' },
    profile: { jaflong: [118, 8, 6, 10], ratargul: [64, 4, 4, 8], sajek: [92, 7, 6, 9], bandarban: [41, -1, 5, 8] },
  },
  {
    id: 'data_completeness', label: 'Data Completeness', unit: '%', decimals: 0, source: SRC.meta, confidence: 'high', min: 0, max: 100,
    thresholds: { watch: 80, risk: 60, worse: 'lower' },
    profile: { jaflong: [86, 1.5, 0.8, 2], ratargul: [91, 1, 0.5, 2], sajek: [78, 2, 1, 3], bandarban: [63, 1.5, 2, 4] },
  },
  {
    id: 'publication_queue', label: 'Publication Queue', unit: 'ct', decimals: 0, source: SRC.meta, confidence: 'high',
    thresholds: { watch: 3, risk: 5, worse: 'higher' },
    derive: (c) => PUBLICATIONS.filter((p) => p.locations.includes(c.loc) && (stageAt(p, c.year) ?? 'published') !== 'published').length,
  },
];

export const SPEC_BY_ID: Record<string, SignalSpec> = Object.fromEntries(SPECS.map((s) => [s.id, s]));

/** Headline signals that set a location's composite (map marker / intel) status. */
export const COMPOSITE_SIGNALS = ['visitor_pressure', 'landslide_susceptibility', 'river_stage', 'rainfall_anomaly'];
