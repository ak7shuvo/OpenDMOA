import type { CoreDef, CoreId } from '../types';

/** CONTRACT.md §3 — fixed set, fixed order. */
export const CORES: CoreDef[] = [
  {
    id: 'observatory', num: '01', name: 'Destination Observatory', short: 'Observatory', route: '/observatory',
    sub: [
      { id: 'visitor-flow', name: 'Visitor Flow' },
      { id: 'site-condition', name: 'Site Condition' },
      { id: 'community-sentiment', name: 'Community Sentiment' },
      { id: 'asset-registry', name: 'Asset Registry' },
    ],
    strip: ['visitor_pressure', 'annual_visitors', 'site_occupancy', 'community_sentiment', 'trail_condition', 'registered_guides'],
    mapSignal: 'visitor_pressure',
  },
  {
    id: 'climate', num: '02', name: 'Climate & Risk', short: 'Climate & Risk', route: '/climate-risk',
    sub: [
      { id: 'weather', name: 'Weather Observations' },
      { id: 'flood-landslide', name: 'Flood & Landslide Risk' },
      { id: 'ecosystem', name: 'Ecosystem Stress' },
      { id: 'early-warning', name: 'Early Warning' },
    ],
    strip: ['rainfall_anomaly', 'landslide_susceptibility', 'river_stage', 'forest_cover_change', 'temp_anomaly', 'active_warnings'],
    mapSignal: 'landslide_susceptibility',
  },
  {
    id: 'economy', num: '03', name: 'Future & Economy', short: 'Future & Economy', route: '/future-economy',
    sub: [
      { id: 'revenue', name: 'Revenue Signals' },
      { id: 'scenario', name: 'Scenario Modelling' },
      { id: 'pipeline', name: 'Infrastructure Pipeline' },
      { id: 'growth', name: 'Growth Forecast' },
    ],
    strip: ['revenue_index', 'employment_index', 'infra_readiness', 'demand_index', 'investment_pipeline', 'local_capture'],
    mapSignal: 'revenue_index',
  },
  {
    id: 'lab', num: '04', name: 'Research & Policy Lab', short: 'Research Lab', route: '/research-lab',
    sub: [
      { id: 'datasets', name: 'Dataset Explorer' },
      { id: 'briefs', name: 'Policy Briefs' },
      { id: 'vrar', name: 'VR/AR Field Visualisation', roadmap: true },
      { id: 'publications', name: 'Publication Queue' },
    ],
    strip: ['active_datasets', 'briefs_open', 'sensors_reporting', 'survey_responses', 'data_completeness', 'publication_queue'],
    mapSignal: 'data_completeness',
  },
];

export const CORE_BY_ID = Object.fromEntries(CORES.map((c) => [c.id, c])) as Record<CoreId, CoreDef>;

export function coreFromPath(pathname: string): CoreId {
  const hit = CORES.find((c) => pathname.startsWith(c.route));
  return hit ? hit.id : 'observatory';
}
