import type { LayerId } from '../types';

export const LAYERS: { id: LayerId; name: string; on: boolean; describes: string }[] = [
  { id: 'tourism', name: 'Tourism', on: true, describes: 'Visitor density halo — radius ∝ annual visitors' },
  { id: 'environment', name: 'Environment', on: true, describes: 'Forest patches — fill ∝ forest cover' },
  { id: 'climate', name: 'Climate', on: false, describes: 'Rainfall anomaly isolines vs 1991–2020 normal' },
  { id: 'risk', name: 'Risk', on: false, describes: 'Flood corridors and landslide-susceptible slopes' },
  { id: 'infrastructure', name: 'Infrastructure', on: false, describes: 'Access roads and pipeline projects by stage' },
  { id: 'community', name: 'Community', on: false, describes: 'Survey clusters — sentiment index' },
];

export const OBSERVATION_YEAR = 2026;
export const YEAR_MIN = 2015;
export const YEAR_MAX = 2030;
/** Fixed timestamp of the synthetic snapshot. Never a live pull. */
export const SNAPSHOT_ISO = '2026-09-24T06:40:00Z';
export const DATASET_VERSION = 'OpenDMO synthetic dataset v0.5';
export const BUILD = '0.5.0-ALPHA';
