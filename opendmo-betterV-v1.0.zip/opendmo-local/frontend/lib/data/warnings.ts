/**
 * Early-warning rule engine. Warnings are DERIVED from signal thresholds
 * for the selected year — nothing here is an issued real-world warning.
 */
import type { LocationKey, Warning } from '../types';
import { statusAt, valueAt, fmtSignal } from './series';
import { LOCATIONS, LOCATION_KEYS } from './locations';
import { SPEC_BY_ID } from './signals';

type Rule = { signalId: string; watch: string; risk: string };

export const WARNING_RULES: Rule[] = [
  { signalId: 'river_stage', watch: 'River stage above watch level', risk: 'Flash-flood warning — gauge above danger level' },
  { signalId: 'rainfall_anomaly', watch: 'Wet-season rainfall above normal', risk: 'Extreme rainfall anomaly' },
  { signalId: 'landslide_susceptibility', watch: 'Elevated slope susceptibility', risk: 'Landslide warning — access corridors' },
  { signalId: 'forest_cover_change', watch: 'Forest loss above background rate', risk: 'Accelerated forest loss' },
  { signalId: 'visitor_pressure', watch: 'Visitor pressure above watch level', risk: 'Visitor pressure beyond carrying capacity' },
  { signalId: 'temp_anomaly', watch: 'Warm anomaly', risk: 'Heat stress advisory' },
];

export function warningsFor(loc: LocationKey, year: number): Warning[] {
  const out: Warning[] = [];
  for (const r of WARNING_RULES) {
    const level = statusAt(r.signalId, loc, year);
    if (level === 'ok') continue;
    const spec = SPEC_BY_ID[r.signalId];
    const v = valueAt(r.signalId, loc, year);
    const t = spec.thresholds;
    out.push({
      id: `${loc}-${r.signalId}-${year}`,
      location: loc,
      signalId: r.signalId,
      level,
      title: level === 'risk' ? r.risk : r.watch,
      detail: `${spec.label} ${fmtSignal(r.signalId, v)} ${spec.unit}` + (t ? ` · ${level} threshold ${t.worse === 'higher' ? '≥' : '≤'} ${level === 'risk' ? t.risk : t.watch}` : ''),
    });
  }
  return out.sort((a, b) => (a.level === b.level ? 0 : a.level === 'risk' ? -1 : 1));
}

export function tickerItems(year: number): string[] {
  const items: string[] = [];
  for (const k of LOCATION_KEYS) {
    for (const w of warningsFor(k, year).slice(0, 2)) {
      items.push(`${w.level === 'risk' ? 'ALERT' : 'ADVISORY'} · ${LOCATIONS[k].short} — ${w.title} (${w.detail.split(' · ')[0]})`);
    }
  }
  if (!items.length) items.push(`NOTE · No rule-derived warnings for ${year}`);
  items.push(`SYSTEM · Simulated snapshot, not a live feed · observation year ${year}${year > 2026 ? ' (projected)' : ''}`);
  items.push('SYSTEM · Warnings are derived from threshold rules on synthetic series');
  return items;
}
