/** JS-side port of the CONTRACT.md §5 token system (for SVG attributes). */
import type { Status, Confidence } from './types';

export const T = {
  bg: 'var(--bg)',
  bgDeep: 'var(--bg-deep)',
  panel: 'var(--panel)',
  panelAlt: 'var(--panel-alt)',
  border: 'var(--border)',
  borderStrong: 'var(--border-strong)',
  text: 'var(--text)',
  dim: 'var(--text-dim)',
  faint: 'var(--text-faint)',
  green: 'var(--green)',
  cyan: 'var(--cyan)',
  amber: 'var(--amber)',
  red: 'var(--red)',
} as const;

/** raw hex, for places CSS variables cannot reach (rgba fills) */
export const HEX = { green: '#6fbf94', cyan: '#6fb3c7', amber: '#cf9f5c', red: '#c26f63', text: '#d9e4dd', faint: '#54615a' } as const;

export const statusColor = (s: Status) => (s === 'risk' ? T.red : s === 'watch' ? T.amber : T.green);
export const statusHex = (s: Status) => (s === 'risk' ? HEX.red : s === 'watch' ? HEX.amber : HEX.green);
export const statusLabel = (s: Status) => (s === 'risk' ? 'ACTIVE RISK' : s === 'watch' ? 'ELEVATED' : 'NOMINAL');
export const statusShort = (s: Status) => (s === 'risk' ? 'RISK' : s === 'watch' ? 'WATCH' : 'OK');
export const confShort = (c: Confidence) => (c === 'high' ? 'HIGH' : c === 'moderate' ? 'MOD' : 'LOW');
export const rgba = (hex: string, a: number) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};
