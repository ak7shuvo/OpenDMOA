/**
 * API types — mirror of backend/app/schemas.py.
 * The frontend never invents shapes; it consumes these contracts and falls
 * back to clearly-labelled demo fixtures when the local API is unreachable.
 */

export type ApiDestination = {
  id: string;
  name: string;
  region: string | null;
  latitude: number | null;
  longitude: number | null;
  capacity_k: number | null;
  attributes: Record<string, string>;
};

export type ApiVariableDef = {
  name: string;
  label: string;
  unit: string;
  type: 'float' | 'int' | 'bool' | 'category' | string;
  description: string;
  required: boolean;
  min: number | null;
  max: number | null;
  source: string;
};

export type ApiDataset = {
  id: string;
  destination_id: string;
  name: string;
  version: number;
  status: 'draft' | 'validated' | 'archived' | string;
  quality_score: number | null;
  variable_defs: ApiVariableDef[];
  provenance: Record<string, unknown>;
};

export type ApiObservation = {
  period: string;
  variable: string;
  value: number;
  unit: string | null;
  quality_flag: string;
};

export type ApiQuality = {
  observations: number;
  periods: string[];
  variables_observed: string[];
  variables_defined: string[];
  variables_missing: string[];
  flags: Record<string, number>;
  completeness_pct: number;
  quality_score: number;
  level: 'high' | 'moderate' | 'low' | string;
};

export type ApiCalculation = {
  id: string;
  name: string;
  version: string;
  category: string;
  inputs: string[];
  formula: string;
  method: string;
  reference: string;
  weights: Record<string, number>;
};

export type ApiProvenance = {
  run_id: string;
  destination: string;
  timestamp: string | null;
  inputs: Record<string, number>;
  outputs: Record<string, unknown>;
  method: { type: 'model' | 'calculation'; id: string; version: string; source_repo?: string | null };
  source?: { dataset_id: string; dataset_version: number; dataset_name: string; quality_score: number | null } | null;
  data_quality?: Record<string, unknown> | null;
};

export type ApiModelRunResult = ApiProvenance & { status: 'success' | 'failed' | string; error: string | null };

export type ApiModelVariable = {
  name: string;
  label?: string;
  type: string;
  unit?: string;
  min?: number;
  max?: number;
  required?: boolean;
};

export type ApiModel = {
  id: string;
  version: string;
  name: string;
  task: string;
  description: string;
  framework: string;
  source_repo: string;
  source_ref: string;
  license: string;
  training_data: string;
  expected_units: Record<string, string>;
  input_variables: ApiModelVariable[];
  output_variables: ApiModelVariable[];
  status: 'enabled' | 'disabled' | 'error' | string;
  installed_at: string | null;
};

export type ApiAvailableModel = {
  repo: string;
  ref: string;
  name: string;
  task: string;
  note: string;
};

export type ApiHealth = { status: string; database: string; local_first: boolean };
