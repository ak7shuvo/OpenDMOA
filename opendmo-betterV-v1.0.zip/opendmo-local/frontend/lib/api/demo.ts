/**
 * Demo fixtures — clearly-labelled synthetic stand-ins used ONLY when the
 * local API is unreachable. They mirror the backend response shapes so the
 * same components render in both modes. Every page shows a DEMO badge.
 */
import type { ApiCalculation, ApiDataset, ApiDestination, ApiModel, ApiQuality } from './types';

export const DEMO_DESTINATIONS: ApiDestination[] = [
  { id: 'jaflong', name: 'Jaflong', region: 'Sylhet Division', latitude: 25.17, longitude: 92.02, capacity_k: 730,
    attributes: { gauge: 'Piyain', envChange: 'Stone-extraction pressure on streambed, monitored since 2021', tourismPressure: 'High weekend density, moderate weekday flow' } },
  { id: 'ratargul', name: 'Ratargul Swamp Forest', region: 'Sylhet Division', latitude: 25.08, longitude: 91.99, capacity_k: 400,
    attributes: { gauge: 'Goyain', envChange: 'Canopy cover stable, minor siltation near boat channel', tourismPressure: 'Boat-access controlled, capacity within limits' } },
  { id: 'sajek', name: 'Sajek Valley', region: 'Chittagong Hill Tracts', latitude: 23.38, longitude: 92.29, capacity_k: 480,
    attributes: { gauge: 'Kassalong (nearest)', envChange: 'Slope destabilisation near km 18 access road, tracked since 2023', tourismPressure: 'Rapid resort development, peak-season overload' } },
  { id: 'bandarban', name: 'Bandarban Hill District', region: 'Chittagong Hill Tracts', latitude: 22.19, longitude: 92.22, capacity_k: 1200,
    attributes: { gauge: 'Sangu', envChange: 'Mixed land-use change along corridor settlements', tourismPressure: 'Distributed across multiple sites; corridor congestion in season' } },
];

export const DEMO_VARIABLES = [
  { name: 'visitors', label: 'Visitors', unit: 'count', type: 'float', description: 'Visitor arrivals in period', required: true, min: 0, max: null, source: 'demo-definition' },
  { name: 'hotel_occupancy', label: 'Hotel occupancy', unit: 'percent', type: 'float', description: 'Occupancy rate', required: true, min: 0, max: 100, source: 'demo-definition' },
  { name: 'avg_stay', label: 'Average stay', unit: 'nights', type: 'float', description: '', required: false, min: 0, max: null, source: 'demo-definition' },
  { name: 'rainfall', label: 'Rainfall', unit: 'mm', type: 'float', description: '', required: false, min: 0, max: null, source: 'demo-definition' },
  { name: 'temperature', label: 'Temperature', unit: 'celsius', type: 'float', description: '', required: false, min: null, max: null, source: 'demo-definition' },
  { name: 'event_count', label: 'Event count', unit: 'count', type: 'int', description: '', required: false, min: 0, max: null, source: 'demo-definition' },
  { name: 'waste_kg', label: 'Waste', unit: 'kg', type: 'float', description: 'Solid waste collected', required: false, min: 0, max: null, source: 'demo-definition' },
  { name: 'revenue', label: 'Revenue', unit: 'BDT', type: 'float', description: 'Direct tourism revenue', required: false, min: 0, max: null, source: 'demo-definition' },
] as ApiDataset['variable_defs'];

export const DEMO_DATASETS: ApiDataset[] = [
  { id: 'DEMO-JAF-MONTHLY-01', destination_id: 'jaflong', name: 'Demo Monthly Indicators', version: 1, status: 'validated', quality_score: 88,
    variable_defs: DEMO_VARIABLES, provenance: { note: 'SYNTHETIC demo dataset — created by the frontend fallback, not stored in any database' } },
  { id: 'DEMO-SAJEK-MONTHLY-01', destination_id: 'sajek', name: 'Demo Monthly Indicators', version: 1, status: 'draft', quality_score: 64,
    variable_defs: DEMO_VARIABLES, provenance: { note: 'SYNTHETIC demo dataset' } },
];

export const DEMO_MODEL: ApiModel = {
  id: 'demo-tourism-demand', version: '1.0.0', name: 'Tourism Demand Forecast (DEMO)', task: 'regression',
  description: 'LOCAL DEMONSTRATION MODEL — illustrative coefficients, NOT fitted to real observations.',
  framework: 'json-linear', source_repo: 'local://bundled/demo-tourism-demand-v1', source_ref: 'bundled-v1.0.0',
  license: 'MIT', training_data: 'NONE — synthetic demonstration coefficients.',
  expected_units: { visitor_count: 'visitors/day', prediction: 'visitors/day' },
  input_variables: [
    { name: 'visitor_count', label: 'Visitor count (same day last year)', type: 'float', unit: 'visitors/day', min: 0, required: true },
    { name: 'hotel_occupancy', label: 'Hotel occupancy', type: 'float', unit: 'percent', min: 0, max: 100, required: true },
    { name: 'rainfall', label: 'Rainfall', type: 'float', unit: 'mm/day', min: 0, required: true },
    { name: 'temperature', label: 'Temperature', type: 'float', unit: 'celsius', required: true },
    { name: 'holiday', label: 'Public holiday (0/1)', type: 'int', unit: '0|1', min: 0, max: 1, required: true },
    { name: 'event_count', label: 'Event count', type: 'int', unit: 'count', min: 0, required: true },
  ],
  output_variables: [{ name: 'prediction', label: 'Predicted visitors', type: 'float', unit: 'visitors/day' }],
  status: 'enabled', installed_at: null,
};

export const DEMO_CALCULATIONS: ApiCalculation[] = [
  { id: 'growth.rate', name: 'Growth Rate (period-over-period)', version: '1.0.0', category: 'growth',
    inputs: ['value_current', 'value_previous'], formula: '(value_current - value_previous) / value_previous * 100',
    method: 'Simple percentage change between two observation periods. Undefined when the base is zero.',
    reference: 'Standard percentage-change formula (algebraic identity).', weights: {} },
  { id: 'growth.cagr', name: 'Compound Annual Growth Rate', version: '1.0.0', category: 'growth',
    inputs: ['value_begin', 'value_end', 'years'], formula: '((value_end / value_begin) ** (1 / years) - 1) * 100',
    method: 'Compound annual growth over n years.', reference: 'Standard CAGR definition.', weights: {} },
  { id: 'ratio.occupancy_rate', name: 'Hotel Occupancy Rate', version: '1.0.0', category: 'ratios',
    inputs: ['rooms_sold', 'rooms_available'], formula: 'rooms_sold / rooms_available * 100',
    method: 'Standard lodging occupancy measure.', reference: 'UNWTO / STR standard occupancy definition.', weights: {} },
  { id: 'ratio.waste_per_visitor', name: 'Waste per Visitor', version: '1.0.0', category: 'ratios',
    inputs: ['waste_kg', 'visitors'], formula: 'waste_kg / visitors',
    method: 'Solid waste generated per visitor visit; kg/visitor.', reference: 'Derived indicator; OpenDMO methodology v1.0.', weights: {} },
  { id: 'ratio.revenue_per_visitor', name: 'Revenue per Visitor', version: '1.0.0', category: 'ratios',
    inputs: ['revenue', 'visitors'], formula: 'revenue / visitors',
    method: 'Direct tourism revenue divided by visitor count.', reference: 'Derived indicator; OpenDMO methodology v1.0.', weights: {} },
  { id: 'ratio.visitor_density', name: 'Visitor Density', version: '1.0.0', category: 'ratios',
    inputs: ['visitors', 'area_km2'], formula: 'visitors / area_km2',
    method: 'Visitors per square kilometre per period.', reference: 'Derived indicator; OpenDMO methodology v1.0.', weights: {} },
  { id: 'pressure.tourism_index', name: 'Tourism Pressure Index', version: '1.1.0', category: 'pressure',
    inputs: ['visitors', 'capacity', 'occupancy_rate'], formula: '(0.6 * visitors/capacity + 0.4 * min(occupancy_rate/100, 1)) * 100',
    method: 'Weighted composite of visitor/capacity ratio and hotel occupancy. Weights 0.6/0.4 (OpenDMO v1.1). Bands: low <45, moderate 45–75, high ≥75. Screening indicator, not a carrying-capacity determination.',
    reference: 'OpenDMO custom index — docs/CALCULATIONS.md', weights: { visitor_capacity_ratio: 0.6, occupancy_rate: 0.4 } },
  { id: 'capacity.utilisation', name: 'Capacity Utilisation', version: '1.0.0', category: 'capacity',
    inputs: ['visitors', 'capacity'], formula: 'visitors / capacity * 100',
    method: 'Share of modelled annual carrying capacity used in the period.', reference: 'Derived indicator; OpenDMO methodology v1.0.', weights: {} },
  { id: 'sustainability.screen', name: 'Sustainability Screening Score', version: '1.0.0', category: 'sustainability',
    inputs: ['waste_per_visitor_kg', 'revenue_per_visitor'], formula: '0.5 * max(0, 100 - waste/0.5*100) + 0.5 * min(revenue/5000*100, 100)',
    method: 'Equal-weighted screen of waste intensity and local revenue capture. Reference levels 0.5 kg and 5000 BDT are methodology constants (v1.0). Screening only, not a certification.',
    reference: 'OpenDMO custom index — docs/CALCULATIONS.md', weights: { waste_score: 0.5, revenue_score: 0.5 } },
];

export const DEMO_QUALITY: ApiQuality = {
  observations: 96, periods: ['2026-06', '2026-07', '2026-08'], variables_observed: DEMO_VARIABLES.map((v) => v.name),
  variables_defined: DEMO_VARIABLES.map((v) => v.name), variables_missing: [],
  flags: { ok: 94, estimated: 2 }, completeness_pct: 100, quality_score: 90, level: 'high',
};
