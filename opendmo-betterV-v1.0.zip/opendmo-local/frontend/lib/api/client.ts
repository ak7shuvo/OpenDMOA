/**
 * Local API client — the ONLY place the frontend talks to the backend.
 *
 * Base URL: NEXT_PUBLIC_OPENDMO_API, default http://localhost:8000
 * Every helper throws ApiOfflineError when the local API cannot be reached;
 * pages catch it and switch to clearly-labelled demo fixtures instead, so the
 * Mission Control stays fully functional with no backend running.
 */

import type { ApiHealth } from './types';

export const API_BASE = process.env.NEXT_PUBLIC_OPENDMO_API ?? 'http://localhost:8000';

export class ApiOfflineError extends Error {
  constructor() {
    super('OpenDMO local API unreachable');
    this.name = 'ApiOfflineError';
  }
}

async function request<T>(path: string, init?: RequestInit, timeoutMs = 2500): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      ...init,
      headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch {
    throw new ApiOfflineError();
  }
  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    throw new Error(`API ${res.status}: ${detail.slice(0, 300)}`);
  }
  return (await res.json()) as T;
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: JSON.stringify(body ?? {}) }),
};

/** Probe the local backend. Returns null when offline (demo mode). */
export async function probeBackend(): Promise<ApiHealth | null> {
  try {
    return await api.get<ApiHealth>('/api/health');
  } catch {
    return null;
  }
}
