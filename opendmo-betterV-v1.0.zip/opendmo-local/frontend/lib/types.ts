/**
 * OpenDMO typed data model — ARCHITECTURE.md §2 "Data layer shape".
 * Every mock object is shaped as if a real API will replace it later.
 */

export type CoreId = 'observatory' | 'climate' | 'economy' | 'lab';
export type LocationKey = 'jaflong' | 'ratargul' | 'sajek' | 'bandarban';
export type LayerId = 'tourism' | 'environment' | 'climate' | 'risk' | 'infrastructure' | 'community';
export type BaseLayer = 'satellite' | 'terrain' | 'analytical';
export type Status = 'ok' | 'watch' | 'risk';
export type Confidence = 'high' | 'moderate' | 'low';

/** `projected` is an additive extension: true for years after the observation year (2026). */
export type HistoryPoint = { year: number; value: number; projected?: boolean };

/** The API contract. Components only ever consume this shape. */
export type Signal = {
  id: string;
  label: string;
  unit: string;
  value: number;
  history: HistoryPoint[];
  status: Status;
  source: string;
  confidence: Confidence;
  lastUpdated: string; // ISO timestamp
};

/* ---------- mock-generation specs (replaced by an API later) ---------- */

/** [value in 2026, trend/yr before 2026, trend/yr after 2026, noise amplitude] */
export type Profile = [number, number, number, number];

export type Thresholds = { watch: number; risk: number; worse: 'higher' | 'lower' };

export type SeriesContext = {
  loc: LocationKey;
  year: number;
  /** value of another signal for the same location and year */
  get: (id: string) => number;
  statusOf: (id: string) => Status;
};

export type SignalSpec = {
  id: string;
  label: string;
  unit: string;
  decimals: number;
  source: string;
  confidence: Confidence;
  min?: number;
  max?: number;
  thresholds?: Thresholds;
  /** statistically generated series */
  profile?: Record<LocationKey, Profile>;
  /** 2020–21 pandemic dip, applied to visitor-driven series */
  shock?: 'covid' | 'covid-mild';
  /** series computed from other signals / registries instead of a profile */
  derive?: (ctx: SeriesContext) => number;
  /** custom status rule when fixed thresholds do not fit */
  statusFn?: (value: number, ctx: SeriesContext) => Status;
};

export type Submodule = { id: string; name: string; roadmap?: boolean };

export type CoreDef = {
  id: CoreId;
  num: string;
  name: string;
  route: string;
  short: string;
  sub: Submodule[];
  strip: string[]; // six signal ids for the monitoring strip
  mapSignal: string; // signal shown next to markers when this core is active
};

export type EventItem = { date: string; text: string };

export type LocationDef = {
  key: LocationKey;
  name: string;
  short: string;
  region: string;
  x: number; // schematic map position, % of canvas
  y: number;
  lat: string;
  lon: string;
  gauge: string;
  capacityK: number; // modelled annual carrying capacity, '000 visitors
  envChange: string;
  tourismPressure: string;
  summary: string;
  events: EventItem[];
  forecast: string;
};

export type ProjectType = 'road' | 'water' | 'waste' | 'accommodation' | 'hazard' | 'digital';

export type Project = {
  id: string;
  name: string;
  location: LocationKey;
  type: ProjectType;
  start: number;
  end: number;
  costCr: number; // BDT crore
  exposure: Status; // hazard exposure of the asset
  dx: number; // map offset from location marker, %
  dy: number;
};

export type ProjectStage = 'planned' | 'construction' | 'complete';

export type Warning = {
  id: string;
  location: LocationKey;
  signalId: string;
  level: Status;
  title: string;
  detail: string;
};
