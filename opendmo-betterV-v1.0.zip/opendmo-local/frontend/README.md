# OpenDMO — Destination Management, Observatory & Analytical Platform

**Research prototype, v0.5.0-alpha.** Every number, alert, project, brief and publication in this application is **synthetic demonstration data**. Nothing is connected to a live feed, sensor, agency or survey. Do not use it for operational decisions.

It covers four pilot locations: Jaflong, Ratargul Swamp Forest, Sajek Valley and Bandarban Hill District. These are organised into four cores with four submodules each, as fixed by `CONTRACT.md`.

---

## Run it

Requires Node.js 18.18+ (tested on Node 22).

```bash
npm install
npm run dev        # http://localhost:3000
```

Production build:

```bash
npm run build
npm start          # serves the optimised build on :3000
```

Quality gates, all passing at handover:

```bash
npm run typecheck  # tsc --noEmit, strict mode
npm run lint       # next/core-web-vitals
npm run build
```

**Offline / air-gapped static build.** Uncomment `output: 'export'` in `next.config.mjs`, then run `npm run build`. The site is written to `./out` and can be served by any static file server. No runtime server is needed, because every route is pre-rendered and all data is bundled.

---

## Architecture

The structure follows `ARCHITECTURE.md` §2: Next.js 15 (App Router), TypeScript (strict), and Tailwind CSS 3.

```
app/
  layout.tsx                 persistent shell (sidebar, monitoring strip, GIS, intel)
  page.tsx                   default route → Destination Observatory
  observatory/  climate-risk/  future-economy/  research-lab/   one route per core
components/
  AppShell.tsx               three-zone layout; hosts the shared context provider
  sidebar/  monitoring/  gis/  intel/
  cores/CoreFrame.tsx        submodule tabs (synced with sidebar) + active view
  cores/{observatory,climate,economy,lab}/   4 submodule views per core
  charts/                    dependency-free SVG charts (line, fan, bar, sparkline)
  shared/                    badges, metric tiles, section headers, hooks
lib/
  types.ts                   Signal, HistoryPoint, specs, registries
  theme.ts                   JS mirror of the token system
  data/                      all mock data + the series engine (see below)
  state/OpenDMOContext.tsx   single shared context
styles/tokens.css            CONTRACT §5 tokens, verbatim from the prototype
tailwind.config.ts           theme REPLACED with the tokens (no default palette,
                             radii or shadows can leak in)
```

### Deviations from ARCHITECTURE.md (one line each)

- **activeCore is derived from the route.** The URL is the single source of truth for which core is open. It is still exposed on the context with the documented shape.
- **The workspace is GIS | core view | Intel.** The four submodule views need room, so they sit between the GIS panel and the Intel panel. The Intel panel stays at 320 px and collapses to a rail.
- **The monitoring strip is 31% of height (max 290 px) instead of 40%.** This gives the core views vertical space. The strip's content and density are otherwise unchanged.
- **Additive state and type fields.** Context adds `submodule` (the active tab per core). `HistoryPoint` adds an optional `projected` flag for years after 2026. Everything else matches the documented shapes.

### How state flows

`OpenDMOContext` holds `location`, `year` (2015–2030), `layers`, `baseLayer` and `submodule`, and derives `activeCore` from the route. It lives in the root layout, so it survives navigation between cores.

Selecting a site anywhere updates all panels at once. That includes the map marker, the location dropdown, the all-sites tables in Early Warning and Revenue, and so on. The panels that follow the selection are the monitoring strip, map, core view, and intel panel.

Moving the year slider re-derives every value, status, marker colour, map overlay, warning, project stage, brief stage and dataset coverage figure. It is not a label change.

### The series engine (`lib/data/series.ts`)

Every quantity is a `SignalSpec` in `lib/data/signals.ts`. Each spec has one of two sources:

- a **profile**: the 2026 value (anchored to the prototype's numbers), a past trend, a future trend, and a noise amplitude;
- a **derive** function, computed from other signals or registries. Examples: visitor pressure is visitors ÷ capacity, and active warnings is a count of risk-level rule hits.

`getSignal(id, location, year)` returns the exact `Signal` contract type from ARCHITECTURE.md, with these rules:

- **Status** comes from thresholds, never hand-set.
- **Confidence** steps down one level every two projected years.
- **`lastUpdated`** is the fixed snapshot timestamp.

The output is deterministic, so screenshots and CSV exports are reproducible. Status at 2026 matches the prototype: Jaflong watch, Ratargul nominal, Sajek watch, Bandarban risk.

---

## Mock vs real-ready

The components only ever call the functions in the "Replace with" column or consume the typed registries. Swapping in a backend means re-implementing those functions against an API. **No component needs to change.**

| Mock module | What it stands in for | Replace with |
|---|---|---|
| `lib/data/signals.ts` + `series.ts` (`getSignal`, `valueAt`, `statusAt`) | Time-series store of indicators per site/year | `GET /signals/{id}?location=&from=&to=` returning `Signal` |
| `lib/data/warnings.ts` (`warningsFor`, `tickerItems`) | Alert service | Rule engine on real series, or ingestion of agency-issued warnings (kept visually distinct) |
| `lib/data/locations.ts` | Site registry + narrative briefs | CMS / site registry API; narratives authored and dated by analysts |
| `lib/data/registry.ts` → `PROJECTS` | Infrastructure pipeline | Project-management / public-works database |
| `registry.ts` → `ASSET_TYPES`, `NOTABLE_ASSETS` | Tourism asset registry | Licensing / registration database |
| `registry.ts` → `DATASETS` | Data catalogue | Catalogue service (e.g. CKAN) with real provenance and licences |
| `registry.ts` → `BRIEFS`, `PUBLICATIONS` | Policy & publication workflow | Document workflow system |
| `registry.ts` → seasonality, rainfall normals, revenue mix, sentiment themes | Reference tables | Derived from real observations |
| `components/gis/GisPanel.tsx` geometry | Schematic map | Real map engine + tile provider (see below) |

Already real-ready:

- the typed `Signal` contract;
- context/state wiring;
- routing;
- the token system;
- CSV export (it writes whatever `valueAt` returns);
- the scenario model's structure, where inputs → outputs is a pure function;
- the rule-driven warning architecture.

**Not real, and labelled as such in the UI:**

- all values;
- the map geometry, which is marked "SCHEMATIC · NOT TO SCALE";
- station IDs;
- project, brief and publication titles;
- the forecast bands, which are heuristic spreads rather than estimated intervals;
- the scenario model, which is a transparent toy model and not calibrated;
- the VR/AR module, which is roadmap only.

---

## What a real deployment would need

**1. Data sources.** Each needs agreements, QA and provenance metadata.

| Domain | Needed |
|---|---|
| Hydromet | Rainfall, temperature and river-stage gauges, e.g. from the national meteorological and water-development agencies. Official danger levels per gauge should replace the illustrative thresholds. |
| Visitors | Gate or boat-ticket counts, accommodation occupancy, mobile-network or counter data. A method to estimate carrying capacity per site. |
| Community | A recurring survey with a documented sampling frame, consent process and coded theme items. |
| Environment | Remote-sensing forest cover (e.g. Landsat/Sentinel-derived), a slope-susceptibility model, water-quality sampling. |
| Economy | A household/business panel for revenue, employment and local capture. |

**2. Backend.** This means an API implementing the `Signal` contract, a time-series-capable database (e.g. PostgreSQL + TimescaleDB, with PostGIS for geometry), and scheduled ingestion jobs. Each record needs versioning, a real `lastUpdated`, and a real `confidence` derived from data quality.

**3. GIS.** Replace the schematic SVG with a real map engine (e.g. MapLibre GL or OpenLayers), a tile provider (self-hosted vector tiles or a commercial provider, plus satellite imagery under licence), and WGS84 / Web Mercator projection handling. Layer geometries (flood extents, slopes, forest polygons, roads) would be served as GeoJSON or vector tiles. The time slider must then query dated layers.

**4. Auth & roles.**

- SSO/OIDC authentication.
- Roles such as viewer, analyst, site officer and administrator.
- Restricted access to community survey microdata and to any personally identifiable registry data.

**5. Hosting & operations.**

- Any Node host or static hosting for the front end.
- A managed database and object storage for datasets.
- Monitoring, backups, and a documented incident process.
- Given connectivity at pilot sites, an offline-tolerant mode (static export plus a cached snapshot) is worth keeping.

**6. Governance.**

- A data-sharing agreement with each provider.
- A clear visual and legal separation between rule-derived alerts and agency-issued warnings.
- Review of all published briefs before release.
- An accessibility audit (WCAG 2.2 AA).

---

## Contract change-control notes (CONTRACT.md §6)

The prototype contained elements that implied live data, so these changed:

- **"LIVE" pulse + "DATA FRESHNESS · 2 MIN AGO" counter + random value jitter** became a cyan (informational) **"SIMULATED · local clock"** indicator and a fixed **"DATA SNAPSHOT 24 SEP 06:40 UTC"**. Values no longer drift randomly.
- **Sidebar "SYSTEM NOMINAL"** became **"DEMO MODE · NO LIVE FEEDS"**. The build tag reads "SYNTHETIC DATA".
- **Map "SCALE 1:480,000" / "RES: 10m/px" / "PROJ: WGS84"** became **"SCHEMATIC · NOT TO SCALE"** and **"DEMO TILES"**, because the map geometry is not projected.
- **Alerts** are now generated by threshold rules on the synthetic series. They are stated to be *not issued by any agency*, both in the intel footer and on the Early Warning rules table.
- **Sajek river stage**: the prototype said "n/a — hill terrain". The engine uses the nearest gauge (Kassalong), labelled as such.
- **The "Data Freshness" signal cell** (Observatory strip) was replaced by **Annual Visitors**. Freshness is not an indicator and cannot honestly be simulated.
- **Visual identity is otherwise untouched.** Palette, typography, density, grid texture, scan line and ticker are all as in the prototype.

---

Documents shipped alongside: `CONTRACT.md`, `ARCHITECTURE.md`, `PROMPT.md` (unchanged from the input package).
