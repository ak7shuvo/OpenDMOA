-- ============================================================================
-- OpenDMO — local-first research database (PostgreSQL + PostGIS)
--
-- Reference DDL for the preferred local architecture. The FastAPI backend
-- (SQLAlchemy models in backend/app/db_models.py) creates an equivalent
-- schema automatically on startup; this file is the canonical reference for
-- a hand-managed PostgreSQL/PostGIS instance and for reviewing the design.
--
-- Local-first: this database is expected to run on the researcher's own
-- machine (or an explicitly self-controlled server). No cloud dependency.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS postgis;

-- ---------------------------------------------------------------------------
-- destinations — the four pilot destinations (fixed set, CONTRACT.md §4)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS destinations (
    id           VARCHAR(32) PRIMARY KEY,             -- 'jaflong' | 'ratargul' | 'sajek' | 'bandarban'
    name         VARCHAR(128) NOT NULL,
    region       VARCHAR(128),
    latitude     DOUBLE PRECISION,
    longitude    DOUBLE PRECISION,
    capacity_k   DOUBLE PRECISION,                    -- modelled annual capacity, '000 visitors
    attributes   JSONB NOT NULL DEFAULT '{}'::jsonb,  -- narrative fields (envChange, tourismPressure, ...)
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- datasets — versioned observation collections per destination
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS datasets (
    id              VARCHAR(64) PRIMARY KEY,          -- e.g. 'JAF-VISITORS-01'
    destination_id  VARCHAR(32) NOT NULL REFERENCES destinations(id),
    name            VARCHAR(192) NOT NULL,
    version         INTEGER NOT NULL DEFAULT 1,
    status          VARCHAR(24) NOT NULL DEFAULT 'draft'
                    CHECK (status IN ('draft','validated','archived')),
    quality_score   DOUBLE PRECISION,                 -- 0–100 data-quality indicator
    quality_notes   TEXT,
    variable_defs   JSONB NOT NULL DEFAULT '[]'::jsonb,  -- DatasetVariableDef[] (metadata-driven)
    provenance      JSONB NOT NULL DEFAULT '{}'::jsonb,  -- source, importer, timestamps
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (destination_id, name, version)
);
CREATE INDEX IF NOT EXISTS idx_datasets_destination ON datasets(destination_id);

-- ---------------------------------------------------------------------------
-- observations — one variable value at one (destination, period)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS observations (
    id              BIGSERIAL PRIMARY KEY,
    dataset_id      VARCHAR(64) NOT NULL REFERENCES datasets(id),
    destination_id  VARCHAR(32) NOT NULL REFERENCES destinations(id),
    period          VARCHAR(16) NOT NULL,             -- '2026-09' or '2026'
    variable        VARCHAR(64) NOT NULL,
    value           DOUBLE PRECISION NOT NULL,
    unit            VARCHAR(32),
    quality_flag    VARCHAR(16) NOT NULL DEFAULT 'ok'
                    CHECK (quality_flag IN ('ok','estimated','missing','outlier')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (dataset_id, period, variable)
);
CREATE INDEX IF NOT EXISTS idx_observations_variable ON observations(variable);
CREATE INDEX IF NOT EXISTS idx_observations_lookup ON observations(destination_id, period);

-- ---------------------------------------------------------------------------
-- models — registered model packages (one row per installed version)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS models (
    id                VARCHAR(64) NOT NULL,
    version           VARCHAR(32) NOT NULL,
    name              VARCHAR(192) NOT NULL,
    task              VARCHAR(64) NOT NULL,           -- regression | classification | index
    description       TEXT,
    framework         VARCHAR(64) NOT NULL,           -- 'json-linear' | 'sklearn-joblib' (whitelisted)
    source_repo       VARCHAR(512) NOT NULL,          -- provenance: where the package came from
    source_ref        VARCHAR(128),                   -- commit / tag / version
    license           VARCHAR(64) NOT NULL,
    training_data     TEXT,
    expected_units    JSONB NOT NULL DEFAULT '{}'::jsonb,
    input_variables   JSONB NOT NULL DEFAULT '[]'::jsonb,
    output_variables  JSONB NOT NULL DEFAULT '[]'::jsonb,
    status            VARCHAR(24) NOT NULL DEFAULT 'disabled'
                      CHECK (status IN ('enabled','disabled','error')),
    package_path      VARCHAR(512) NOT NULL,          -- local storage path (inside MODEL_STORE)
    installed_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    metadata_json     JSONB NOT NULL DEFAULT '{}'::jsonb,  -- full copy of metadata.json
    PRIMARY KEY (id, version)
);

-- ---------------------------------------------------------------------------
-- model_runs — one row per local execution (reproducibility record)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS model_runs (
    id                VARCHAR(48) PRIMARY KEY,        -- 'RUN-<ts>-<rand>'
    model_id          VARCHAR(64) NOT NULL,
    model_version     VARCHAR(32) NOT NULL,
    destination_id    VARCHAR(32) NOT NULL REFERENCES destinations(id),
    inputs            JSONB NOT NULL,                 -- {var: value} exactly as supplied
    derived_variables JSONB NOT NULL DEFAULT '{}'::jsonb,
    dataset_id        VARCHAR(64),                    -- provenance: which dataset fed X
    dataset_version   INTEGER,
    outputs           JSONB NOT NULL,                 -- {var: {value, unit}}
    status            VARCHAR(24) NOT NULL CHECK (status IN ('success','failed')),
    runtime           VARCHAR(64) NOT NULL DEFAULT 'local',
    eval_metrics      JSONB NOT NULL DEFAULT '{}'::jsonb,
    data_quality      JSONB NOT NULL DEFAULT '{}'::jsonb,
    error             TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_model_runs_model ON model_runs(model_id, model_version);
CREATE INDEX IF NOT EXISTS idx_model_runs_destination ON model_runs(destination_id);

-- ---------------------------------------------------------------------------
-- calculations + calculation_versions — methodology registry
-- (the executable registry lives in backend/app/calculations; these tables
--  mirror it for querying and record versioned methodology)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS calculations (
    id          VARCHAR(64) NOT NULL,
    version     VARCHAR(32) NOT NULL,
    name        VARCHAR(192) NOT NULL,
    category    VARCHAR(64),                          -- growth | ratios | pressure | capacity | sustainability
    inputs      JSONB NOT NULL DEFAULT '[]'::jsonb,
    formula     TEXT NOT NULL,
    method      TEXT,
    reference   VARCHAR(512),
    weights     JSONB NOT NULL DEFAULT '{}'::jsonb,
    status      VARCHAR(24) NOT NULL DEFAULT 'active',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (id, version)
);

-- ---------------------------------------------------------------------------
-- calculation_runs — provenance for every executed calculation
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS calculation_runs (
    id                  VARCHAR(48) PRIMARY KEY,
    calculation_id      VARCHAR(64) NOT NULL,
    calculation_version VARCHAR(32) NOT NULL,
    destination_id      VARCHAR(32) NOT NULL REFERENCES destinations(id),
    inputs              JSONB NOT NULL,
    outputs             JSONB NOT NULL,
    dataset_id          VARCHAR(64),
    data_quality        JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_calc_runs_calc ON calculation_runs(calculation_id, calculation_version);

-- ---------------------------------------------------------------------------
-- gis_layers — spatial context for destinations / datasets / results
-- geometry is native PostGIS here; the portable fallback stores WKT/GeoJSON text.
-- demo = TRUE rows are schematic/synthetic and must stay clearly labelled.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gis_layers (
    id             VARCHAR(64) PRIMARY KEY,
    name           VARCHAR(128) NOT NULL,
    category       VARCHAR(64),
    description    TEXT,
    destination_id VARCHAR(32) REFERENCES destinations(id),
    geometry       geometry(Geometry, 4326),
    attributes     JSONB NOT NULL DEFAULT '{}'::jsonb,
    source         VARCHAR(512),
    demo           BOOLEAN NOT NULL DEFAULT FALSE,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_gis_layers_geom ON gis_layers USING GIST (geometry);

-- ============================================================================
-- Demo vs research data
--   * The frontend bundles SYNTHETIC demo data (labelled everywhere).
--   * Research data enters ONLY through the Data Operations panel into the
--     tables above. Nothing is uploaded anywhere by default.
-- ============================================================================
